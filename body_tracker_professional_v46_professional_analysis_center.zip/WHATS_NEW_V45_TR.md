# V45 Görünür Akıllı Takip Merkezi

- Ana dashboard'a `Akıllı Takip Merkezi` eklendi.
- Yağ riski, sıvı düşüklüğü, iç yağ riski ve ölçüm bekleyen danışan sayısı ana ekranda gösterilir.
- Dashboard üzerinden doğrudan `Akıllı Plan`, `Ölçüm` ve `Randevu + Stok Takibi` açılır.
- Danışan detayına `Akıllı Danışan Özeti` eklendi.
- Detay ekranında durum, kalite skoru, plan/ürün sayısı, kritik stok, uyum ve karar günlüğü özetlenir.
- Workflow zip adı `body_tracker_professional_v45_visible_smart_center.zip` olarak güncellendi.
- Sürüm `versionCode 45` / `versionName 45.0` yapıldı.
