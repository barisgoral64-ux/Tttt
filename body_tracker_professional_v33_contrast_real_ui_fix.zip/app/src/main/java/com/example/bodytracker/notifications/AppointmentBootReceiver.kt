package com.example.bodytracker.notifications

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class AppointmentBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val shouldReschedule = intent.action in setOf(
            Intent.ACTION_BOOT_COMPLETED,
            Intent.ACTION_TIME_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED
        )
        if (!shouldReschedule) return

        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                AppointmentAlarmReceiver.rescheduleFutureAppointments(context.applicationContext)
            } catch (t: Throwable) {
                Log.e("AppointmentBoot", "Future appointment reschedule failed", t)
            } finally {
                pendingResult.finish()
            }
        }
    }
}
