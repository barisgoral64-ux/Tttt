# Tasarım Özeti - v3

## Yeni kullanıcı deneyimi
- Hasta arama alanı ile hızlı erişim
- Hasta detayından diyet listesine kısa yol
- Hazırlanan belgeyi WhatsApp üzerinden gönderme
- Ölçüme göre kişiselleştirilmiş plan metni

## Diyet listesi ekranı
- Hedef seçimi: Kilo Verme / Kilo Kontrolü / Kas Koruma
- Öğün planı alanı
- Su tüketimi alanı
- Uzman notları alanı
- Belge önizleme kartı
- Paylaş / WhatsApp butonları

## Kayıt ve kıyas mantığı
- Ölçüm tarihi bazlı kayıt
- Son ve bir önceki ölçüm arasında kıyas
- Kilo, VKİ, yağ ve iç yağ değişim özeti
