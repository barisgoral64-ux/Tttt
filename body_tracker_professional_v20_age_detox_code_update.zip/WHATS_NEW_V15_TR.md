# V15 Yenilikleri

- Ürün liste ekranı diyet planı sayfasına eklendi
- Kategori filtreleme
- Ürün arama
- Görselli ürün seçme
- Seçilen takviyelerin diyet belgesine eklenmesi
- Uzaktan görseller için INTERNET izni eklendi
