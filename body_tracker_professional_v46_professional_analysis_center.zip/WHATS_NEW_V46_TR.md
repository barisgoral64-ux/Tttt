# V46 Profesyonel Vücut Analiz Merkezi

- Danışan detayına büyük `Profesyonel Vücut Analiz Merkezi` eklendi.
- Analiz skoru, grade, risk matrisi, kompozisyon barları ve aksiyon listesi görünür hale getirildi.
- Önceki ölçüme göre kilo, yağ, sıvı ve iç yağ farkı ayrı gösterilir.
- Ölçüm giriş ekranında canlı karar paneli eklendi.
- Son ölçümler için kilo/yağ/sıvı trend şeridi eklendi.
- Workflow zip adı `body_tracker_professional_v46_professional_analysis_center.zip` olarak güncellendi.
- Sürüm `versionCode 46` / `versionName 46.0` yapıldı.
