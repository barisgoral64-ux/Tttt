package com.example.bodytracker.util

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

enum class ReferenceLevel { LOW, NORMAL, HIGH, INFO }

data class ReferenceStatus(
    val rangeLabel: String,
    val statusText: String,
    val level: ReferenceLevel,
    val detail: String = ""
)

private val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
private val dateTimeFormat = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())

fun formatDate(millis: Long): String = dateFormat.format(Date(millis))
fun formatDateTime(millis: Long): String = dateTimeFormat.format(Date(millis))

fun combineDateAndTime(dateMillis: Long, hour: Int, minute: Int): Long {
    val cal = Calendar.getInstance().apply { timeInMillis = dateMillis }
    cal.set(Calendar.HOUR_OF_DAY, hour.coerceIn(0, 23))
    cal.set(Calendar.MINUTE, minute.coerceIn(0, 59))
    cal.set(Calendar.SECOND, 0)
    cal.set(Calendar.MILLISECOND, 0)
    return cal.timeInMillis
}

fun calculateAge(birthMillis: Long): Int {
    val birth = Calendar.getInstance().apply { timeInMillis = birthMillis }
    val today = Calendar.getInstance()
    var age = today.get(Calendar.YEAR) - birth.get(Calendar.YEAR)
    if (today.get(Calendar.DAY_OF_YEAR) < birth.get(Calendar.DAY_OF_YEAR)) age--
    return age.coerceAtLeast(0)
}

fun calculateBmi(weightKg: Double, heightCm: Int): Double {
    val heightM = heightCm / 100.0
    return if (heightM > 0) weightKg / (heightM * heightM) else 0.0
}

fun Double.oneDecimal(): String = String.format(Locale.getDefault(), "%.1f", this)

fun deltaText(current: Double, previous: Double, unit: String): String {
    val delta = current - previous
    val sign = if (delta > 0) "+" else ""
    return "$sign${String.format(Locale.getDefault(), "%.1f", delta)} $unit"
}

fun metabolicAgeHint(age: Int, bmi: Double): Int = (age + (bmi - 21.0).roundToInt()).coerceAtLeast(1)

private fun statusForRange(value: Double, min: Double, max: Double, detail: String = ""): ReferenceStatus = when {
    value < min -> ReferenceStatus("${min.oneDecimal()} - ${max.oneDecimal()}", "Referans aralığının altında", ReferenceLevel.LOW, detail)
    value > max -> ReferenceStatus("${min.oneDecimal()} - ${max.oneDecimal()}", "Referans aralığının üstünde", ReferenceLevel.HIGH, detail)
    else -> ReferenceStatus("${min.oneDecimal()} - ${max.oneDecimal()}", "Referans aralığında", ReferenceLevel.NORMAL, detail)
}

fun bmiReferenceStatus(bmi: Double): ReferenceStatus = when {
    bmi < 18.5 -> ReferenceStatus("18.5 - 24.9", "Referans aralığının altında", ReferenceLevel.LOW, "Düşük kilo sınıfında")
    bmi <= 24.9 -> ReferenceStatus("18.5 - 24.9", "Referans aralığında", ReferenceLevel.NORMAL, "Normal VKİ aralığında")
    bmi <= 29.9 -> ReferenceStatus("18.5 - 24.9", "Referans aralığının üstünde", ReferenceLevel.HIGH, "Fazla kilolu sınıfında")
    else -> ReferenceStatus("18.5 - 24.9", "Referans aralığının üstünde", ReferenceLevel.HIGH, "Obezite sınıfında")
}

fun weightReferenceStatus(weightKg: Double, heightCm: Int): ReferenceStatus {
    val h = heightCm / 100.0
    val min = 18.5 * h * h
    val max = 24.9 * h * h
    return statusForRange(weightKg, min, max, "Boy bilgisine göre hedef kilo aralığı")
}

fun bodyFatReferenceStatus(gender: String, age: Int, value: Double): ReferenceStatus {
    val (min, max) = if (gender == "Kadın") {
        when {
            age < 40 -> 21.0 to 33.0
            age < 60 -> 23.0 to 34.0
            else -> 24.0 to 36.0
        }
    } else {
        when {
            age < 40 -> 8.0 to 20.0
            age < 60 -> 11.0 to 22.0
            else -> 13.0 to 25.0
        }
    }
    return statusForRange(value, min, max, "Yaş ve cinsiyete göre genel yağ oranı aralığı")
}

fun bodyWaterReferenceStatus(gender: String, value: Double): ReferenceStatus {
    val (min, max) = if (gender == "Kadın") 45.0 to 60.0 else 50.0 to 65.0
    return statusForRange(value, min, max, "Düşük su oranı ölçüm saatine göre değişebilir")
}

fun visceralFatReferenceStatus(value: Double): ReferenceStatus = when {
    value < 1.0 -> ReferenceStatus("1.0 - 12.0", "Referans aralığının altında", ReferenceLevel.LOW, "Cihaz ölçeği alt sınırında")
    value <= 12.0 -> ReferenceStatus("1.0 - 12.0", "Referans aralığında", ReferenceLevel.NORMAL, "Normal iç yağ seviyesi")
    else -> ReferenceStatus("1.0 - 12.0", "Referans aralığının üstünde", ReferenceLevel.HIGH, "İç yağ seviyesi yüksek")
}

fun metabolicAgeReferenceStatus(actualAge: Int, metabolicAge: Int): ReferenceStatus = when {
    metabolicAge < actualAge -> ReferenceStatus("Gerçek yaş: $actualAge", "Gerçek yaşın altında", ReferenceLevel.NORMAL, "Olumlu metabolik yaş görünümü")
    metabolicAge == actualAge -> ReferenceStatus("Gerçek yaş: $actualAge", "Gerçek yaş ile uyumlu", ReferenceLevel.NORMAL, "Beklenen aralıkta")
    else -> ReferenceStatus("Gerçek yaş: $actualAge", "Gerçek yaşın üstünde", ReferenceLevel.HIGH, "Yaşam tarzı takibi önerilir")
}

fun metabolicRateReferenceStatus(gender: String, age: Int, heightCm: Int, weightKg: Double, metabolicRate: Double): ReferenceStatus {
    val expected = if (gender == "Kadın") {
        10 * weightKg + 6.25 * heightCm - 5 * age - 161
    } else {
        10 * weightKg + 6.25 * heightCm - 5 * age + 5
    }
    val min = expected * 0.9
    val max = expected * 1.1
    return statusForRange(metabolicRate, min, max, "Tahmini BMR ile ±%10 karşılaştırma")
}

fun muscleReferenceStatus(gender: String, value: Double): ReferenceStatus {
    val (min, max) = if (gender == "Kadın") 25.0 to 40.0 else 33.0 to 50.0
    return statusForRange(value, min, max, "Genel takip aralığı; cihaz tipine göre değişebilir")
}

fun activityReferenceStatus(value: Double): ReferenceStatus = when {
    value < 3.0 -> ReferenceStatus("3.0 - 7.0", "Referans aralığının altında", ReferenceLevel.LOW, "Aktivite puanı düşük")
    value <= 7.0 -> ReferenceStatus("3.0 - 7.0", "Referans aralığında", ReferenceLevel.NORMAL, "Aktivite dengeli")
    else -> ReferenceStatus("3.0 - 7.0", "Referans aralığının üstünde", ReferenceLevel.INFO, "Aktivite seviyesi yüksek")
}

fun boneReferenceStatus(gender: String, value: Double): ReferenceStatus {
    val (min, max) = if (gender == "Kadın") 2.0 to 3.2 else 2.5 to 4.0
    return statusForRange(value, min, max, "Genel cihaz referansı")
}
