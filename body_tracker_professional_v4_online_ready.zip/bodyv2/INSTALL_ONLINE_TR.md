# Online APK Olusturma (GitHub Actions)

Bu paket, GitHub'a yuklendikten sonra Android debug APK uretmek icin hazirlanmistir.

## 1) GitHub repo olustur
- GitHub'da yeni bir repo olustur.
- Repo bos olsun.

## 2) Dosyalari yukle
- Bu klasordeki tum dosyalari GitHub reposuna yukle.
- Ozellikle `.github/workflows/build-apk.yml` dosyasinin oldugundan emin ol.

## 3) APK build calistir
- GitHub repo icinde `Actions` sekmesine gir.
- `Build APK` workflow'unu sec.
- `Run workflow` dugmesine bas.

## 4) APK indir
- Build bittiginde ilgili calismayi ac.
- `Artifacts` bolumunden `body-tracker-debug-apk` dosyasini indir.
- ZIP icinden `app-debug.apk` cikacaktir.

## Notlar
- Bu APK `debug` APK'dir.
- Telefona kurarken Android bilinmeyen uygulama izni isteyebilir.
- WhatsApp paylasimi icin telefonda WhatsApp kurulu olmali.
