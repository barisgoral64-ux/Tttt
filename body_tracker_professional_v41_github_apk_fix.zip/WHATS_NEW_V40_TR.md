# V40 Tam Takip Platformu

- Danışman Notları / Karar Günlüğü eklendi.
- Günlük uyum takibi ve uyum yüzdesi eklendi.
- Plan kalite skoru ve otomatik danışan takip durumu eklendi.
- Yağ/kilo, sıvı düşük, kas düşük ve iç yağ/bel takibi için profesyonel plan şablonları eklendi.
- Akıllı plan ekranı tek dashboard ile sınırlı kalmayacak şekilde şablon, uyum, karar günlüğü ve stok uyarılarıyla genişletildi.
- Room veritabanı 13. sürüme taşındı; mevcut eski veriler migration ile korunur.
- GitHub Actions build workflow v40 zip adına ve güvenli build log yüklemeye göre düzeltildi.
- Sürüm `versionCode 40` / `versionName 40.0` yapıldı.
