# V43 SDK Lisans Pipefix

- GitHub Actions Android lisans kabul adımı düzeltildi.
- `yes | sdkmanager --licenses` komutu lisansları kabul ettikten sonra `pipefail` yüzünden job'u düşürmez.
- Android platform ve build-tools kurulumu hata kontrolüyle devam eder.
- Workflow zip adı `body_tracker_professional_v43_sdk_license_pipefix.zip` olarak güncellendi.
- Sürüm `versionCode 43` / `versionName 43.0` yapıldı.
