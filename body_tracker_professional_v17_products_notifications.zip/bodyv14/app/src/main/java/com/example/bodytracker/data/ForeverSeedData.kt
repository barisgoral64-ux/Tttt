package com.example.bodytracker.data

internal data class SeedCategory(
    val name: String,
    val iconName: String,
    val sortOrder: Int
)

internal data class SeedProduct(
    val name: String,
    val category: String,
    val description: String,
    val usageNote: String,
    val defaultDose: String,
    val timing: String,
    val sourceUrl: String,
    val imageUrl: String = ""
)

internal object ForeverSeedData {
    val categories = listOf(
        SeedCategory("Aloe İçecekleri", "local_drink", 1),
        SeedCategory("Vitamin ve Mineraller", "health_and_safety", 2),
        SeedCategory("Sindirim ve Lif", "spa", 3),
        SeedCategory("Performans ve Aktif Yaşam", "fitness_center", 4),
        SeedCategory("Kilo Yönetimi", "monitor_weight", 5),
        SeedCategory("Arı Ürünleri", "emoji_nature", 6),
        SeedCategory("Kişisel Bakım", "face", 7)
    )

    val products = listOf(
        SeedProduct(
            name = "Forever Marine Collagen",
            category = "Vitamin ve Mineraller",
            description = "Kolajen destek ürünü.",
            usageNote = "Günlük destek planına eklenebilir.",
            defaultDose = "1 porsiyon",
            timing = "Sabah / Akşam",
            sourceUrl = "https://flptr.com/e-shop/4717-forever-marine-collagen"
        ),
        SeedProduct(
            name = "Forever Aloe Mango",
            category = "Aloe İçecekleri",
            description = "Mango aromalı aloe içecek ürünü.",
            usageNote = "Sabah veya ara öğünde planlanabilir.",
            defaultDose = "1 porsiyon",
            timing = "Sabah / Ara öğün",
            sourceUrl = "https://flptr.com/e-shop/4373-forever-aloe-mango"
        ),
        SeedProduct(
            name = "Forever Aloe Vera Juice",
            category = "Aloe İçecekleri",
            description = "Aloe vera içecek ürünü.",
            usageNote = "Günlük plan içinde içecek desteği olarak kullanılabilir.",
            defaultDose = "1 porsiyon",
            timing = "Sabah",
            sourceUrl = "https://flptr.com/e-shop"
        ),
        SeedProduct(
            name = "Forever Freedom",
            category = "Performans ve Aktif Yaşam",
            description = "Aktif yaşam desteği ürünü.",
            usageNote = "Hareket ve eklem odaklı planlarda değerlendirilebilir.",
            defaultDose = "1 porsiyon",
            timing = "Sabah / Akşam",
            sourceUrl = "https://flptr.com/e-shop"
        ),
        SeedProduct(
            name = "Forever ImmuBlend",
            category = "Vitamin ve Mineraller",
            description = "Bitki ve vitamin içeren destek ürünü.",
            usageNote = "Bağışıklık odaklı plan notlarına eklenebilir.",
            defaultDose = "1 tablet",
            timing = "Sabah",
            sourceUrl = "https://flptr.com/e-shop"
        ),
        SeedProduct(
            name = "F15 Vanilla",
            category = "Kilo Yönetimi",
            description = "Kilo yönetimi programlarında kullanılabilen öğün destek ürünü.",
            usageNote = "Plan hedefiyle uyumlu şekilde öğün yerine yazılabilir.",
            defaultDose = "1 porsiyon",
            timing = "Ara öğün",
            sourceUrl = "https://flptr.com/e-shop"
        ),
        SeedProduct(
            name = "F15 Chocolate",
            category = "Kilo Yönetimi",
            description = "Çikolata aromalı öğün destek ürünü.",
            usageNote = "Ara öğün veya kontrollü öğün yerine kullanılabilir.",
            defaultDose = "1 porsiyon",
            timing = "Ara öğün",
            sourceUrl = "https://flptr.com/e-shop"
        ),
        SeedProduct(
            name = "Forever Aloe Vera Gel",
            category = "Aloe İçecekleri",
            description = "Aloe vera bazlı içecek ürünü.",
            usageNote = "Kişisel plana göre kullanılacak içecek ürünü olarak listelenir.",
            defaultDose = "1 porsiyon",
            timing = "Sabah",
            sourceUrl = "https://flptr.com/e-shop"
        ),
        SeedProduct(
            name = "Forever Aloe Berry Nectar",
            category = "Aloe İçecekleri",
            description = "Aloe vera ve meyve aromalı içecek ürünü.",
            usageNote = "Diyet listesinde içecek seçeneği olarak gösterilir.",
            defaultDose = "1 porsiyon",
            timing = "Sabah / Ara öğün",
            sourceUrl = "https://flptr.com/e-shop"
        ),
        SeedProduct(
            name = "Forever Aloe Peaches",
            category = "Aloe İçecekleri",
            description = "Şeftali aromalı aloe vera içecek ürünü.",
            usageNote = "Kullanım zamanı uzman notuna göre özelleştirilir.",
            defaultDose = "1 porsiyon",
            timing = "Sabah / Ara öğün",
            sourceUrl = "https://flptr.com/e-shop"
        ),
        SeedProduct(
            name = "Forever Daily",
            category = "Vitamin ve Mineraller",
            description = "Vitamin ve mineral içeren günlük destek ürünü.",
            usageNote = "Uzman planına göre günlük destek alanında kullanılır.",
            defaultDose = "1 tablet",
            timing = "Kahvaltı sonrası",
            sourceUrl = "https://flptr.com/e-shop"
        ),
        SeedProduct(
            name = "Forever Absorbent-C",
            category = "Vitamin ve Mineraller",
            description = "C vitamini içeren destek ürünü.",
            usageNote = "Plan notuna göre günlük takviye alanında gösterilir.",
            defaultDose = "1 tablet",
            timing = "Öğün sonrası",
            sourceUrl = "https://flptr.com/e-shop"
        ),
        SeedProduct(
            name = "Forever Arctic Sea",
            category = "Vitamin ve Mineraller",
            description = "Yağ asidi içeren destek ürünü.",
            usageNote = "Takviye planında öğünle birlikte kullanılacak ürün olarak seçilir.",
            defaultDose = "1 softgel",
            timing = "Öğün ile birlikte",
            sourceUrl = "https://flptr.com/e-shop"
        ),
        SeedProduct(
            name = "Forever Fiber",
            category = "Sindirim ve Lif",
            description = "Lif içeren destek ürünü.",
            usageNote = "Sıvı tüketim notu ile birlikte planlanması önerilir.",
            defaultDose = "1 saşe",
            timing = "Ara öğün / Akşam",
            sourceUrl = "https://flptr.com/e-shop"
        ),
        SeedProduct(
            name = "Active Pro-B",
            category = "Sindirim ve Lif",
            description = "Probiyotik destek ürünü.",
            usageNote = "Kişisel plana göre sindirim desteği bölümünde kullanılır.",
            defaultDose = "1 kapsül",
            timing = "Sabah",
            sourceUrl = "https://flptr.com/e-shop"
        ),
        SeedProduct(
            name = "Forever Bee Propolis",
            category = "Arı Ürünleri",
            description = "Propolis içeren destek ürünü.",
            usageNote = "Arı ürünü hassasiyeti olanlarda dikkat notu eklenmelidir.",
            defaultDose = "1 tablet",
            timing = "Öğün sonrası",
            sourceUrl = "https://foreverliving.com/shop/usa/en-us/products/bee-products/027-Forever-Bee-Propolis"
        ),
        SeedProduct(
            name = "Forever Garlic-Thyme",
            category = "Vitamin ve Mineraller",
            description = "Sarımsak ve kekik içeren destek ürünü.",
            usageNote = "Uzman önerisine göre günlük plan alanında kullanılabilir.",
            defaultDose = "1 softgel",
            timing = "Öğün ile birlikte",
            sourceUrl = "https://flptr.com/e-shop"
        ),
        SeedProduct(
            name = "Forever Focus",
            category = "Performans ve Aktif Yaşam",
            description = "Aktif yaşam odaklı destek ürünü.",
            usageNote = "Günlük rutin veya çalışma döneminde planlanabilir.",
            defaultDose = "1 tablet",
            timing = "Sabah",
            sourceUrl = "https://flptr.com/e-shop"
        ),
        SeedProduct(
            name = "Forever Move",
            category = "Performans ve Aktif Yaşam",
            description = "Aktif yaşam rutinlerinde kullanılan destek ürünü.",
            usageNote = "Egzersiz ve hareket planı notu ile birlikte yazılabilir.",
            defaultDose = "1 tablet",
            timing = "Sabah / Akşam",
            sourceUrl = "https://flptr.com/e-shop"
        ),
        SeedProduct(
            name = "Forever Argi+",
            category = "Performans ve Aktif Yaşam",
            description = "Aktif yaşam ve spor rutinlerinde tercih edilen ürün.",
            usageNote = "Antrenman veya yoğun gün planı alanına eklenebilir.",
            defaultDose = "1 saşe",
            timing = "Antrenman öncesi / Akşam",
            sourceUrl = "https://flptr.com/e-shop"
        ),
        SeedProduct(
            name = "Forever Therm",
            category = "Kilo Yönetimi",
            description = "Kilo yönetimi planlarında yer verilebilen destek ürünü.",
            usageNote = "Günlük plan içinde uzman onayıyla konumlandırılır.",
            defaultDose = "1 tablet",
            timing = "Sabah / Öğle",
            sourceUrl = "https://flptr.com/e-shop"
        ),
        SeedProduct(
            name = "Forever Garcinia Plus",
            category = "Kilo Yönetimi",
            description = "Kilo yönetimi odaklı planlarda kullanılan destek ürünü.",
            usageNote = "Takip notu ile birlikte yazılması önerilir.",
            defaultDose = "1 tablet",
            timing = "Öğün öncesi",
            sourceUrl = "https://flptr.com/e-shop"
        ),
        SeedProduct(
            name = "Lite Ultra Vanilla",
            category = "Kilo Yönetimi",
            description = "Öğün planlarında kullanılabilen shake ürünü.",
            usageNote = "Öğün yerine veya ara öğünde uzman planına göre kullanılır.",
            defaultDose = "1 ölçek",
            timing = "Ara öğün",
            sourceUrl = "https://flptr.com/e-shop"
        ),
        SeedProduct(
            name = "Lite Ultra Chocolate",
            category = "Kilo Yönetimi",
            description = "Çikolata aromalı shake ürünü.",
            usageNote = "Öğün planı ve kalori takibine göre düzenlenir.",
            defaultDose = "1 ölçek",
            timing = "Ara öğün",
            sourceUrl = "https://flptr.com/e-shop"
        ),
        SeedProduct(
            name = "Aloe Propolis Creme",
            category = "Kişisel Bakım",
            description = "Aloe ve propolis içeren kişisel bakım ürünü.",
            usageNote = "Takviye değil bakım ürünü olarak ayrı listelenir.",
            defaultDose = "Haricen",
            timing = "Günlük kullanım",
            sourceUrl = "https://foreverliving.com/shop/usa/en-us/products/skin-care/051-Aloe-Propolis-Creme"
        )
    )
}
