# V8 Yenilikleri

- Profesyonel uygulama ikonu eklendi
- Kamera akışı TakePicturePreview + izin kontrolü ile sadeleştirildi
- Kamera başarısız olursa uygulama kapanmak yerine uyarı verir
- Hakkında sayfası eklendi
- Uygulama içinde `Yapan: Barış Göral` bilgisi yer alıyor
- Renk paleti daha kurumsal hale getirildi
