# V18 - Forever Danışan Takip

Bu sürümde:
- uygulama adı `Forever Danışan Takip` olarak güncellendi
- ürün seed mantığı tekrar üretmeyecek şekilde düzenlendi
- aynı isimli yinelenen ürünler açılışta temizleniyor
- eksik ürün alanları seed veriden güncelleniyor
- veritabanı sürümü 18.0 paket sürümüne yükseltildi

Not:
- APK üstüne güncelleme için package name aynı tutuldu
- Yine de Android'in uygulamayı güncelleme olarak kabul etmesi için aynı imza ile yükleme gerekir
