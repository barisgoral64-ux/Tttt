# Body Tracker Professional v4

Bu sürümde eklenen başlıca özellikler:
- Hasta arama
- Kamera ve galeri ile profil fotoğrafı
- Erkek / Kadın seçimi
- Doğum tarihi ve ölçüm tarihi için modern gg/aa/yyyy tarih seçici
- Otomatik VKİ hesaplama
- Diyet listesi oluşturma
- WhatsApp ve genel paylaşım
- PDF rapor üretimi ve paylaşımı
- Ölçüm düzenleme ve silme
- Basit trend grafiği
- Randevu / kontrol takibi

Not: Bu paket kaynak projedir. Android Studio veya online build ile APK oluşturulur.
