# V44 Kotlin Compile Fix

- GitHub build logunda görülen Kotlin compile hataları düzeltildi.
- Material3 `ElevatedCard` için desteklenmeyen `border` parametreleri kaldırıldı.
- `DietPlanProductEntity` import eksikleri giderildi.
- Takviye stok metni nullable güvenli hale getirildi.
- Workflow zip adı `body_tracker_professional_v44_kotlin_compile_fix.zip` olarak güncellendi.
- Sürüm `versionCode 44` / `versionName 44.0` yapıldı.
