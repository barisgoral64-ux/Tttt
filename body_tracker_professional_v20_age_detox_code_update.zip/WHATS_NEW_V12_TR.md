# V12 - Ürün Veritabanı Başlangıcı

Bu sürümde ürün ve diyet planı için veritabanı altyapısı eklendi.

Eklenenler:
- ürün kategori tablosu
- ürün tablosu
- diyet planı tablosu
- diyet planı ürün eşleştirme tablosu
- Room DAO katmanı
- repository katmanı

Bu aşamada amaç, Forever ürünleri daha sonra toplu veya tek tek ekleyebileceğimiz sağlam bir katalog tabanı oluşturmaktır.


## V13
- Forever başlangıç ürün kataloğu eklendi
- Ürün kategorileri otomatik seed olarak veritabanına yazılıyor
- Ürünlerde kaynak link alanı eklendi
- Diyet/takviye modülü için hazır başlangıç veri seti oluşturuldu
