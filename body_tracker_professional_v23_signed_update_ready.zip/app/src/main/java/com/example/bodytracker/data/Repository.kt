package com.example.bodytracker.data

import kotlinx.coroutines.flow.Flow

class BodyTrackerRepository(
    private val patientDao: PatientDao,
    private val measurementDao: MeasurementDao,
    private val appointmentDao: AppointmentDao,
    private val productCategoryDao: ProductCategoryDao,
    private val productDao: ProductDao,
    private val dietPlanDao: DietPlanDao,
    private val dietPlanProductDao: DietPlanProductDao,
    private val appSettingDao: AppSettingDao
) {
    private fun deriveProductCode(productName: String, imageUrl: String): String {
        val explicitCodes = mapOf(
            "Forever Aloe Vera Gel" to "015",
            "Forever Aloe Berry Nectar" to "034",
            "Forever Aloe Bits N' Peaches" to "077",
            "Forever Aloe Mango" to "736",
            "Forever Freedom" to "196",
            "Aloe Blossom Herbal Tea" to "200",
            "Forever Fiber" to "464",
            "Forever Absorbent-D" to "672",
            "Forever Daily" to "439",
            "Forever Active Pro B" to "610",
            "Forever Calcium" to "206",
            "Arctic Sea Omega 3" to "039",
            "Nature-Min" to "037",
            "Forever iVision" to "624",
            "Forever B12 Plus" to "188",
            "Forever Lycium Plus" to "072",
            "Vitolize" to "375",
            "Forever AloeTurm" to "676",
            "Absorbent-C" to "048",
            "Forever Garlic-Thyme" to "065",
            "Forever Immune Gummy" to "566",
            "Forever ImmuBlend" to "355",
            "ARGI+" to "473",
            "Forever Marine Collagen" to "613",
            "Forever Garcinia Plus" to "071",
            "Forever Lean" to "289",
            "Forever Sensatiable" to "665",
            "Forever Therm" to "463",
            "C9" to "220/221",
            "Smile 5" to "456N/456S/457N/457S/458N/458S/459N/459S",
            "MY FIT" to "2021F/2021G/2021H/2021J/2021T/2021M",
            "ECO" to "013A/013B/013C/013D/013E/013F/013G/0153/0333/0343/0773/1963/7363",
            "Aloe Propolis Creme" to "051",
            "Forever Bee Honey" to "207",
            "Forever Royal Jelly" to "036",
            "Forever Bee Pollen" to "026",
            "Forever Bee Propolis" to "027",
            "Aloe Cooling Lotion" to "564",
            "Aloe Heat Lotion" to "064",
            "Aloe MSM Gel" to "205",
            "Forever Active HA" to "264",
            "Forever Nutra Q10" to "312",
            "Aloe Lips" to "022",
            "Aloe Body Lotion" to "647",
            "Aloe Moisturizing Lotion" to "063",
            "Aloe Sunscreen" to "617",
            "Aloe Vera Gelly" to "061",
            "Forever Aloe Scrub" to "238",
            "Gentleman's Pride" to "070",
            "Forever Bright Toothgel" to "028",
            "Aloe Avocado Face & Body Soap" to "284",
            "Aloe Body Wash" to "646",
            "Aloe First" to "040",
            "Aloe-Jojoba Shampoo" to "640",
            "Aloe-Jojoba Conditioner" to "641",
            "Aloe Liquid Soap" to "633",
            "Forever Nourishing Hair Oil" to "642",
            "Aloe Alafa Fine Fragrance" to "643",
            "Aloe Malosi Fine Fragrance" to "644",
            "Aloe Ever-Shield" to "067",
            "Sonya Refreshing Gel Cleanser" to "605",
            "Sonya Refining Gel Mask" to "607",
            "Sonya Soothing Gel Moisturizer" to "608",
            "Sonya Illuminating Gel" to "606",
            "Infinite by Forever" to "444",
            "Logic by Forever Skin Care System" to "667/668/669",
            "Infinite by Forever Hydrating Cleanser" to "554",
            "Infinite by Forever Firming Serum" to "555",
            "Infinite by Forever Restoring Creme" to "558",
            "Deep Moisturizing Cream" to "651",
            "Tightening Mask Powder" to "652",
            "Awakening Eye Cream" to "561",
            "Hydrating Serum" to "618",
            "Protecting Day Lotion" to "645",
            "Aloe Activator" to "612",
            "Forever Replenishing Skin Oil" to "653",
            "Smoothing Exfoliator" to "559",
            "Aloe Bio-Cellulose Mask" to "664",
            "Logic by Forever Aloe Gel Cleanser" to "667",
            "Logic by Forever Balancing Aloe Essence" to "668",
            "Logic by Forever Soothing Gel Moisturizer" to "669",
            "Aloe Vera Gel" to "015",
            "Aloe Berry Nectar" to "034",
            "Arctic-Sea Omega-3" to "039",
            "Forever Nature-Min" to "037",
            "Lycium Plus" to "072",
            "Aloe First Spray" to "040",
            "Aloe Ever Shield Stick Deo" to "067",
            "R-3 Factor Skin Defense Creme" to "069",
            "Forever Active PRO B" to "610",
            "Forever Lite Ultra Vanilla Flavour" to "470",
            "Forever Lite Ultra Chocolate Flavour" to "471",
            "Forever Lite Ultr Vanilla - Pouch" to "470",
            "Forever Lite Ultr Chocolate - Pouch" to "471",
            "Forever ARGI+ - Pouch" to "473",
            "Forever Leane" to "289",
            "Forever Immublend" to "355",
            "Infinite Kit" to "444",
            "Infinite Hydrating Cleanser" to "554",
            "Infinite Firming Serum" to "555",
            "Infinite Restoring Cream" to "558",
            "Forever i-VSN" to "624",
            "Nourishing Hair Oil" to "642",
            "Forever Alofa Fine Fragrance" to "643",
            "Forever Malosi Fine Fragrance" to "644",
            "Aloe Vera Gel (330 ml Pack of-3)" to "7163",
            "Aloe Berry Nectar (330 ml Pack of-3)" to "7353",
            "Forever Peaches (330 ml Pack of-3)" to "7783",
            "Aloe Vera Gel (330 ml Pack of-12)" to "71612",
            "Aloe Berry Nectar (330 ml Pack of-12)" to "73512",
            "Forever Peaches (330 ml Pack of-12)" to "77812"
        )
        val byName = explicitCodes[productName.trim()]
        if (!byName.isNullOrBlank()) return byName
        val fileName = imageUrl.substringAfterLast('/')
        return fileName.takeWhile { it.isDigit() }
    }

    fun observePatients(): Flow<List<PatientEntity>> = patientDao.observePatients()
    fun observePatient(id: Long): Flow<PatientEntity?> = patientDao.observePatient(id)
    fun observeMeasurements(patientId: Long): Flow<List<MeasurementEntity>> = measurementDao.observeMeasurements(patientId)
    fun observeMeasurement(id: Long): Flow<MeasurementEntity?> = measurementDao.observeMeasurement(id)
    fun observeAppointments(patientId: Long): Flow<List<AppointmentEntity>> = appointmentDao.observeAppointments(patientId)
    suspend fun getPatientNow(id: Long): PatientEntity? = patientDao.getPatientNow(id)
    suspend fun getFutureAppointments(nowMillis: Long): List<AppointmentEntity> = appointmentDao.getFutureAppointments(nowMillis)
    fun observeCategories(): Flow<List<ProductCategoryEntity>> = productCategoryDao.observeCategories()
    fun observeProducts(): Flow<List<ProductEntity>> = productDao.observeProducts()
    fun observeProductsByCategory(categoryId: Long): Flow<List<ProductEntity>> = productDao.observeProductsByCategory(categoryId)
    fun observeDietPlans(patientId: Long): Flow<List<DietPlanEntity>> = dietPlanDao.observeDietPlans(patientId)
    fun observeDietPlanProducts(dietPlanId: Long): Flow<List<DietPlanProductEntity>> = dietPlanProductDao.observeDietPlanProducts(dietPlanId)
    suspend fun getDietPlanProductsNow(dietPlanId: Long): List<DietPlanProductEntity> = dietPlanProductDao.getDietPlanProductsNow(dietPlanId)

    suspend fun addPatient(patient: PatientEntity): Long = patientDao.insert(patient)
    suspend fun updatePatient(patient: PatientEntity) = patientDao.update(patient)
    suspend fun deletePatient(patient: PatientEntity) = patientDao.delete(patient)

    suspend fun addMeasurement(measurement: MeasurementEntity): Long = measurementDao.insert(measurement)
    suspend fun updateMeasurement(measurement: MeasurementEntity) = measurementDao.update(measurement)
    suspend fun deleteMeasurement(measurement: MeasurementEntity) = measurementDao.delete(measurement)

    suspend fun addAppointment(appointment: AppointmentEntity): Long = appointmentDao.insert(appointment)
    suspend fun updateAppointment(appointment: AppointmentEntity) = appointmentDao.update(appointment)
    suspend fun deleteAppointment(appointment: AppointmentEntity) = appointmentDao.delete(appointment)

    suspend fun addCategory(category: ProductCategoryEntity): Long = productCategoryDao.insert(category)
    suspend fun updateCategory(category: ProductCategoryEntity) = productCategoryDao.update(category)
    suspend fun deleteCategory(category: ProductCategoryEntity) = productCategoryDao.delete(category)

    suspend fun addProduct(product: ProductEntity): Long = productDao.insert(product)
    suspend fun updateProduct(product: ProductEntity) = productDao.update(product)
    suspend fun deleteProduct(product: ProductEntity) = productDao.delete(product)

    suspend fun addDietPlan(dietPlan: DietPlanEntity): Long = dietPlanDao.insert(dietPlan)
    suspend fun updateDietPlan(dietPlan: DietPlanEntity) = dietPlanDao.update(dietPlan)
    suspend fun deleteDietPlan(dietPlan: DietPlanEntity) = dietPlanDao.delete(dietPlan)

    suspend fun addDietPlanProduct(item: DietPlanProductEntity): Long = dietPlanProductDao.insert(item)
    suspend fun updateDietPlanProduct(item: DietPlanProductEntity) = dietPlanProductDao.update(item)
    suspend fun deleteDietPlanProduct(item: DietPlanProductEntity) = dietPlanProductDao.delete(item)

    suspend fun updateLastBackupTimestamp(timestamp: Long) {
        appSettingDao.upsert(
            AppSettingEntity(
                key = "last_backup_ts",
                value = timestamp.toString(),
                updatedAt = timestamp
            )
        )
    }

    suspend fun getLastBackupTimestamp(): Long? =
        appSettingDao.get("last_backup_ts")?.value?.toLongOrNull()

    suspend fun ensureSeededProducts() {
        val existingCategories = productCategoryDao.getAll()
        val categoryMap = existingCategories.associateBy { it.name.trim().lowercase() }.toMutableMap()
        val categoryIdMap = mutableMapOf<String, Long>()

        ForeverSeedData.categories.forEach { category ->
            val key = category.name.trim().lowercase()
            val existing = categoryMap[key]
            val id = existing?.id ?: productCategoryDao.insert(
                ProductCategoryEntity(
                    name = category.name,
                    iconName = category.iconName,
                    sortOrder = category.sortOrder
                )
            )
            categoryIdMap[category.name] = id
        }

        val existingProducts = productDao.getAll()
        val grouped = existingProducts.groupBy { it.name.trim().lowercase() }
        grouped.values.forEach { sameNameProducts ->
            if (sameNameProducts.size > 1) {
                sameNameProducts.drop(1).forEach { duplicate ->
                    productDao.delete(duplicate)
                }
            }
        }

        val canonicalProducts = productDao.getAll().associateBy { it.name.trim().lowercase() }.toMutableMap()

        ForeverSeedData.products
            .distinctBy { it.name.trim().lowercase() }
            .forEach { product ->
                val key = product.name.trim().lowercase()
                val existing = canonicalProducts[key]
                if (existing == null) {
                    val id = productDao.insert(
                        ProductEntity(
                            name = product.name,
                            brand = "Forever",
                            categoryId = categoryIdMap[product.category],
                            imageUrl = product.imageUrl,
                            sourceUrl = product.sourceUrl,
                            description = product.description,
                            usageNote = product.usageNote,
                            defaultDose = product.defaultDose,
                            timing = product.timing,
                        code = deriveProductCode(product.name, product.imageUrl)
                        )
                    )
                    canonicalProducts[key] = ProductEntity(
                        id = id,
                        name = product.name,
                        brand = "Forever",
                        categoryId = categoryIdMap[product.category],
                        imageUrl = product.imageUrl,
                        sourceUrl = product.sourceUrl,
                        description = product.description,
                        usageNote = product.usageNote,
                        defaultDose = product.defaultDose,
                        timing = product.timing,
                        code = deriveProductCode(product.name, product.imageUrl)
                    )
                } else {
                    val updated = existing.copy(
                        categoryId = existing.categoryId ?: categoryIdMap[product.category],
                        imageUrl = if (existing.imageUrl.isBlank()) product.imageUrl else existing.imageUrl,
                        sourceUrl = if (existing.sourceUrl.isBlank()) product.sourceUrl else existing.sourceUrl,
                        description = if (existing.description.isBlank()) product.description else existing.description,
                        usageNote = if (existing.usageNote.isBlank()) product.usageNote else existing.usageNote,
                        defaultDose = if (existing.defaultDose.isBlank()) product.defaultDose else existing.defaultDose,
                        timing = if (existing.timing.isBlank()) product.timing else existing.timing,
                        code = deriveProductCode(product.name, product.imageUrl).ifBlank { existing.code },
                        updatedAt = System.currentTimeMillis()
                    )
                    if (updated != existing) productDao.update(updated)
                }
            }
    }
}
