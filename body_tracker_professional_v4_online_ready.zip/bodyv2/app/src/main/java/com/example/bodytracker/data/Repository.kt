package com.example.bodytracker.data

import kotlinx.coroutines.flow.Flow

class BodyTrackerRepository(
    private val patientDao: PatientDao,
    private val measurementDao: MeasurementDao,
    private val appointmentDao: AppointmentDao
) {
    fun observePatients(): Flow<List<PatientEntity>> = patientDao.observePatients()
    fun observePatient(id: Long): Flow<PatientEntity?> = patientDao.observePatient(id)
    fun observeMeasurements(patientId: Long): Flow<List<MeasurementEntity>> = measurementDao.observeMeasurements(patientId)
    fun observeMeasurement(id: Long): Flow<MeasurementEntity?> = measurementDao.observeMeasurement(id)
    fun observeAppointments(patientId: Long): Flow<List<AppointmentEntity>> = appointmentDao.observeAppointments(patientId)

    suspend fun addPatient(patient: PatientEntity): Long = patientDao.insert(patient)
    suspend fun addMeasurement(measurement: MeasurementEntity): Long = measurementDao.insert(measurement)
    suspend fun updateMeasurement(measurement: MeasurementEntity) = measurementDao.update(measurement)
    suspend fun deleteMeasurement(measurement: MeasurementEntity) = measurementDao.delete(measurement)
    suspend fun addAppointment(appointment: AppointmentEntity): Long = appointmentDao.insert(appointment)
    suspend fun deleteAppointment(appointment: AppointmentEntity) = appointmentDao.delete(appointment)
}
