# V4 Yenilikleri

## Klinik kullanım için eklenen modüller
- PDF diyet raporu
- Ölçüm düzenle / sil
- Kilo trend grafiği
- Randevu kayıt ve silme

## Sonraki sürüm için öneriler
- Grafik çeşitlerini artırma
- PDF içine logo ve imza alanı
- Ölçümlerde aylık otomatik kıyas
- Hasta iletişim bilgileri
- Yedekleme / dışa aktarma
