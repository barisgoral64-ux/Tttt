# V23 - Kurumsal Menü ve Bildirim Sağlamlaştırma

- Ana ekrandaki hızlı işlem kartları artık sadece danışan detayına götürmek yerine ilgili işleme doğrudan gider.
  - Vücut Analizi: son danışan için ölçüm ekleme ekranını açar.
  - Takviye Planı: son danışanın takviye planına gider.
  - Randevu Oluştur: son danışanın randevu ekranını açar.
- Bildirimden uygulama açıldığında doğrudan ilgili danışanın randevu ekranına yönlenir.
- Android 13+ bildirim izni kapalıysa randevu alarmı uygulamayı çökertmeden güvenli şekilde atlanır ve loglanır.
- Bildirim aksiyonundaki “Tamamlandı” ifadesi “Kapat” olarak değiştirildi; yanlışlıkla randevu kaydı siliniyor algısı engellendi.
- Menü/akış değerlendirme notları güncellendi.
