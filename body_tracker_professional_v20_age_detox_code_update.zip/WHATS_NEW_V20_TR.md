# v20
- Randevu bildirimleri için Android 13+ bildirim izni akışı eklendi.
- Android 12+ kesin alarm izni yönlendirmesi eklendi.
- Bildirimden hasta detayına açılış desteği eklendi.
- release imzası ve package korunarak güncelleme zinciri korunur.
