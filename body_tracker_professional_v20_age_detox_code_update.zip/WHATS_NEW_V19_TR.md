Forever Danışan Takip v19

- Ürün kataloğu 2025/2026 PDF görselleriyle yerel olarak eklendi.
- Seed ürün listesi katalogdan türetildi ve tekrar eden kayıtların güncellenmesi iyileştirildi.
- Uygulama release imzası projeye eklendi.
- GitHub Actions workflow artık signed release APK üretir.

Önemli:
- Telefonda daha önce farklı imzalı bir debug/release sürüm kuruluysa, ilk kez v19'a geçerken eski uygulamayı kaldırman gerekebilir.
- V19'dan sonra aynı repo ve aynı workflow ile alınan yeni release APK'lar birbirinin üstüne güncellenebilir.
