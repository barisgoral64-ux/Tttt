package com.example.bodytracker

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Female
import androidx.compose.material.icons.filled.Man
import androidx.compose.material.icons.filled.MonitorWeight
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.QueryStats
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SmallTopAppBar
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.compose.runtime.collectAsState
import coil.compose.AsyncImage
import com.example.bodytracker.data.AppDatabase
import com.example.bodytracker.data.AppointmentEntity
import com.example.bodytracker.data.BodyTrackerRepository
import com.example.bodytracker.data.MeasurementEntity
import com.example.bodytracker.data.PatientEntity
import com.example.bodytracker.ui.theme.BodyTrackerTheme
import com.example.bodytracker.util.calculateAge
import com.example.bodytracker.util.calculateBmi
import com.example.bodytracker.util.deltaText
import com.example.bodytracker.util.formatDate
import com.example.bodytracker.util.metabolicAgeHint
import com.example.bodytracker.util.oneDecimal
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream

sealed interface Screen {
    data object Patients : Screen
    data object AddPatient : Screen
    data object About : Screen
    data class Detail(val patientId: Long) : Screen
    data class AddMeasurement(val patientId: Long, val measurementId: Long? = null) : Screen
    data class DietPlan(val patientId: Long) : Screen
    data class Appointments(val patientId: Long) : Screen
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = AppDatabase.get(this)
        val repo = BodyTrackerRepository(db.patientDao(), db.measurementDao(), db.appointmentDao())
        setContent {
            BodyTrackerTheme {
                BodyTrackerApp(repo)
            }
        }
    }
}

@Composable
fun BodyTrackerApp(repo: BodyTrackerRepository) {
    var screen by remember { mutableStateOf<Screen>(Screen.Patients) }
    when (val s = screen) {
        Screen.Patients -> PatientsScreen(repo, onAdd = { screen = Screen.AddPatient }, onAbout = { screen = Screen.About }, onOpen = { screen = Screen.Detail(it) })
        Screen.AddPatient -> AddPatientScreen(repo, onBack = { screen = Screen.Patients }, onSaved = { screen = Screen.Detail(it) })
        Screen.About -> AboutScreen(onBack = { screen = Screen.Patients })
        is Screen.Detail -> PatientDetailScreen(
            repo = repo,
            patientId = s.patientId,
            onBack = { screen = Screen.Patients },
            onAddMeasurement = { screen = Screen.AddMeasurement(s.patientId) },
            onEditMeasurement = { screen = Screen.AddMeasurement(s.patientId, it) },
            onOpenDietPlan = { screen = Screen.DietPlan(s.patientId) },
            onOpenAppointments = { screen = Screen.Appointments(s.patientId) }
        )
        is Screen.AddMeasurement -> AddMeasurementScreen(repo, s.patientId, s.measurementId, onBack = { screen = Screen.Detail(s.patientId) }, onSaved = { screen = Screen.Detail(s.patientId) })
        is Screen.DietPlan -> DietPlanScreen(repo, s.patientId, onBack = { screen = Screen.Detail(s.patientId) })
        is Screen.Appointments -> AppointmentsScreen(repo, s.patientId, onBack = { screen = Screen.Detail(s.patientId) })
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PatientsScreen(repo: BodyTrackerRepository, onAdd: () -> Unit, onAbout: () -> Unit, onOpen: (Long) -> Unit) {
    val scope = rememberCoroutineScope()
    val patients by repo.observePatients().collectAsState(initial = emptyList())
    var query by rememberSaveable { mutableStateOf("") }
    val filtered = remember(patients, query) {
        val q = query.trim().lowercase()
        if (q.isBlank()) patients else patients.filter { (it.firstName + " " + it.lastName).lowercase().contains(q) }
    }

    Scaffold(
        topBar = {
            SmallTopAppBar(
                title = { Text("Vücut Analiz Takip Pro") },
                actions = { IconButton(onClick = onAbout) { Icon(Icons.Default.Info, contentDescription = "Hakkında") } }
            )
        },
        floatingActionButton = { FloatingActionButton(onClick = onAdd) { Icon(Icons.Default.Add, null) } }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Profesyonel hasta takip sistemi", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text("Kamera, arama, randevu, diyet planı, PDF rapor, grafik ve ölçüm kıyas özellikleri eklendi.")
                    }
                }
            }
            item {
                OutlinedTextField(query, { query = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Hasta ara") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true)
            }
            items(filtered) { patient ->
                Card(modifier = Modifier.clickable { onOpen(patient.id) }) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("${patient.firstName} ${patient.lastName}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(selected = true, onClick = {}, label = { Text(patient.gender) }, leadingIcon = { Icon(if (patient.gender == "Erkek") Icons.Default.Man else Icons.Default.Female, null) })
                            FilterChip(selected = true, onClick = {}, label = { Text("${calculateAge(patient.birthDateMillis)} yaş") }, leadingIcon = { Icon(Icons.Default.Person, null) })
                            FilterChip(selected = true, onClick = {}, label = { Text("${patient.heightCm} cm") }, leadingIcon = { Icon(Icons.Default.MonitorWeight, null) })
                        }
                        Text("Doğum Tarihi: ${formatDate(patient.birthDateMillis)}")
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddPatientScreen(repo: BodyTrackerRepository, onBack: () -> Unit, onSaved: (Long) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var firstName by rememberSaveable { mutableStateOf("") }
    var lastName by rememberSaveable { mutableStateOf("") }
    var gender by rememberSaveable { mutableStateOf("Erkek") }
    var heightText by rememberSaveable { mutableStateOf("") }
    var birthDate by rememberSaveable { mutableStateOf(System.currentTimeMillis()) }
    var showDatePicker by remember { mutableStateOf(false) }
    var photoUri by rememberSaveable { mutableStateOf<String?>(null) }

    val previewLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicturePreview()) { bitmap ->
        if (bitmap != null) {
            photoUri = saveBitmapToCache(context, bitmap)?.toString()
        } else {
            Toast.makeText(context, "Kamera görüntüsü alınamadı", Toast.LENGTH_SHORT).show()
        }
    }
    val cameraPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            try {
                previewLauncher.launch(null)
            } catch (_: Exception) {
                Toast.makeText(context, "Kamera açılamadı", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(context, "Kamera izni verilmedi", Toast.LENGTH_SHORT).show()
        }
    }
    val galleryLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> photoUri = uri?.toString() }

    if (showDatePicker) {
        ModernDatePicker(initial = birthDate, title = "Doğum tarihi seç", onDismiss = { showDatePicker = false }) {
            birthDate = it
            showDatePicker = false
        }
    }

    Scaffold(topBar = { SmallTopAppBar(title = { Text("Yeni Hasta") }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) } }) }) { padding ->
        LazyColumn(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                PatientPhotoCard(photoUri, onCamera = {
                    val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == android.content.pm.PackageManager.PERMISSION_GRANTED
                    if (granted) {
                        try {
                            previewLauncher.launch(null)
                        } catch (_: Exception) {
                            Toast.makeText(context, "Kamera açılamadı", Toast.LENGTH_SHORT).show()
                        }
                    } else {
                        cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                    }
                }, onGallery = { galleryLauncher.launch("image/*") })
            }
            item { OutlinedTextField(firstName, { firstName = it }, Modifier.fillMaxWidth(), label = { Text("Ad") }, leadingIcon = { Icon(Icons.Default.Person, null) }) }
            item { OutlinedTextField(lastName, { lastName = it }, Modifier.fillMaxWidth(), label = { Text("Soyad") }, leadingIcon = { Icon(Icons.Default.Person, null) }) }
            item { DateField("Doğum Tarihi", formatDate(birthDate)) { showDatePicker = true } }
            item {
                Text("Cinsiyet", style = MaterialTheme.typography.titleMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = gender == "Erkek", onClick = { gender = "Erkek" }, label = { Text("Erkek") }, leadingIcon = { Icon(Icons.Default.Man, null) })
                    FilterChip(selected = gender == "Kadın", onClick = { gender = "Kadın" }, label = { Text("Kadın") }, leadingIcon = { Icon(Icons.Default.Female, null) })
                }
            }
            item { OutlinedTextField(heightText, { heightText = it.filter(Char::isDigit) }, Modifier.fillMaxWidth(), label = { Text("Boy (cm)") }, leadingIcon = { Icon(Icons.Default.MonitorWeight, null) }) }
            item {
                Button(onClick = {
                    val height = heightText.toIntOrNull() ?: 0
                    if (firstName.isNotBlank() && lastName.isNotBlank() && height > 0) {
                        scope.launch {
                            val id = repo.addPatient(PatientEntity(firstName = firstName.trim(), lastName = lastName.trim(), birthDateMillis = birthDate, gender = gender, heightCm = height, photoUri = photoUri))
                            onSaved(id)
                        }
                    }
                }, modifier = Modifier.fillMaxWidth()) { Text("Hastayı Kaydet") }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PatientDetailScreen(
    repo: BodyTrackerRepository,
    patientId: Long,
    onBack: () -> Unit,
    onAddMeasurement: () -> Unit,
    onEditMeasurement: (Long) -> Unit,
    onOpenDietPlan: () -> Unit,
    onOpenAppointments: () -> Unit
) {
    val scope = rememberCoroutineScope()
    val patient by repo.observePatient(patientId).collectAsState(initial = null)
    val measurements by repo.observeMeasurements(patientId).collectAsState(initial = emptyList())
    val latest = measurements.firstOrNull()
    val previous = measurements.getOrNull(1)

    Scaffold(
        topBar = {
            SmallTopAppBar(
                title = { Text("Hasta Detayı") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) } },
                actions = {
                    IconButton(onClick = onOpenAppointments) { Icon(Icons.Default.Event, null) }
                    IconButton(onClick = onOpenDietPlan) { Icon(Icons.Default.Description, null) }
                    IconButton(onClick = onAddMeasurement) { Icon(Icons.Default.Add, null) }
                }
            )
        }
    ) { padding ->
        val p = patient ?: return@Scaffold
        LazyColumn(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                Card {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("${p.firstName} ${p.lastName}", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        Text("${p.gender} • ${calculateAge(p.birthDateMillis)} yaş • ${p.heightCm} cm")
                        Text("Doğum Tarihi: ${formatDate(p.birthDateMillis)}")
                    }
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                    QuickActionCard("Diyet", Icons.Default.Description, Modifier.weight(1f), onOpenDietPlan)
                    QuickActionCard("Randevu", Icons.Default.Event, Modifier.weight(1f), onOpenAppointments)
                }
            }
            if (latest != null) {
                item { ComparisonOverview(latest, previous) }
                item { MetricGrid(latest) }
                item { TrendChartCard(measurements) }
            }
            item { Text("Ölçüm Geçmişi", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
            items(measurements) { m ->
                Card {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text(formatDate(m.dateMillis), fontWeight = FontWeight.SemiBold)
                            Row {
                                IconButton(onClick = { onEditMeasurement(m.id) }) { Icon(Icons.Default.Edit, null) }
                                IconButton(onClick = { scope.launch { repo.deleteMeasurement(m) } }) { Icon(Icons.Default.Delete, null) }
                            }
                        }
                        Text("Kilo: ${m.weightKg.oneDecimal()} kg  •  VKİ: ${m.bmi.oneDecimal()}")
                        Text("Yağ: ${m.bodyFatPercent.oneDecimal()}%  •  Sıvı: ${m.bodyWaterPercent.oneDecimal()}%  •  Kas: ${m.muscle.oneDecimal()}")
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddMeasurementScreen(repo: BodyTrackerRepository, patientId: Long, measurementId: Long?, onBack: () -> Unit, onSaved: () -> Unit) {
    val scope = rememberCoroutineScope()
    val patient by repo.observePatient(patientId).collectAsState(initial = null)
    val existing by if (measurementId != null) {
        repo.observeMeasurement(measurementId).collectAsState(initial = null)
    } else {
        remember { mutableStateOf<MeasurementEntity?>(null) }
    }
    val p = patient ?: return

    var initialized by remember(existing?.id) { mutableStateOf(false) }
    var dateMillis by rememberSaveable { mutableStateOf(System.currentTimeMillis()) }
    var showDatePicker by remember { mutableStateOf(false) }
    var weightText by rememberSaveable { mutableStateOf("") }
    var fatText by rememberSaveable { mutableStateOf("") }
    var waterText by rememberSaveable { mutableStateOf("") }
    var muscleText by rememberSaveable { mutableStateOf("") }
    var activityText by rememberSaveable { mutableStateOf("") }
    var boneText by rememberSaveable { mutableStateOf("") }
    var rateText by rememberSaveable { mutableStateOf("") }
    var metabolicAgeText by rememberSaveable { mutableStateOf("") }
    var visceralText by rememberSaveable { mutableStateOf("") }

    val existingMeasurement = existing
    if (existingMeasurement != null && !initialized) {
        dateMillis = existingMeasurement.dateMillis
        weightText = existingMeasurement.weightKg.toString()
        fatText = existingMeasurement.bodyFatPercent.toString()
        waterText = existingMeasurement.bodyWaterPercent.toString()
        muscleText = existingMeasurement.muscle.toString()
        activityText = existingMeasurement.physicalActivity.toString()
        boneText = existingMeasurement.bone.toString()
        rateText = existingMeasurement.metabolicRate.toString()
        metabolicAgeText = existingMeasurement.metabolicAge.toString()
        visceralText = existingMeasurement.visceralFat.toString()
        initialized = true
    }

    val bmi = calculateBmi(weightText.toDoubleOrNull() ?: 0.0, p.heightCm)
    if (showDatePicker) {
        ModernDatePicker(initial = dateMillis, title = "Ölçüm tarihi seç", onDismiss = { showDatePicker = false }) {
            dateMillis = it
            showDatePicker = false
        }
    }

    Scaffold(topBar = { SmallTopAppBar(title = { Text(if (measurementId == null) "Yeni Ölçüm" else "Ölçüm Düzenle") }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) } }) }) { padding ->
        LazyColumn(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("${p.firstName} ${p.lastName}", fontWeight = FontWeight.Bold)
                        Text("Boy: ${p.heightCm} cm • Yaş: ${calculateAge(p.birthDateMillis)}")
                        Text("VKİ otomatik hesaplanır.")
                    }
                }
            }
            item { DateField("Ölçüm Tarihi", formatDate(dateMillis)) { showDatePicker = true } }
            item { NumericField("Kilo (kg)", weightText) { weightText = it } }
            item {
                ElevatedCard { Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween) { Text("Otomatik VKİ", fontWeight = FontWeight.SemiBold); Text(bmi.oneDecimal(), style = MaterialTheme.typography.titleLarge) } }
            }
            item { NumericField("Vücut Yağ Oranı (%)", fatText) { fatText = it } }
            item { NumericField("Vücut Sıvı Oranı (%)", waterText) { waterText = it } }
            item { NumericField("Kas", muscleText) { muscleText = it } }
            item { NumericField("Fiziksel Aktivite", activityText) { activityText = it } }
            item { NumericField("Kemik", boneText) { boneText = it } }
            item { NumericField("Metabolizma Hızı", rateText) { rateText = it } }
            item { NumericField("Metabolizma Yaşı", metabolicAgeText) { metabolicAgeText = it } }
            item { NumericField("İç Yağ", visceralText) { visceralText = it } }
            item {
                Button(onClick = {
                    val weight = weightText.toDoubleOrNull() ?: 0.0
                    if (weight > 0) {
                        val entity = MeasurementEntity(
                            id = existing?.id ?: 0,
                            patientId = patientId,
                            dateMillis = dateMillis,
                            weightKg = weight,
                            bmi = bmi,
                            bodyFatPercent = fatText.toDoubleOrNull() ?: 0.0,
                            bodyWaterPercent = waterText.toDoubleOrNull() ?: 0.0,
                            muscle = muscleText.toDoubleOrNull() ?: 0.0,
                            physicalActivity = activityText.toDoubleOrNull() ?: 0.0,
                            bone = boneText.toDoubleOrNull() ?: 0.0,
                            metabolicRate = rateText.toDoubleOrNull() ?: 0.0,
                            metabolicAge = metabolicAgeText.toIntOrNull() ?: metabolicAgeHint(calculateAge(p.birthDateMillis), bmi),
                            visceralFat = visceralText.toDoubleOrNull() ?: 0.0
                        )
                        scope.launch {
                            if (existing == null) repo.addMeasurement(entity) else repo.updateMeasurement(entity)
                            onSaved()
                        }
                    }
                }, modifier = Modifier.fillMaxWidth()) { Text(if (measurementId == null) "Ölçümü Kaydet" else "Değişiklikleri Kaydet") }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppointmentsScreen(repo: BodyTrackerRepository, patientId: Long, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    val patient by repo.observePatient(patientId).collectAsState(initial = null)
    val appointments by repo.observeAppointments(patientId).collectAsState(initial = emptyList())
    val p = patient ?: return
    var title by rememberSaveable { mutableStateOf("") }
    var note by rememberSaveable { mutableStateOf("") }
    var dateMillis by rememberSaveable { mutableStateOf(System.currentTimeMillis()) }
    var showDatePicker by remember { mutableStateOf(false) }

    if (showDatePicker) {
        ModernDatePicker(initial = dateMillis, title = "Kontrol tarihi seç", onDismiss = { showDatePicker = false }) { dateMillis = it; showDatePicker = false }
    }

    Scaffold(topBar = { SmallTopAppBar(title = { Text("Randevu Takibi") }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) } }) }) { padding ->
        LazyColumn(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("${p.firstName} ${p.lastName}", fontWeight = FontWeight.Bold)
                        Text("Kontrol ve takip randevularını buradan yönetebilirsin.")
                    }
                }
            }
            item { OutlinedTextField(title, { title = it }, Modifier.fillMaxWidth(), label = { Text("Randevu Başlığı") }, leadingIcon = { Icon(Icons.Default.Event, null) }) }
            item { DateField("Randevu Tarihi", formatDate(dateMillis)) { showDatePicker = true } }
            item { OutlinedTextField(note, { note = it }, Modifier.fillMaxWidth().height(120.dp), label = { Text("Not") }) }
            item {
                Button(onClick = {
                    if (title.isNotBlank()) {
                        scope.launch {
                            repo.addAppointment(AppointmentEntity(patientId = patientId, dateMillis = dateMillis, title = title.trim(), note = note.trim()))
                            title = ""
                            note = ""
                            dateMillis = System.currentTimeMillis()
                        }
                    }
                }, modifier = Modifier.fillMaxWidth()) { Text("Randevu Kaydet") }
            }
            item { Text("Kayıtlı Randevular", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
            items(appointments) { appt ->
                Card {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Column {
                                Text(appt.title, fontWeight = FontWeight.SemiBold)
                                Text(formatDate(appt.dateMillis))
                            }
                            IconButton(onClick = { scope.launch { repo.deleteAppointment(appt) } }) { Icon(Icons.Default.Delete, null) }
                        }
                        if (appt.note.isNotBlank()) Text(appt.note)
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DietPlanScreen(repo: BodyTrackerRepository, patientId: Long, onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val patient by repo.observePatient(patientId).collectAsState(initial = null)
    val measurements by repo.observeMeasurements(patientId).collectAsState(initial = emptyList())
    val p = patient ?: return
    val latest = measurements.firstOrNull()

    var goal by rememberSaveable { mutableStateOf("Kilo Kontrolü") }
    var meals by rememberSaveable { mutableStateOf("3 ana öğün + 2 ara öğün") }
    var water by rememberSaveable { mutableStateOf("Günde 2-2.5 litre su") }
    var notes by rememberSaveable { mutableStateOf("") }
    val planText = remember(p, latest, goal, meals, water, notes) { generateDietPlanText(p, latest, goal, meals, water, notes) }

    Scaffold(topBar = { SmallTopAppBar(title = { Text("Diyet Listesi") }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) } }) }) { padding ->
        LazyColumn(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("${p.firstName} ${p.lastName}", fontWeight = FontWeight.Bold)
                        Text("Son ölçüme göre kişiselleştirilmiş plan")
                        Text(latest?.let { "Son ölçüm: ${formatDate(it.dateMillis)} • VKİ ${it.bmi.oneDecimal()}" } ?: "Henüz ölçüm yok. Plan temel profile göre hazırlanır.")
                    }
                }
            }
            item {
                Text("Hedef", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Kilo Verme", "Kilo Kontrolü", "Kas Koruma").forEach { item ->
                        FilterChip(selected = goal == item, onClick = { goal = item }, label = { Text(item) })
                    }
                }
            }
            item { OutlinedTextField(meals, { meals = it }, Modifier.fillMaxWidth(), label = { Text("Öğün Planı") }) }
            item { OutlinedTextField(water, { water = it }, Modifier.fillMaxWidth(), label = { Text("Su Tüketimi") }) }
            item { OutlinedTextField(notes, { notes = it }, Modifier.fillMaxWidth().height(140.dp), label = { Text("Diyetisyen notları") }) }
            item {
                ElevatedCard {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Hazırlanan belge", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text(planText)
                    }
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = { shareText(context, planText, p, false) }, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Default.Share, null); Spacer(Modifier.size(6.dp)); Text("Paylaş")
                    }
                    Button(onClick = { shareText(context, planText, p, true) }, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Default.Share, null); Spacer(Modifier.size(6.dp)); Text("WhatsApp")
                    }
                }
            }
            item {
                OutlinedButton(onClick = {
                    val pdf = createDietPdf(context, p, planText)
                    shareFile(context, pdf, p, "application/pdf")
                }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.PictureAsPdf, null); Spacer(Modifier.size(6.dp)); Text("PDF Oluştur ve Paylaş")
                }
            }
        }
    }
}

private fun shareText(context: Context, content: String, patient: PatientEntity, whatsappOnly: Boolean) {
    val file = File(context.cacheDir, "diyet_${patient.firstName}_${patient.lastName}.txt")
    file.writeText(content)
    val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, content)
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    try {
        if (whatsappOnly) {
            intent.setPackage("com.whatsapp")
            context.startActivity(intent)
        } else context.startActivity(Intent.createChooser(intent, "Belgeyi paylaş"))
    } catch (_: ActivityNotFoundException) {
        context.startActivity(Intent.createChooser(intent.apply { `package` = null }, "Belgeyi paylaş"))
    }
}

private fun shareFile(context: Context, file: File, patient: PatientEntity, mimeType: String) {
    val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = mimeType
        putExtra(Intent.EXTRA_STREAM, uri)
        putExtra(Intent.EXTRA_SUBJECT, "${patient.firstName} ${patient.lastName} raporu")
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(Intent.createChooser(intent, "Raporu paylaş"))
}

private fun createDietPdf(context: Context, patient: PatientEntity, content: String): File {
    val pdf = PdfDocument()
    val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
    val page = pdf.startPage(pageInfo)
    val canvas = page.canvas
    val titlePaint = Paint().apply { textSize = 20f; isFakeBoldText = true }
    val bodyPaint = Paint().apply { textSize = 12f }
    var y = 40f
    canvas.drawText("Hasta Diyet Planı", 40f, y, titlePaint)
    y += 30f
    canvas.drawText("Hasta: ${patient.firstName} ${patient.lastName}", 40f, y, bodyPaint)
    y += 20f
    canvas.drawText("Tarih: ${formatDate(System.currentTimeMillis())}", 40f, y, bodyPaint)
    y += 30f
    content.lines().forEach { line ->
        canvas.drawText(line.take(90), 40f, y, bodyPaint)
        y += 18f
        if (y > 800f) return@forEach
    }
    pdf.finishPage(page)
    val file = File(context.cacheDir, "diyet_raporu_${patient.firstName}_${patient.lastName}.pdf")
    file.outputStream().use { pdf.writeTo(it) }
    pdf.close()
    return file
}

private fun generateDietPlanText(patient: PatientEntity, latest: MeasurementEntity?, goal: String, meals: String, water: String, notes: String): String {
    val bmiLine = latest?.bmi?.oneDecimal() ?: "-"
    val weightLine = latest?.weightKg?.oneDecimal()?.plus(" kg") ?: "-"
    val fatLine = latest?.bodyFatPercent?.oneDecimal()?.plus("%") ?: "-"
    val visceralLine = latest?.visceralFat?.oneDecimal() ?: "-"
    val focus = when (goal) {
        "Kilo Verme" -> "Rafine şeker ve kızartma azaltılır, porsiyon kontrolü güçlendirilir."
        "Kas Koruma" -> "Protein dağılımı güne yayılır, ana öğünlerde kaliteli protein artırılır."
        else -> "Dengeli tabak modeli ve sürdürülebilir beslenme düzeni korunur."
    }
    return buildString {
        appendLine("HASTA DIYET LISTESI")
        appendLine("Ad Soyad: ${patient.firstName} ${patient.lastName}")
        appendLine("Tarih: ${formatDate(System.currentTimeMillis())}")
        appendLine("Doğum Tarihi: ${formatDate(patient.birthDateMillis)}")
        appendLine("Cinsiyet: ${patient.gender}")
        appendLine("Boy: ${patient.heightCm} cm")
        appendLine("Son Kilo: $weightLine")
        appendLine("VKİ: $bmiLine")
        appendLine("Vücut Yağ Oranı: $fatLine")
        appendLine("İç Yağ: $visceralLine")
        appendLine()
        appendLine("HEDEF")
        appendLine(goal)
        appendLine()
        appendLine("BESLENME PLANLARI")
        appendLine("- $meals")
        appendLine("- Kahvaltıda protein kaynağı, öğle ve akşamda sebze + ana protein dengesi")
        appendLine("- Paketli atıştırmalık yerine yoğurt, kefir, meyve veya çiğ kuruyemiş")
        appendLine("- $water")
        appendLine("- $focus")
        appendLine()
        appendLine("IZLEME NOTLARI")
        appendLine("- Haftalık kilo ve iştah takibi yapılır")
        appendLine("- Bir sonraki kontrolde önceki ölçümle kıyas önerilir")
        if (notes.isNotBlank()) appendLine("- Uzman notu: $notes")
    }
}


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AboutScreen(onBack: () -> Unit) {
    Scaffold(
        topBar = {
            SmallTopAppBar(
                title = { Text("Uygulama Hakkında") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) } }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                    Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Vücut Analiz Takip Pro", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        Text("Profesyonel hasta takip, ölçüm karşılaştırma, diyet planı ve paylaşım uygulaması")
                    }
                }
            }
            item {
                ElevatedCard {
                    Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Yapan: Barış Göral", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Text("Sürüm: 8.0")
                        Text("Öne çıkanlar: kamera desteği, hasta arama, otomatik VKİ, PDF rapor, WhatsApp paylaşımı, randevu takibi ve diyet planı.")
                    }
                }
            }
            item {
                ElevatedCard {
                    Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Sonraki geliştirmeler", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text("• Bulut yedekleme\n• Ölçüm grafiklerini çoğaltma\n• Randevu hatırlatma bildirimi\n• Çoklu uzman profili\n• PDF üst bilgi ve kurum logosu")
                    }
                }
            }
        }
    }
}

private fun saveBitmapToCache(context: Context, bitmap: Bitmap): Uri? {
    return runCatching {
        val file = File(context.cacheDir, "camera_${System.currentTimeMillis()}.jpg")
        FileOutputStream(file).use { out ->
            bitmap.compress(Bitmap.CompressFormat.JPEG, 92, out)
        }
        Uri.fromFile(file)
    }.getOrNull()
}

@Composable
fun QuickActionCard(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier, onClick: () -> Unit) {
    ElevatedCard(modifier = modifier.clickable(onClick = onClick)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(icon, null)
            Text(title, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
fun TrendChartCard(measurements: List<MeasurementEntity>) {
    if (measurements.size < 2) return
    val primaryColor = MaterialTheme.colorScheme.primary
    val surfaceVariantColor = MaterialTheme.colorScheme.surfaceVariant
    val cardShape = MaterialTheme.shapes.medium
    ElevatedCard {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Kilo trend grafiği", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text("Son ${measurements.size} ölçümün görsel takibi")
            Canvas(modifier = Modifier.fillMaxWidth().height(180.dp).background(surfaceVariantColor, cardShape)) {
                val sorted = measurements.sortedBy { it.dateMillis }
                val weights = sorted.map { it.weightKg.toFloat() }
                val min = weights.minOrNull() ?: 0f
                val max = weights.maxOrNull() ?: 1f
                val range = (max - min).takeIf { it > 0 } ?: 1f
                val stepX = size.width / (weights.size - 1).coerceAtLeast(1)
                var prev: Offset? = null
                weights.forEachIndexed { index, value ->
                    val x = stepX * index
                    val y = size.height - ((value - min) / range) * (size.height - 20f) - 10f
                    val point = Offset(x, y)
                    drawCircle(color = primaryColor, radius = 6f, center = point)
                    prev?.let { drawLine(primaryColor, it, point, strokeWidth = 6f, cap = StrokeCap.Round) }
                    prev = point
                }
                drawRect(color = Color.Gray.copy(alpha = 0.2f), style = Stroke(2f))
            }
        }
    }
}

@Composable
fun PatientPhotoCard(photoUri: String?, onCamera: () -> Unit, onGallery: () -> Unit) {
    ElevatedCard {
        Column(Modifier.fillMaxWidth().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Surface(modifier = Modifier.height(150.dp).fillMaxWidth(), shape = MaterialTheme.shapes.large, color = MaterialTheme.colorScheme.surfaceVariant) {
                if (photoUri != null) {
                    AsyncImage(model = photoUri, contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                } else {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Column(horizontalAlignment = Alignment.CenterHorizontally) { Icon(Icons.Default.Person, null); Text("Hasta fotoğrafı") } }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onCamera) { Icon(Icons.Default.CameraAlt, null); Spacer(Modifier.size(6.dp)); Text("Kamera") }
                OutlinedButton(onClick = onGallery) { Icon(Icons.Default.PhotoLibrary, null); Spacer(Modifier.size(6.dp)); Text("Galeri") }
            }
        }
    }
}

@Composable
fun NumericField(label: String, value: String, onValue: (String) -> Unit) {
    OutlinedTextField(value, { onValue(it.filter { ch -> ch.isDigit() || ch == '.' || ch == ',' }.replace(',', '.')) }, modifier = Modifier.fillMaxWidth(), label = { Text(label) }, leadingIcon = { Icon(Icons.Default.QueryStats, null) })
}

@Composable
fun DateField(label: String, value: String, onClick: () -> Unit) {
    OutlinedButton(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.CalendarMonth, null); Text(label) }
            Text(value)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ModernDatePicker(initial: Long, title: String, onDismiss: () -> Unit, onConfirm: (Long) -> Unit) {
    val state = rememberDatePickerState(initialSelectedDateMillis = initial)
    DatePickerDialog(onDismissRequest = onDismiss, confirmButton = { TextButton(onClick = { onConfirm(state.selectedDateMillis ?: initial) }) { Text("Tamam") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("İptal") } }) {
        Column {
            Text(title, modifier = Modifier.padding(16.dp), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            DatePicker(state = state)
        }
    }
}

@Composable
fun ComparisonOverview(latest: MeasurementEntity, previous: MeasurementEntity?) {
    ElevatedCard {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Sonuç Özeti", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text("Son ölçüm: ${formatDate(latest.dateMillis)}")
            HorizontalDivider()
            ComparisonLine("Kilo", latest.weightKg.oneDecimal() + " kg", previous?.let { deltaText(latest.weightKg, it.weightKg, "kg") } ?: "İlk kayıt")
            ComparisonLine("VKİ", latest.bmi.oneDecimal(), previous?.let { deltaText(latest.bmi, it.bmi, "") } ?: "İlk kayıt")
            ComparisonLine("Yağ", latest.bodyFatPercent.oneDecimal() + "%", previous?.let { deltaText(latest.bodyFatPercent, it.bodyFatPercent, "%") } ?: "İlk kayıt")
            ComparisonLine("İç yağ", latest.visceralFat.oneDecimal(), previous?.let { deltaText(latest.visceralFat, it.visceralFat, "") } ?: "İlk kayıt")
        }
    }
}

@Composable
fun ComparisonLine(label: String, value: String, delta: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Column { Text(label, fontWeight = FontWeight.SemiBold); Text(value) }
        Text(delta, color = MaterialTheme.colorScheme.primary)
    }
}

@Composable
fun MetricGrid(m: MeasurementEntity) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Ölçüm Kartları", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        val items = listOf(
            "Kilo" to "${m.weightKg.oneDecimal()} kg",
            "VKİ" to m.bmi.oneDecimal(),
            "Yağ" to "${m.bodyFatPercent.oneDecimal()} %",
            "Sıvı" to "${m.bodyWaterPercent.oneDecimal()} %",
            "Kas" to m.muscle.oneDecimal(),
            "Aktivite" to m.physicalActivity.oneDecimal(),
            "Kemik" to m.bone.oneDecimal(),
            "Met. Hızı" to m.metabolicRate.oneDecimal(),
            "Met. Yaşı" to m.metabolicAge.toString(),
            "İç Yağ" to m.visceralFat.oneDecimal()
        )
        items.chunked(2).forEach { rowItems ->
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                rowItems.forEach { (title, value) ->
                    ElevatedCard(modifier = Modifier.weight(1f)) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(title, fontWeight = FontWeight.SemiBold)
                            Text(value, style = MaterialTheme.typography.titleLarge)
                        }
                    }
                }
                if (rowItems.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}
