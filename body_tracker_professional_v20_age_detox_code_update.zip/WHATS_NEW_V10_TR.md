# V10 Yenilikleri

- Hasta kartı düzenleme ve silme
- Hasta notu / hastalık notu alanı
- Aramada hasta notuna göre filtreleme
- Hasta detayında not gösterimi
- Ölçüm girişlerinde numeric klavye
- Son ölçümü:
  - bir önceki kayıtla
  - önceki aya en yakın kayıtla
  - tüm önceki kayıtların ortalamasıyla
  ayrı ayrı kıyaslama
- Her metrik için ayrı grafik:
  - kilo
  - VKİ
  - yağ
  - sıvı
  - kas
  - aktivite
  - kemik
  - metabolizma hızı
  - metabolizma yaşı
  - iç yağ
- Sürüm bilgisi 10.0 olarak güncellendi

Not: Diyet listesi ekranı bu sürümde korunmuştur; sonraki sürümde ayrıca revize edilebilir.
