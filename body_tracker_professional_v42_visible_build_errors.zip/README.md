# Body Tracker Professional v42

Bu sürümde eklenen başlıca özellikler:
- Hasta arama
- Kamera ve galeri ile profil fotoğrafı
- Erkek / Kadın seçimi
- Doğum tarihi ve ölçüm tarihi için modern gg/aa/yyyy tarih seçici
- Otomatik VKİ hesaplama
- Diyet listesi oluşturma
- WhatsApp ve genel paylaşım
- PDF rapor üretimi ve paylaşımı
- Ölçüm düzenleme ve silme
- Basit trend grafiği
- Randevu / kontrol takibi
- Cihaz yeniden başlatma sonrası randevu hatırlatıcılarını yeniden kurma
- Kurumsal release imzalama: şifreler kod dışında tutulur

Not: Bu paket kaynak projedir. Android Studio veya online build ile APK oluşturulur.


## Veri kaybını azaltma
- Uygulama kimliği sabit tutuldu: `com.example.bodytracker`
- Room destructive migration kaldirildi
- Migration 5->6 eklendi
- Android backup kurallari eklendi
- Uygulamayı silmeden üstüne güncelleme önerilir
- Güncelleme APK'sı eski uygulamayla aynı `forever-release.jks` anahtarıyla imzalanmalıdır


## V23 Kurumsal Menü Notu
Ana ekran hızlı işlem kartları doğrudan ilgili modüllere yönlendirilir. Bildirim güvenliği ve randevu ekranına yönlendirme iyileştirilmiştir.


## v30 Kurumsal Paket

Dashboard, danışan sağlık profili, bel çevresi ölçümü, canlı arama ve yerel akıllı analiz asistanı eklendi. Aynı release keystore ile imzalandığında önceki sürümlerin üzerine güncelleme olarak kurulur.

## v34 Kurumsal Görsel Paket

- Ana ekran kurumsal operasyon paneli olarak yenilendi.
- Kadın / erkek / toplam danışan özeti ve 7 günlük randevu takibi üst panelde gösterilir.
- Hızlı işlemler daha profesyonel kart yapısına taşındı.
- Yerel veritabanı yedeği alma ve paylaşma aksiyonu eklendi.
- APK güncellemesi için `versionCode` 34, `versionName` 34.0 yapıldı.
- Room database version değiştirilmedi; mevcut kullanıcı verisi ve migration zinciri korunur.

## v35-v36 Takviye, Stok ve Klinik Analiz

- Takviye planı ürün görselleri, ürün kodu, kategori ve açıklama ile güçlendirildi.
- Danışana özel takviye kartlarına kutu sayısı, kutu içi miktar, birim ve günlük tüketim alanları eklendi.
- Uygulama kullanım şekline göre toplam stok ve yaklaşık kaç gün yeteceğini hesaplar.
- Bitmek üzere olan veya stok bilgisi eksik ürünler için danışman uyarıları eklendi.
- Danışan detayına klinik ölçüm özeti eklendi: kilo, yağ, sıvı, VKİ, bel ve iç yağ hedef/durum kartları.
- Ölçüm giriş ekranına canlı analiz önizlemesi eklendi.
- Trend grafikleri kilo/yağ/sıvı, kas/bel/KPS ve metabolik risk grupları olarak düzenlendi.
- APK güncellemesi için `versionCode` 36, `versionName` 36.0 yapıldı.
- Room database version 12 oldu; migration 11->12 yalnızca takviye stok alanlarını ekler, mevcut verileri silmez.

## v37 Akıllı Ürün Eşleşmesi

- 83 ürün, danışanın son ölçüm verileri ve hedef planına göre uygunluk skoruyla listelenir.
- Skor; VKİ, vücut yağ oranı, iç yağ, sıvı oranı, aktivite, yaş, cinsiyet, hedef odağı, alerji ve ilaç notlarına göre hesaplanır.
- Ürün kartında öneri gerekçesi, hedef etiketleri, ürün görseli, ürün kodu ve varsa güvenlik uyarısı gösterilir.
- Bu özellik tıbbi etki garantisi vermez; danışman için karar destek ve önceliklendirme ekranıdır.
- APK güncellemesi için `versionCode` 37, `versionName` 37.0 yapıldı.

## v38-v39 Adaptif Plan Zekası

- Akıllı plan aksiyonları üst seviye hale getirildi: öncelik, kategori, metrik, ürün odağı ve takip periyodu ayrı gösterilir.
- Akıllı beslenme planı eklendi: sebze, protein, su, lif, ara öğün ve aktivite uyumu ölçüm verisine göre önerilir.
- Bir danışanda birden fazla ölçüm ve birden fazla takviye planı dikkate alınır.
- Seçili ölçüme bağlı plan ile önceki ölçüme bağlı plan kıyaslanır.
- Önceki plana göre “iyi trend”, “kötü trend”, “aynı plan yeterli değil”, “çıkarılan ürünleri kontrol et” gibi karar destekleri üretilir.
- APK güncellemesi için `versionCode` 39, `versionName` 39.0 yapıldı.

## v40 Tam Takip Platformu

- Danışman Notları / Karar Günlüğü eklendi: her ölçüm ve plan değişikliğinde karar başlığı, gerekçe ve aksiyon saklanır.
- Günlük Uyum Takibi eklendi: ürün kullanımı, su, sebze, protein, aktivite, uyku ve not kaydedilir; yüzde uyum hesaplanır.
- Plan kalite skoru eklendi: ölçüm, ürün planı, stok bilgisi, beslenme, akıllı aksiyon, uyum ve uzman notuna göre % skor gösterilir.
- Danışan takip etiketi eklendi: iyi gidiyor, plan değişmeli, stok kritik, uyum düşük, riskli trend gibi otomatik durum üretir.
- Profesyonel plan şablonları eklendi: yağ/kilo, sıvı düşük, kas düşük, iç yağ/bel takibi için hazır beslenme-su-ürün-aktivite omurgası verir.
- Stok bildirimi güçlendirildi: 7 gün altı kritik ürünlerden randevu/bildirim hatırlatıcısı oluşturulabilir.
- Ürün kataloğu yönetimi eklendi: ürün adı, kodu, görseli, açıklaması, varsayılan kullanım ve zamanlama uygulama içinden düzenlenebilir.
- PDF raporu kurumsallaştırıldı: TANITA tarzı ölçüm karşılaştırması, grafik, takviye/stok kıyaslaması ve ikinci sayfada akıllı plan özeti yer alır.
- Randevu + plan entegrasyonu eklendi: randevu ekranı son planı, ürün sayısını, stok riskini ve ölçüm farkını özetler.
- Room database version 13 oldu; migration 12->13 sadece yeni takip tablolarını ekler, önceki danışan ve ölçüm verilerini silmez.
- GitHub Actions APK workflow v40 zip adına göre güncellendi; build log yolu ve proje bulma adımı daha dayanıklı hale getirildi.
- APK güncellemesi için `versionCode` 40, `versionName` 40.0 yapıldı.

## v41 GitHub APK Build Düzeltmesi

- GitHub Actions workflow repo kökünde ayrıca kullanılacak şekilde hazırlandı.
- Build başlamadan `build.log` oluşturulur; artifact yolu sabit `build.log` olduğu için `/build.log` hatası oluşmaz.
- Gradle logları, Android SDK kurulumu, unzip, proje bulma ve build çıktısı aynı log dosyasına yazılır.
- APK artifact yolu sabit glob ile aranır; boş `project_dir` yüzünden path bozulmaz.
- APK güncellemesi için `versionCode` 41, `versionName` 41.0 yapıldı.

## v42 Görünür Build Hatası

- GitHub Actions hata verse bile `build.log` son satırları job ekranına ve summary bölümüne basılır.
- Gradle sürümü build başlamadan loglanır.
- APK çıktı klasörleri her koşulda listelenir.
- APK güncellemesi için `versionCode` 42, `versionName` 42.0 yapıldı.
