package com.example.bodytracker.notifications

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.bodytracker.MainActivity
import com.example.bodytracker.R

class AppointmentAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            ACTION_SNOOZE -> {
                val triggerAt = System.currentTimeMillis() + 60 * 60 * 1000L
                val snoozeIntent = buildAlarmIntent(
                    context = context,
                    appointmentId = intent.getLongExtra(EXTRA_APPOINTMENT_ID, 0L),
                    patientId = intent.getLongExtra(EXTRA_PATIENT_ID, 0L),
                    patientName = intent.getStringExtra(EXTRA_PATIENT_NAME).orEmpty(),
                    title = intent.getStringExtra(EXTRA_TITLE).orEmpty(),
                    note = intent.getStringExtra(EXTRA_NOTE).orEmpty(),
                    whenMillis = triggerAt,
                    action = ACTION_NOTIFY
                )
                scheduleExact(context, snoozeIntent, triggerAt)
                return
            }
            ACTION_COMPLETE -> {
                NotificationManagerCompat.from(context).cancel(intent.getLongExtra(EXTRA_APPOINTMENT_ID, 0L).toInt())
                return
            }
            else -> Unit
        }

        createChannel(context)
        val appointmentId = intent.getLongExtra(EXTRA_APPOINTMENT_ID, 0L)
        val patientId = intent.getLongExtra(EXTRA_PATIENT_ID, 0L)
        val patientName = intent.getStringExtra(EXTRA_PATIENT_NAME).orEmpty()
        val title = intent.getStringExtra(EXTRA_TITLE).orEmpty().ifBlank { "Randevu" }
        val note = intent.getStringExtra(EXTRA_NOTE).orEmpty()
        val whenText = intent.getStringExtra(EXTRA_WHEN_TEXT).orEmpty()

        val openIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("appointment_patient_id", patientId)
        }
        val openPendingIntent = PendingIntent.getActivity(
            context,
            appointmentId.toInt(),
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val snoozePendingIntent = PendingIntent.getBroadcast(
            context,
            (appointmentId.toInt() + 10000),
            buildAlarmIntent(
                context, appointmentId, patientId, patientName, title, note,
                System.currentTimeMillis() + 60 * 60 * 1000L, ACTION_SNOOZE
            ),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val completePendingIntent = PendingIntent.getBroadcast(
            context,
            (appointmentId.toInt() + 20000),
            buildAlarmIntent(
                context, appointmentId, patientId, patientName, title, note,
                System.currentTimeMillis(), ACTION_COMPLETE
            ),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val detailText = buildString {
            append(patientName)
            if (whenText.isNotBlank()) append(" • ").append(whenText)
            if (note.isNotBlank()) append("\nNot: ").append(note)
        }

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText(patientName)
            .setStyle(NotificationCompat.BigTextStyle().bigText(detailText))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(openPendingIntent)
            .addAction(0, "Ertele", snoozePendingIntent)
            .addAction(0, "Tamam", completePendingIntent)
            .build()

        NotificationManagerCompat.from(context).notify(appointmentId.toInt(), notification)
    }

    private fun createChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Randevu Hatırlatmaları",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Danışan randevu bildirimleri"
            }
            val manager = context.getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    companion object {
        const val CHANNEL_ID = "appointments"
        const val ACTION_NOTIFY = "com.example.bodytracker.ACTION_NOTIFY_APPOINTMENT"
        const val ACTION_SNOOZE = "com.example.bodytracker.ACTION_SNOOZE_APPOINTMENT"
        const val ACTION_COMPLETE = "com.example.bodytracker.ACTION_COMPLETE_APPOINTMENT"
        const val EXTRA_APPOINTMENT_ID = "extra_appointment_id"
        const val EXTRA_PATIENT_ID = "extra_patient_id"
        const val EXTRA_PATIENT_NAME = "extra_patient_name"
        const val EXTRA_TITLE = "extra_title"
        const val EXTRA_NOTE = "extra_note"
        const val EXTRA_WHEN_TEXT = "extra_when_text"

        fun buildAlarmIntent(
            context: Context,
            appointmentId: Long,
            patientId: Long,
            patientName: String,
            title: String,
            note: String,
            whenMillis: Long,
            action: String = ACTION_NOTIFY,
            whenText: String = ""
        ): Intent = Intent(context, AppointmentAlarmReceiver::class.java).apply {
            this.action = action
            putExtra(EXTRA_APPOINTMENT_ID, appointmentId)
            putExtra(EXTRA_PATIENT_ID, patientId)
            putExtra(EXTRA_PATIENT_NAME, patientName)
            putExtra(EXTRA_TITLE, title)
            putExtra(EXTRA_NOTE, note)
            putExtra(EXTRA_WHEN_TEXT, whenText)
            putExtra("when_millis", whenMillis)
        }

        fun scheduleExact(context: Context, intent: Intent, triggerAtMillis: Long) {
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val requestCode = intent.getLongExtra(EXTRA_APPOINTMENT_ID, 0L).toInt()
            val pendingIntent = PendingIntent.getBroadcast(
                context,
                requestCode,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !alarmManager.canScheduleExactAlarms()) {
                    alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pendingIntent)
                } else {
                    alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pendingIntent)
                }
            } catch (sec: SecurityException) {
                Log.e("AppointmentAlarm", "Alarm scheduling failed", sec)
                alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pendingIntent)
            }
        }
    }
}
