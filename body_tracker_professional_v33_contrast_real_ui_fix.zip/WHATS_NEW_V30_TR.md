# Body Tracker Professional v30

Bu sürüm kurumsal kullanım hedefiyle hazırlanmıştır.

## Yeni özellikler
- Danışan profiline hedef kilo, hedef yağ oranı, hastalık geçmişi, alerjiler ve kullanılan ilaçlar eklendi.
- Dashboard daha akıllı hale getirildi: bugünkü randevular, haftalık randevular ve ölçüm bekleyen danışanlar gösterilir.
- Canlı arama sağlık notları, alerji ve ilaç alanlarını da kapsar.
- Ölçüm ekranına bel çevresi eklendi.
- Grafik bölümüne bel çevresi trendi eklendi.
- Danışan detayına Akıllı Analiz Asistanı eklendi.
- Analiz raporunda hedef kilo ve yerel trend yorumları kullanılır.
- Sürüm versionCode 30 / versionName 30.0 yapıldı.

## Not
Google Drive yedekleme ve gerçek bulut tabanlı yapay zeka entegrasyonu için OAuth/API anahtarı gerekir. Bu sürümde güvenli şekilde eklenebilir temel yapı ve yerel akıllı analiz mantığı hazırlanmıştır.
