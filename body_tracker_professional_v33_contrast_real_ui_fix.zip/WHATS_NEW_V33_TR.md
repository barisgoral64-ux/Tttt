# Body Tracker Professional v33

Bu sürüm v32 sonrası gelen görsel/tema geri bildirimlerine odaklanır.

## Düzeltmeler
- Koyu tema kontrastı iyileştirildi.
- Beyaz zemin üzerinde beyaz/silik yazı kalma riski azaltıldı.
- Özel renkli kartlarda `contentColor` açıkça tanımlandı.
- Koyu kartlarda yazı rengi netleştirildi.
- Üst bar koyu temaya sabitlendi.
- Danışan kartları ve çiplerde okunabilirlik artırıldı.

## Sürüm
- versionCode: 33
- versionName: 33.0
