# İmzalı Güncelleme APK Rehberi

Bu paket, eski uygulamanın üzerine güncelleme yapılabilmesi için orijinal `app/forever-release.jks` keystore dosyasıyla yapılandırılmıştır.

## Kritik Kurallar

- `applicationId`: `com.example.bodytracker` olarak korunmuştur.
- `versionCode`: `23` olarak ayarlanmıştır.
- Güncelleme için APK mutlaka aynı `forever-release.jks` ile imzalanmalıdır.
- Farklı keystore ile imzalanan APK eski uygulamanın üzerine kurulmaz.

## GitHub Actions

Repo köküne bu zip dosyasını yükleyin:

`body_tracker_professional_v23_signed_update_ready.zip`

Actions ekranından:

`Build Signed Release APK from ZIP` → `Run workflow`

Başarılı çıktının artifact adı:

`forever-danisan-takip-signed-update-apk`

## Veri Kaybı Olmaması İçin

Kullanıcı eski uygulamayı kaldırmamalıdır. Aynı imzalı APK doğrudan kurulmalıdır. Böylece Room veritabanı ve girilen bilgiler korunur.
