# V42 Görünür Build Hatası

- GitHub Actions hata verse bile `build.log` son 220 satırı job ekranına basılır.
- Job summary içine `build.log` son 120 satırı eklenir.
- Gradle sürümü ve APK çıktı klasörleri loglanır.
- Workflow zip adı `body_tracker_professional_v42_visible_build_errors.zip` olarak güncellendi.
- Sürüm `versionCode 42` / `versionName 42.0` yapıldı.
