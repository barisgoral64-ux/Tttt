# V22 Kurumsal Düzeltme Paketi

- Uygulama sürümü 22.0 / versionCode 22 olarak güncellendi.
- Release imzalama yapısı kurumsallaştırıldı: şifreler kodda değil, `keystore.properties` veya CI environment değişkenlerinde tutulur.
- Aynı eski keystore ile imzalanırsa kullanıcı verileri korunarak normal güncelleme yapılır.
- Randevu saat/dakika doğrulaması eklendi.
- Geçmiş tarihli randevu kaydı engellendi.
- Kesin alarm izni kapalıysa randevu kaydı engellenmez; sistem en iyi çabayla alarm kurar ve kullanıcı bilgilendirilir.
- Cihaz yeniden başlatıldığında, saat veya zaman dilimi değiştiğinde gelecekteki randevular yeniden planlanır.
- Erteleme bildirimi tarih metni güncellendi.
- Silme/tamamlandı işlemleri ana alarm, erteleme ve tamamlandı PendingIntent kayıtlarını birlikte iptal eder.
- Veritabanı yedeği WAL checkpoint sonrası zaman damgalı ve `latest` kopyalı alınır.
- Room schema export yapılandırması eklendi.
