# V11 - Referans Aralıkları ve Akıllı Uyarılar

Bu sürümde uygulamaya profesyonel referans aralıkları eklendi.

## Eklenenler
- Kilo için boya göre hedef kilo aralığı
- VKİ için otomatik sınıflama
- Yağ oranı için yaş ve cinsiyete göre referans
- Vücut sıvı oranı için cinsiyete göre referans
- İç yağ için referans seviyesi
- Metabolizma yaşı için gerçek yaş kıyası
- Metabolizma hızı için tahmini BMR kıyası
- Kas, kemik ve fiziksel aktivite için takip referansları

## Görsel Değişiklikler
- Ölçüm giriş ekranında her alanın altında referans kartı
- Hasta detay ekranında her ölçüm kartında referans bilgisi
- Referans içinde / altında / üstünde durum bilgisi
- Ek açıklama notları
