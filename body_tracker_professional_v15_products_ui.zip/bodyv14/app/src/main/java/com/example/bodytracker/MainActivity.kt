package com.example.bodytracker

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Female
import androidx.compose.material.icons.filled.Man
import androidx.compose.material.icons.filled.MonitorWeight
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.QueryStats
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SmallTopAppBar
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardOptions
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.input.KeyboardType
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import androidx.compose.runtime.collectAsState
import coil.compose.AsyncImage
import com.example.bodytracker.data.AppDatabase
import com.example.bodytracker.data.AppointmentEntity
import com.example.bodytracker.data.BodyTrackerRepository
import com.example.bodytracker.data.MeasurementEntity
import com.example.bodytracker.data.PatientEntity
import com.example.bodytracker.ui.theme.BodyTrackerTheme
import com.example.bodytracker.util.*
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream

sealed interface Screen {
    data object Patients : Screen
    data class AddPatient(val patientId: Long? = null) : Screen
    data object About : Screen
    data class Detail(val patientId: Long) : Screen
    data class AddMeasurement(val patientId: Long, val measurementId: Long? = null) : Screen
    data class DietPlan(val patientId: Long) : Screen
    data class Appointments(val patientId: Long) : Screen
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = AppDatabase.get(this)
        val repo = BodyTrackerRepository(
            db.patientDao(),
            db.measurementDao(),
            db.appointmentDao(),
            db.productCategoryDao(),
            db.productDao(),
            db.dietPlanDao(),
            db.dietPlanProductDao(),
            db.appSettingDao()
        )
        lifecycleScope.launch { repo.ensureSeededProducts() }
        setContent {
            BodyTrackerTheme {
                BodyTrackerApp(repo)
            }
        }
    }
}

@Composable
fun BodyTrackerApp(repo: BodyTrackerRepository) {
    var screen by remember { mutableStateOf<Screen>(Screen.Patients) }
    when (val s = screen) {
        Screen.Patients -> PatientsScreen(
            repo,
            onAdd = { screen = Screen.AddPatient() },
            onAbout = { screen = Screen.About },
            onOpen = { screen = Screen.Detail(it) },
            onEdit = { screen = Screen.AddPatient(it) }
        )
        is Screen.AddPatient -> AddPatientScreen(repo, s.patientId, onBack = {
            screen = if (s.patientId == null) Screen.Patients else Screen.Detail(s.patientId)
        }, onSaved = { screen = Screen.Detail(it) })
        Screen.About -> AboutScreen(onBack = { screen = Screen.Patients })
        is Screen.Detail -> PatientDetailScreen(
            repo = repo,
            patientId = s.patientId,
            onBack = { screen = Screen.Patients },
            onEditPatient = { screen = Screen.AddPatient(s.patientId) },
            onAddMeasurement = { screen = Screen.AddMeasurement(s.patientId) },
            onEditMeasurement = { screen = Screen.AddMeasurement(s.patientId, it) },
            onOpenDietPlan = { screen = Screen.DietPlan(s.patientId) },
            onOpenAppointments = { screen = Screen.Appointments(s.patientId) }
        )
        is Screen.AddMeasurement -> AddMeasurementScreen(repo, s.patientId, s.measurementId, onBack = { screen = Screen.Detail(s.patientId) }, onSaved = { screen = Screen.Detail(s.patientId) })
        is Screen.DietPlan -> DietPlanScreen(repo, s.patientId, onBack = { screen = Screen.Detail(s.patientId) })
        is Screen.Appointments -> AppointmentsScreen(repo, s.patientId, onBack = { screen = Screen.Detail(s.patientId) })
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PatientsScreen(repo: BodyTrackerRepository, onAdd: () -> Unit, onAbout: () -> Unit, onOpen: (Long) -> Unit, onEdit: (Long) -> Unit) {
    val patients by repo.observePatients().collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    var query by rememberSaveable { mutableStateOf("") }
    val filtered = remember(patients, query) {
        val q = query.trim().lowercase()
        if (q.isBlank()) {
            patients
        } else {
            patients.filter {
                listOf(
                    it.firstName,
                    it.lastName,
                    "${it.firstName} ${it.lastName}",
                    it.gender,
                    formatDate(it.birthDateMillis),
                    it.notes
                ).any { value -> value.lowercase().contains(q) }
            }
        }
    }

    Scaffold(
        topBar = {
            SmallTopAppBar(
                title = { Text("Vücut Analiz Takip Pro") },
                actions = { IconButton(onClick = onAbout) { Icon(Icons.Default.Info, contentDescription = "Hakkında") } }
            )
        },
        floatingActionButton = { FloatingActionButton(onClick = onAdd) { Icon(Icons.Default.Add, null) } }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Profesyonel hasta arama", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text("Kayıtlı hastaları hızlı ara, karttan detay aç ve hasta bilgilerini tek bakışta gör.")
                    }
                }
            }
            item {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Hasta ara") },
                    placeholder = { Text("Ad, soyad, cinsiyet veya tarih") },
                    leadingIcon = { Icon(Icons.Default.Search, null) },
                    trailingIcon = {
                        if (query.isNotBlank()) {
                            IconButton(onClick = { query = "" }) { Icon(Icons.Default.Close, contentDescription = "Temizle") }
                        }
                    },
                    singleLine = true
                )
            }
            if (filtered.isEmpty()) {
                item {
                    ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                        Column(Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.Search, contentDescription = null)
                            Text("Sonuç bulunamadı", fontWeight = FontWeight.Bold)
                            Text("Arama kelimesini değiştirerek tekrar deneyebilirsin.")
                        }
                    }
                }
            }
            items(filtered) { patient ->
                PatientSearchCard(
                    patient = patient,
                    onOpen = { onOpen(patient.id) },
                    onEdit = { onEdit(patient.id) },
                    onDelete = { scope.launch { repo.deletePatient(patient) } }
                )
            }
        }
    }
}

@Composable
private fun PatientSearchCard(patient: PatientEntity, onOpen: () -> Unit, onEdit: () -> Unit, onDelete: () -> Unit) {
    ElevatedCard(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onOpen),
        colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Surface(
                    modifier = Modifier.size(60.dp),
                    shape = MaterialTheme.shapes.large,
                    color = MaterialTheme.colorScheme.secondaryContainer
                ) {
                    if (patient.photoUri.isNullOrBlank()) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.Person, contentDescription = null, modifier = Modifier.size(32.dp))
                        }
                    } else {
                        AsyncImage(
                            model = patient.photoUri,
                            contentDescription = null,
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    }
                }
                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("${patient.firstName} ${patient.lastName}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(
                        text = "Doğum: ${formatDate(patient.birthDateMillis)}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Surface(shape = MaterialTheme.shapes.large, color = MaterialTheme.colorScheme.primaryContainer) {
                    Text(
                        text = if (patient.gender == "Erkek") "Erkek" else "Kadın",
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PatientInfoChip(icon = Icons.Default.Person, text = "${calculateAge(patient.birthDateMillis)} yaş")
                PatientInfoChip(icon = Icons.Default.MonitorWeight, text = "${patient.heightCm} cm")
                PatientInfoChip(
                    icon = if (patient.gender == "Erkek") Icons.Default.Man else Icons.Default.Female,
                    text = "Profil"
                )
            }

            if (patient.notes.isNotBlank()) {
                Surface(shape = MaterialTheme.shapes.medium, color = MaterialTheme.colorScheme.tertiaryContainer) {
                    Text(
                        text = patient.notes.take(90),
                        modifier = Modifier.fillMaxWidth().padding(10.dp),
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }

            HorizontalDivider()

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text("Kayıt tarihi", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(formatDate(patient.createdAt), fontWeight = FontWeight.Medium)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = onEdit) { Text("Düzenle") }
                    TextButton(onClick = onOpen) { Text("Detayı Aç") }
                    IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, contentDescription = "Sil") }
                }
            }
        }
    }
}

@Composable
private fun PatientInfoChip(icon: androidx.compose.ui.graphics.vector.ImageVector, text: String) {
    Surface(shape = MaterialTheme.shapes.large, color = MaterialTheme.colorScheme.surfaceVariant) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = null, modifier = Modifier.size(18.dp))
            Text(text, style = MaterialTheme.typography.labelLarge)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddPatientScreen(repo: BodyTrackerRepository, patientId: Long?, onBack: () -> Unit, onSaved: (Long) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val existingPatient by if (patientId != null) {
        repo.observePatient(patientId).collectAsState(initial = null)
    } else {
        remember { mutableStateOf<PatientEntity?>(null) }
    }
    var initialized by remember(existingPatient?.id) { mutableStateOf(false) }
    var firstName by rememberSaveable { mutableStateOf("") }
    var lastName by rememberSaveable { mutableStateOf("") }
    var gender by rememberSaveable { mutableStateOf("Erkek") }
    var heightText by rememberSaveable { mutableStateOf("") }
    var birthDate by rememberSaveable { mutableStateOf(System.currentTimeMillis()) }
    var showDatePicker by remember { mutableStateOf(false) }
    var photoUri by rememberSaveable { mutableStateOf<String?>(null) }
    var notes by rememberSaveable { mutableStateOf("") }

    val previewLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicturePreview()) { bitmap ->
        if (bitmap != null) {
            photoUri = saveBitmapToCache(context, bitmap)?.toString()
        } else {
            Toast.makeText(context, "Kamera görüntüsü alınamadı", Toast.LENGTH_SHORT).show()
        }
    }
    val cameraPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            try {
                previewLauncher.launch(null)
            } catch (_: Exception) {
                Toast.makeText(context, "Kamera açılamadı", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(context, "Kamera izni verilmedi", Toast.LENGTH_SHORT).show()
        }
    }
    val galleryLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> photoUri = uri?.toString() }

    val existingProfile = existingPatient
    if (existingProfile != null && !initialized) {
        firstName = existingProfile.firstName
        lastName = existingProfile.lastName
        gender = existingProfile.gender
        heightText = existingProfile.heightCm.toString()
        birthDate = existingProfile.birthDateMillis
        photoUri = existingProfile.photoUri
        notes = existingProfile.notes
        initialized = true
    }

    if (showDatePicker) {
        ModernDatePicker(initial = birthDate, title = "Doğum tarihi seç", onDismiss = { showDatePicker = false }) {
            birthDate = it
            showDatePicker = false
        }
    }

    Scaffold(topBar = { SmallTopAppBar(title = { Text(if (patientId == null) "Yeni Hasta" else "Hasta Düzenle") }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) } }) }) { padding ->
        LazyColumn(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                PatientPhotoCard(photoUri, onCamera = {
                    val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == android.content.pm.PackageManager.PERMISSION_GRANTED
                    if (granted) {
                        try {
                            previewLauncher.launch(null)
                        } catch (_: Exception) {
                            Toast.makeText(context, "Kamera açılamadı", Toast.LENGTH_SHORT).show()
                        }
                    } else {
                        cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                    }
                }, onGallery = { galleryLauncher.launch("image/*") })
            }
            item { OutlinedTextField(firstName, { firstName = it }, Modifier.fillMaxWidth(), label = { Text("Ad") }, leadingIcon = { Icon(Icons.Default.Person, null) }) }
            item { OutlinedTextField(lastName, { lastName = it }, Modifier.fillMaxWidth(), label = { Text("Soyad") }, leadingIcon = { Icon(Icons.Default.Person, null) }) }
            item { DateField("Doğum Tarihi", formatDate(birthDate)) { showDatePicker = true } }
            item {
                Text("Cinsiyet", style = MaterialTheme.typography.titleMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = gender == "Erkek", onClick = { gender = "Erkek" }, label = { Text("Erkek") }, leadingIcon = { Icon(Icons.Default.Man, null) })
                    FilterChip(selected = gender == "Kadın", onClick = { gender = "Kadın" }, label = { Text("Kadın") }, leadingIcon = { Icon(Icons.Default.Female, null) })
                }
            }
            item { OutlinedTextField(heightText, { heightText = it.filter(Char::isDigit) }, Modifier.fillMaxWidth(), label = { Text("Boy (cm)") }, leadingIcon = { Icon(Icons.Default.MonitorWeight, null) }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)) }
            item {
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    modifier = Modifier.fillMaxWidth().height(120.dp),
                    label = { Text("Hasta Notu / Hastalıklar") },
                    leadingIcon = { Icon(Icons.Default.Info, null) }
                )
            }
            item {
                Button(onClick = {
                    val height = heightText.toIntOrNull() ?: 0
                    if (firstName.isNotBlank() && lastName.isNotBlank() && height > 0) {
                        scope.launch {
                            val entity = PatientEntity(
                                id = existingPatient?.id ?: 0,
                                firstName = firstName.trim(),
                                lastName = lastName.trim(),
                                birthDateMillis = birthDate,
                                gender = gender,
                                heightCm = height,
                                photoUri = photoUri,
                                notes = notes.trim(),
                                createdAt = existingPatient?.createdAt ?: System.currentTimeMillis()
                            )
                            if (existingPatient == null) {
                                val id = repo.addPatient(entity)
                                onSaved(id)
                            } else {
                                repo.updatePatient(entity)
                                onSaved(entity.id)
                            }
                        }
                    }
                }, modifier = Modifier.fillMaxWidth()) { Text(if (patientId == null) "Hastayı Kaydet" else "Hastayı Güncelle") }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PatientDetailScreen(
    repo: BodyTrackerRepository,
    patientId: Long,
    onBack: () -> Unit,
    onEditPatient: () -> Unit,
    onAddMeasurement: () -> Unit,
    onEditMeasurement: (Long) -> Unit,
    onOpenDietPlan: () -> Unit,
    onOpenAppointments: () -> Unit
) {
    val scope = rememberCoroutineScope()
    val patient by repo.observePatient(patientId).collectAsState(initial = null)
    val measurements by repo.observeMeasurements(patientId).collectAsState(initial = emptyList())
    val latest = measurements.firstOrNull()
    val previous = measurements.getOrNull(1)
    val previousMonth = latest?.let { l -> measurements.drop(1).minByOrNull { kotlin.math.abs(it.dateMillis - (l.dateMillis - 30L * 24 * 60 * 60 * 1000)) } }

    Scaffold(
        topBar = {
            SmallTopAppBar(
                title = { Text("Hasta Detayı") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) } },
                actions = {
                    IconButton(onClick = onEditPatient) { Icon(Icons.Default.Edit, null) }
                    IconButton(onClick = onOpenAppointments) { Icon(Icons.Default.Event, null) }
                    IconButton(onClick = onOpenDietPlan) { Icon(Icons.Default.Description, null) }
                    IconButton(onClick = onAddMeasurement) { Icon(Icons.Default.Add, null) }
                }
            )
        }
    ) { padding ->
        val p = patient ?: return@Scaffold
        LazyColumn(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                Card {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("${p.firstName} ${p.lastName}", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        Text("${p.gender} • ${calculateAge(p.birthDateMillis)} yaş • ${p.heightCm} cm")
                        Text("Doğum Tarihi: ${formatDate(p.birthDateMillis)}")
                        if (p.notes.isNotBlank()) {
                            Surface(shape = MaterialTheme.shapes.medium, color = MaterialTheme.colorScheme.tertiaryContainer) {
                                Text("Not: ${p.notes}", modifier = Modifier.fillMaxWidth().padding(10.dp))
                            }
                        }
                    }
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                    QuickActionCard("Diyet", Icons.Default.Description, Modifier.weight(1f), onOpenDietPlan)
                    QuickActionCard("Randevu", Icons.Default.Event, Modifier.weight(1f), onOpenAppointments)
                }
            }
            if (latest != null) {
                item { ComparisonOverview(latest, previous, previousMonth, measurements.drop(1)) }
                item { MetricGrid(p, latest) }
                item { MetricChartsSection(measurements) }
            }
            item { Text("Ölçüm Geçmişi", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
            items(measurements) { m ->
                Card {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text(formatDate(m.dateMillis), fontWeight = FontWeight.SemiBold)
                            Row {
                                IconButton(onClick = { onEditMeasurement(m.id) }) { Icon(Icons.Default.Edit, null) }
                                IconButton(onClick = { scope.launch { repo.deleteMeasurement(m) } }) { Icon(Icons.Default.Delete, null) }
                            }
                        }
                        Text("Kilo: ${m.weightKg.oneDecimal()} kg  •  VKİ: ${m.bmi.oneDecimal()}")
                        Text("Yağ: ${m.bodyFatPercent.oneDecimal()}%  •  Sıvı: ${m.bodyWaterPercent.oneDecimal()}%  •  Kas: ${m.muscle.oneDecimal()}")
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddMeasurementScreen(repo: BodyTrackerRepository, patientId: Long, measurementId: Long?, onBack: () -> Unit, onSaved: () -> Unit) {
    val scope = rememberCoroutineScope()
    val patient by repo.observePatient(patientId).collectAsState(initial = null)
    val existing by if (measurementId != null) {
        repo.observeMeasurement(measurementId).collectAsState(initial = null)
    } else {
        remember { mutableStateOf<MeasurementEntity?>(null) }
    }
    val p = patient ?: return

    var initialized by remember(existing?.id) { mutableStateOf(false) }
    var dateMillis by rememberSaveable { mutableStateOf(System.currentTimeMillis()) }
    var showDatePicker by remember { mutableStateOf(false) }
    var weightText by rememberSaveable { mutableStateOf("") }
    var fatText by rememberSaveable { mutableStateOf("") }
    var waterText by rememberSaveable { mutableStateOf("") }
    var muscleText by rememberSaveable { mutableStateOf("") }
    var activityText by rememberSaveable { mutableStateOf("") }
    var boneText by rememberSaveable { mutableStateOf("") }
    var rateText by rememberSaveable { mutableStateOf("") }
    var metabolicAgeText by rememberSaveable { mutableStateOf("") }
    var visceralText by rememberSaveable { mutableStateOf("") }

    val existingMeasurement = existing
    if (existingMeasurement != null && !initialized) {
        dateMillis = existingMeasurement.dateMillis
        weightText = existingMeasurement.weightKg.toString()
        fatText = existingMeasurement.bodyFatPercent.toString()
        waterText = existingMeasurement.bodyWaterPercent.toString()
        muscleText = existingMeasurement.muscle.toString()
        activityText = existingMeasurement.physicalActivity.toString()
        boneText = existingMeasurement.bone.toString()
        rateText = existingMeasurement.metabolicRate.toString()
        metabolicAgeText = existingMeasurement.metabolicAge.toString()
        visceralText = existingMeasurement.visceralFat.toString()
        initialized = true
    }

    val bmi = calculateBmi(weightText.toDoubleOrNull() ?: 0.0, p.heightCm)
    if (showDatePicker) {
        ModernDatePicker(initial = dateMillis, title = "Ölçüm tarihi seç", onDismiss = { showDatePicker = false }) {
            dateMillis = it
            showDatePicker = false
        }
    }

    Scaffold(topBar = { SmallTopAppBar(title = { Text(if (measurementId == null) "Yeni Ölçüm" else "Ölçüm Düzenle") }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) } }) }) { padding ->
        LazyColumn(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("${p.firstName} ${p.lastName}", fontWeight = FontWeight.Bold)
                        Text("Boy: ${p.heightCm} cm • Yaş: ${calculateAge(p.birthDateMillis)}")
                        Text("VKİ otomatik hesaplanır.")
                    }
                }
            }
            item { DateField("Ölçüm Tarihi", formatDate(dateMillis)) { showDatePicker = true } }
            item { NumericField("Kilo (kg)", weightText) { weightText = it } }
            item { ReferenceStatusCard("Kilo Referansı", weightReferenceStatus(weightText.toDoubleOrNull() ?: 0.0, p.heightCm)) }
            item {
                ElevatedCard { Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween) { Text("Otomatik VKİ", fontWeight = FontWeight.SemiBold); Text(bmi.oneDecimal(), style = MaterialTheme.typography.titleLarge) } }
            }
            item { ReferenceStatusCard("VKİ Referansı", bmiReferenceStatus(bmi)) }
            item { NumericField("Vücut Yağ Oranı (%)", fatText) { fatText = it } }
            item { ReferenceStatusCard("Yağ Oranı Referansı", bodyFatReferenceStatus(p.gender, calculateAge(p.birthDateMillis), fatText.toDoubleOrNull() ?: 0.0)) }
            item { NumericField("Vücut Sıvı Oranı (%)", waterText) { waterText = it } }
            item { ReferenceStatusCard("Sıvı Oranı Referansı", bodyWaterReferenceStatus(p.gender, waterText.toDoubleOrNull() ?: 0.0)) }
            item { NumericField("Kas", muscleText) { muscleText = it } }
            item { ReferenceStatusCard("Kas Referansı", muscleReferenceStatus(p.gender, muscleText.toDoubleOrNull() ?: 0.0)) }
            item { NumericField("Fiziksel Aktivite", activityText) { activityText = it } }
            item { ReferenceStatusCard("Aktivite Referansı", activityReferenceStatus(activityText.toDoubleOrNull() ?: 0.0)) }
            item { NumericField("Kemik", boneText) { boneText = it } }
            item { ReferenceStatusCard("Kemik Referansı", boneReferenceStatus(p.gender, boneText.toDoubleOrNull() ?: 0.0)) }
            item { NumericField("Metabolizma Hızı", rateText) { rateText = it } }
            item { ReferenceStatusCard("Metabolizma Hızı Referansı", metabolicRateReferenceStatus(p.gender, calculateAge(p.birthDateMillis), p.heightCm, weightText.toDoubleOrNull() ?: 0.0, rateText.toDoubleOrNull() ?: 0.0)) }
            item { NumericField("Metabolizma Yaşı", metabolicAgeText) { metabolicAgeText = it } }
            item { ReferenceStatusCard("Metabolizma Yaşı Referansı", metabolicAgeReferenceStatus(calculateAge(p.birthDateMillis), metabolicAgeText.toIntOrNull() ?: 0)) }
            item { NumericField("İç Yağ", visceralText) { visceralText = it } }
            item { ReferenceStatusCard("İç Yağ Referansı", visceralFatReferenceStatus(visceralText.toDoubleOrNull() ?: 0.0)) }
            item {
                Button(onClick = {
                    val weight = weightText.toDoubleOrNull() ?: 0.0
                    if (weight > 0) {
                        val entity = MeasurementEntity(
                            id = existing?.id ?: 0,
                            patientId = patientId,
                            dateMillis = dateMillis,
                            weightKg = weight,
                            bmi = bmi,
                            bodyFatPercent = fatText.toDoubleOrNull() ?: 0.0,
                            bodyWaterPercent = waterText.toDoubleOrNull() ?: 0.0,
                            muscle = muscleText.toDoubleOrNull() ?: 0.0,
                            physicalActivity = activityText.toDoubleOrNull() ?: 0.0,
                            bone = boneText.toDoubleOrNull() ?: 0.0,
                            metabolicRate = rateText.toDoubleOrNull() ?: 0.0,
                            metabolicAge = metabolicAgeText.toIntOrNull() ?: metabolicAgeHint(calculateAge(p.birthDateMillis), bmi),
                            visceralFat = visceralText.toDoubleOrNull() ?: 0.0
                        )
                        scope.launch {
                            if (existing == null) repo.addMeasurement(entity) else repo.updateMeasurement(entity)
                            onSaved()
                        }
                    }
                }, modifier = Modifier.fillMaxWidth()) { Text(if (measurementId == null) "Ölçümü Kaydet" else "Değişiklikleri Kaydet") }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppointmentsScreen(repo: BodyTrackerRepository, patientId: Long, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    val patient by repo.observePatient(patientId).collectAsState(initial = null)
    val appointments by repo.observeAppointments(patientId).collectAsState(initial = emptyList())
    val p = patient ?: return
    var title by rememberSaveable { mutableStateOf("") }
    var note by rememberSaveable { mutableStateOf("") }
    var dateMillis by rememberSaveable { mutableStateOf(System.currentTimeMillis()) }
    var showDatePicker by remember { mutableStateOf(false) }

    if (showDatePicker) {
        ModernDatePicker(initial = dateMillis, title = "Kontrol tarihi seç", onDismiss = { showDatePicker = false }) { dateMillis = it; showDatePicker = false }
    }

    Scaffold(topBar = { SmallTopAppBar(title = { Text("Randevu Takibi") }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) } }) }) { padding ->
        LazyColumn(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("${p.firstName} ${p.lastName}", fontWeight = FontWeight.Bold)
                        Text("Kontrol ve takip randevularını buradan yönetebilirsin.")
                    }
                }
            }
            item { OutlinedTextField(title, { title = it }, Modifier.fillMaxWidth(), label = { Text("Randevu Başlığı") }, leadingIcon = { Icon(Icons.Default.Event, null) }) }
            item { DateField("Randevu Tarihi", formatDate(dateMillis)) { showDatePicker = true } }
            item { OutlinedTextField(note, { note = it }, Modifier.fillMaxWidth().height(120.dp), label = { Text("Not") }) }
            item {
                Button(onClick = {
                    if (title.isNotBlank()) {
                        scope.launch {
                            repo.addAppointment(AppointmentEntity(patientId = patientId, dateMillis = dateMillis, title = title.trim(), note = note.trim()))
                            title = ""
                            note = ""
                            dateMillis = System.currentTimeMillis()
                        }
                    }
                }, modifier = Modifier.fillMaxWidth()) { Text("Randevu Kaydet") }
            }
            item { Text("Kayıtlı Randevular", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
            items(appointments) { appt ->
                Card {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Column {
                                Text(appt.title, fontWeight = FontWeight.SemiBold)
                                Text(formatDate(appt.dateMillis))
                            }
                            IconButton(onClick = { scope.launch { repo.deleteAppointment(appt) } }) { Icon(Icons.Default.Delete, null) }
                        }
                        if (appt.note.isNotBlank()) Text(appt.note)
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DietPlanScreen(repo: BodyTrackerRepository, patientId: Long, onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val patient by repo.observePatient(patientId).collectAsState(initial = null)
    val measurements by repo.observeMeasurements(patientId).collectAsState(initial = emptyList())
    val categories by repo.observeCategories().collectAsState(initial = emptyList())
    val products by repo.observeProducts().collectAsState(initial = emptyList())
    val dietPlans by repo.observeDietPlans(patientId).collectAsState(initial = emptyList())
    val currentPlan = dietPlans.firstOrNull()
    val selectedPlanProducts by if (currentPlan != null) {
        repo.observeDietPlanProducts(currentPlan.id).collectAsState(initial = emptyList())
    } else {
        remember { mutableStateOf(emptyList()) }
    }
    val p = patient ?: return
    val latest = measurements.firstOrNull()

    var goal by rememberSaveable { mutableStateOf("Kilo Kontrolü") }
    var meals by rememberSaveable { mutableStateOf("3 ana öğün + 2 ara öğün") }
    var water by rememberSaveable { mutableStateOf("Günde 2-2.5 litre su") }
    var notes by rememberSaveable { mutableStateOf("") }
    var productQuery by rememberSaveable { mutableStateOf("") }
    var selectedCategoryId by rememberSaveable { mutableStateOf<Long?>(null) }

    val selectedProducts = remember(products, selectedPlanProducts) {
        val ids = selectedPlanProducts.map { it.productId }.toSet()
        products.filter { it.id in ids }
    }
    val filteredProducts = remember(products, categories, productQuery, selectedCategoryId) {
        products.filter { product ->
            val categoryOk = selectedCategoryId == null || product.categoryId == selectedCategoryId
            val q = productQuery.trim().lowercase()
            val queryOk = q.isBlank() || listOf(product.name, product.brand, product.description, product.defaultDose, product.timing)
                .any { it.lowercase().contains(q) }
            categoryOk && queryOk
        }
    }

    val supplementLines = remember(selectedProducts, selectedPlanProducts) {
        selectedProducts.map { product ->
            val item = selectedPlanProducts.firstOrNull { it.productId == product.id }
            val dose = item?.customDose?.takeIf { it.isNotBlank() } ?: product.defaultDose
            val timing = item?.customTiming?.takeIf { it.isNotBlank() } ?: product.timing
            listOf(product.name, dose, timing).filter { it.isNotBlank() }.joinToString(" — ")
        }
    }

    val planText = remember(p, latest, goal, meals, water, notes, supplementLines) {
        generateDietPlanText(p, latest, goal, meals, water, notes, supplementLines)
    }

    fun ensurePlanAndToggle(productId: Long, selected: Boolean, productDefaultDose: String, productTiming: String) {
        scope.launch {
            val planId = currentPlan?.id ?: repo.addDietPlan(
                com.example.bodytracker.data.DietPlanEntity(
                    patientId = patientId,
                    title = "${p.firstName} ${p.lastName} Diyet Planı",
                    description = "Takviye destekli diyet planı"
                )
            )
            val existing = selectedPlanProducts.firstOrNull { it.productId == productId }
            if (selected) {
                if (existing != null) repo.deleteDietPlanProduct(existing)
            } else {
                repo.addDietPlanProduct(
                    com.example.bodytracker.data.DietPlanProductEntity(
                        dietPlanId = planId,
                        productId = productId,
                        customDose = productDefaultDose,
                        customTiming = productTiming,
                        sortOrder = selectedPlanProducts.size + 1
                    )
                )
            }
        }
    }

    Scaffold(topBar = { SmallTopAppBar(title = { Text("Diyet Listesi ve Takviyeler") }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) } }) }) { padding ->
        LazyColumn(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("${p.firstName} ${p.lastName}", fontWeight = FontWeight.Bold)
                        Text("Son ölçüme göre kişiselleştirilmiş plan")
                        Text(latest?.let { "Son ölçüm: ${formatDate(it.dateMillis)} • VKİ ${it.bmi.oneDecimal()}" } ?: "Henüz ölçüm yok. Plan temel profile göre hazırlanır.")
                    }
                }
            }
            item {
                Text("Hedef", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Kilo Verme", "Kilo Kontrolü", "Kas Koruma").forEach { item ->
                        FilterChip(selected = goal == item, onClick = { goal = item }, label = { Text(item) })
                    }
                }
            }
            item { OutlinedTextField(meals, { meals = it }, Modifier.fillMaxWidth(), label = { Text("Öğün Planı") }) }
            item { OutlinedTextField(water, { water = it }, Modifier.fillMaxWidth(), label = { Text("Su Tüketimi") }) }
            item { OutlinedTextField(notes, { notes = it }, Modifier.fillMaxWidth().height(140.dp), label = { Text("Diyetisyen notları") }) }

            item {
                ElevatedCard {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Ürün Listesi", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        OutlinedTextField(
                            value = productQuery,
                            onValueChange = { productQuery = it },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            label = { Text("Ürün ara") },
                            leadingIcon = { Icon(Icons.Default.Search, null) },
                            trailingIcon = {
                                if (productQuery.isNotBlank()) IconButton(onClick = { productQuery = "" }) { Icon(Icons.Default.Close, null) }
                            }
                        )
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(selected = selectedCategoryId == null, onClick = { selectedCategoryId = null }, label = { Text("Tümü") })
                            categories.forEach { cat ->
                                FilterChip(
                                    selected = selectedCategoryId == cat.id,
                                    onClick = { selectedCategoryId = if (selectedCategoryId == cat.id) null else cat.id },
                                    label = { Text(cat.name) },
                                    modifier = Modifier.padding(end = 8.dp)
                                )
                            }
                        }
                        if (filteredProducts.isEmpty()) {
                            Text("Aramana uygun ürün bulunamadı.")
                        } else {
                            filteredProducts.take(30).forEach { product ->
                                val selected = selectedPlanProducts.any { it.productId == product.id }
                                ProductSelectionCard(
                                    product = product,
                                    categoryName = categories.firstOrNull { it.id == product.categoryId }?.name.orEmpty(),
                                    selected = selected,
                                    onToggle = { ensurePlanAndToggle(product.id, selected, product.defaultDose, product.timing) }
                                )
                            }
                        }
                    }
                }
            }

            item {
                ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Seçilen Takviyeler", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        if (selectedProducts.isEmpty()) {
                            Text("Henüz ürün seçilmedi. Üstteki listeden ürün ekleyebilirsin.")
                        } else {
                            selectedProducts.forEach { product ->
                                val item = selectedPlanProducts.firstOrNull { it.productId == product.id }
                                Surface(shape = MaterialTheme.shapes.medium, color = MaterialTheme.colorScheme.surface) {
                                    Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Text(product.name, fontWeight = FontWeight.SemiBold)
                                        if (!product.description.isNullOrBlank()) Text(product.description)
                                        Text("Doz: ${item?.customDose?.ifBlank { product.defaultDose } ?: product.defaultDose}")
                                        Text("Zaman: ${item?.customTiming?.ifBlank { product.timing } ?: product.timing}")
                                    }
                                }
                            }
                        }
                    }
                }
            }

            item {
                ElevatedCard {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Hazırlanan belge", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text(planText)
                    }
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = { shareText(context, planText, p, false) }, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Default.Share, null); Spacer(Modifier.size(6.dp)); Text("Paylaş")
                    }
                    Button(onClick = { shareText(context, planText, p, true) }, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Default.Share, null); Spacer(Modifier.size(6.dp)); Text("WhatsApp")
                    }
                }
            }
            item {
                OutlinedButton(onClick = {
                    val pdf = createDietPdf(context, p, planText)
                    shareFile(context, pdf, p, "application/pdf")
                }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.PictureAsPdf, null); Spacer(Modifier.size(6.dp)); Text("PDF Oluştur ve Paylaş")
                }
            }
        }
    }
}

@Composable
private fun ProductSelectionCard(
    product: com.example.bodytracker.data.ProductEntity,
    categoryName: String,
    selected: Boolean,
    onToggle: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
            .clickable(onClick = onToggle),
        colors = CardDefaults.cardColors(
            containerColor = if (selected) MaterialTheme.colorScheme.tertiaryContainer else MaterialTheme.colorScheme.surface
        )
    ) {
        Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
            if (product.imageUrl.isNotBlank()) {
                AsyncImage(
                    model = product.imageUrl,
                    contentDescription = product.name,
                    modifier = Modifier.size(72.dp),
                    contentScale = ContentScale.Crop
                )
            } else {
                Surface(color = MaterialTheme.colorScheme.primaryContainer, shape = MaterialTheme.shapes.medium, modifier = Modifier.size(72.dp)) {
                    Box(contentAlignment = Alignment.Center) { Text(product.name.take(1), fontWeight = FontWeight.Bold) }
                }
            }
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(product.name, fontWeight = FontWeight.Bold)
                if (categoryName.isNotBlank()) Text(categoryName, color = MaterialTheme.colorScheme.primary)
                if (product.description.isNotBlank()) Text(product.description, maxLines = 2)
                val info = listOf(product.defaultDose, product.timing).filter { it.isNotBlank() }.joinToString(" • ")
                if (info.isNotBlank()) Text(info, style = MaterialTheme.typography.bodySmall)
            }
            Button(onClick = onToggle) {
                Text(if (selected) "Çıkar" else "Ekle")
            }
        }
    }
}

private fun shareText(context: Context, content: String, patient: PatientEntity, whatsappOnly: Boolean) {
    val file = File(context.cacheDir, "diyet_${patient.firstName}_${patient.lastName}.txt")
    file.writeText(content)
    val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, content)
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    try {
        if (whatsappOnly) {
            intent.setPackage("com.whatsapp")
            context.startActivity(intent)
        } else context.startActivity(Intent.createChooser(intent, "Belgeyi paylaş"))
    } catch (_: ActivityNotFoundException) {
        context.startActivity(Intent.createChooser(intent.apply { `package` = null }, "Belgeyi paylaş"))
    }
}

private fun shareFile(context: Context, file: File, patient: PatientEntity, mimeType: String) {
    val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = mimeType
        putExtra(Intent.EXTRA_STREAM, uri)
        putExtra(Intent.EXTRA_SUBJECT, "${patient.firstName} ${patient.lastName} raporu")
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(Intent.createChooser(intent, "Raporu paylaş"))
}

private fun createDietPdf(context: Context, patient: PatientEntity, content: String): File {
    val pdf = PdfDocument()
    val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
    val page = pdf.startPage(pageInfo)
    val canvas = page.canvas
    val titlePaint = Paint().apply { textSize = 20f; isFakeBoldText = true }
    val bodyPaint = Paint().apply { textSize = 12f }
    var y = 40f
    canvas.drawText("Hasta Diyet Planı", 40f, y, titlePaint)
    y += 30f
    canvas.drawText("Hasta: ${patient.firstName} ${patient.lastName}", 40f, y, bodyPaint)
    y += 20f
    canvas.drawText("Tarih: ${formatDate(System.currentTimeMillis())}", 40f, y, bodyPaint)
    y += 30f
    content.lines().forEach { line ->
        canvas.drawText(line.take(90), 40f, y, bodyPaint)
        y += 18f
        if (y > 800f) return@forEach
    }
    pdf.finishPage(page)
    val file = File(context.cacheDir, "diyet_raporu_${patient.firstName}_${patient.lastName}.pdf")
    file.outputStream().use { pdf.writeTo(it) }
    pdf.close()
    return file
}

private fun generateDietPlanText(patient: PatientEntity, latest: MeasurementEntity?, goal: String, meals: String, water: String, notes: String, supplements: List<String>): String {
    val bmiLine = latest?.bmi?.oneDecimal() ?: "-"
    val weightLine = latest?.weightKg?.oneDecimal()?.plus(" kg") ?: "-"
    val fatLine = latest?.bodyFatPercent?.oneDecimal()?.plus("%") ?: "-"
    val visceralLine = latest?.visceralFat?.oneDecimal() ?: "-"
    val focus = when (goal) {
        "Kilo Verme" -> "Rafine şeker ve kızartma azaltılır, porsiyon kontrolü güçlendirilir."
        "Kas Koruma" -> "Protein dağılımı güne yayılır, ana öğünlerde kaliteli protein artırılır."
        else -> "Dengeli tabak modeli ve sürdürülebilir beslenme düzeni korunur."
    }
    return buildString {
        appendLine("HASTA DIYET LISTESI")
        appendLine("Ad Soyad: ${patient.firstName} ${patient.lastName}")
        appendLine("Tarih: ${formatDate(System.currentTimeMillis())}")
        appendLine("Doğum Tarihi: ${formatDate(patient.birthDateMillis)}")
        appendLine("Cinsiyet: ${patient.gender}")
        appendLine("Boy: ${patient.heightCm} cm")
        appendLine("Son Kilo: $weightLine")
        appendLine("VKİ: $bmiLine")
        appendLine("Vücut Yağ Oranı: $fatLine")
        appendLine("İç Yağ: $visceralLine")
        appendLine()
        appendLine("HEDEF")
        appendLine(goal)
        appendLine()
        appendLine("BESLENME PLANLARI")
        appendLine("- $meals")
        appendLine("- Kahvaltıda protein kaynağı, öğle ve akşamda sebze + ana protein dengesi")
        appendLine("- Paketli atıştırmalık yerine yoğurt, kefir, meyve veya çiğ kuruyemiş")
        appendLine("- $water")
        appendLine("- $focus")
        appendLine()
        appendLine("TAKVIYELER")
        if (supplements.isEmpty()) {
            appendLine("- Ek takviye seçilmedi")
        } else {
            supplements.forEach { appendLine("- $it") }
        }
        appendLine()
        appendLine("IZLEME NOTLARI")
        appendLine("- Haftalık kilo ve iştah takibi yapılır")
        appendLine("- Bir sonraki kontrolde önceki ölçümle kıyas önerilir")
        if (notes.isNotBlank()) appendLine("- Uzman notu: $notes")
    }
}


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AboutScreen(onBack: () -> Unit) {
    Scaffold(
        topBar = {
            SmallTopAppBar(
                title = { Text("Uygulama Hakkında") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) } }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                    Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Vücut Analiz Takip Pro", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        Text("Profesyonel hasta takip, ölçüm karşılaştırma, diyet planı ve paylaşım uygulaması")
                    }
                }
            }
            item {
                ElevatedCard {
                    Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Yapan: Barış Göral", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Text("Sürüm: 10.0")
                        Text("Öne çıkanlar: kamera desteği, hasta arama, otomatik VKİ, PDF rapor, WhatsApp paylaşımı, randevu takibi ve diyet planı.")
                    }
                }
            }
            item {
                ElevatedCard {
                    Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Sonraki geliştirmeler", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text("• Bulut yedekleme\n• Ölçüm grafiklerini çoğaltma\n• Randevu hatırlatma bildirimi\n• Çoklu uzman profili\n• PDF üst bilgi ve kurum logosu")
                    }
                }
            }
        }
    }
}

private fun saveBitmapToCache(context: Context, bitmap: Bitmap): Uri? {
    return runCatching {
        val file = File(context.cacheDir, "camera_${System.currentTimeMillis()}.jpg")
        FileOutputStream(file).use { out ->
            bitmap.compress(Bitmap.CompressFormat.JPEG, 92, out)
        }
        Uri.fromFile(file)
    }.getOrNull()
}

@Composable
fun QuickActionCard(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier, onClick: () -> Unit) {
    ElevatedCard(modifier = modifier.clickable(onClick = onClick)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(icon, null)
            Text(title, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
fun TrendChartCard(measurements: List<MeasurementEntity>) {
    if (measurements.size < 2) return
    val primaryColor = MaterialTheme.colorScheme.primary
    val surfaceVariantColor = MaterialTheme.colorScheme.surfaceVariant
    val cardShape = MaterialTheme.shapes.medium
    ElevatedCard {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Kilo trend grafiği", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text("Son ${measurements.size} ölçümün görsel takibi")
            Canvas(modifier = Modifier.fillMaxWidth().height(180.dp).background(surfaceVariantColor, cardShape)) {
                val sorted = measurements.sortedBy { it.dateMillis }
                val weights = sorted.map { it.weightKg.toFloat() }
                val min = weights.minOrNull() ?: 0f
                val max = weights.maxOrNull() ?: 1f
                val range = (max - min).takeIf { it > 0 } ?: 1f
                val stepX = size.width / (weights.size - 1).coerceAtLeast(1)
                var prev: Offset? = null
                weights.forEachIndexed { index, value ->
                    val x = stepX * index
                    val y = size.height - ((value - min) / range) * (size.height - 20f) - 10f
                    val point = Offset(x, y)
                    drawCircle(color = primaryColor, radius = 6f, center = point)
                    prev?.let { drawLine(primaryColor, it, point, strokeWidth = 6f, cap = StrokeCap.Round) }
                    prev = point
                }
                drawRect(color = Color.Gray.copy(alpha = 0.2f), style = Stroke(2f))
            }
        }
    }
}

@Composable
fun PatientPhotoCard(photoUri: String?, onCamera: () -> Unit, onGallery: () -> Unit) {
    ElevatedCard {
        Column(Modifier.fillMaxWidth().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Surface(modifier = Modifier.height(150.dp).fillMaxWidth(), shape = MaterialTheme.shapes.large, color = MaterialTheme.colorScheme.surfaceVariant) {
                if (photoUri != null) {
                    AsyncImage(model = photoUri, contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                } else {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Column(horizontalAlignment = Alignment.CenterHorizontally) { Icon(Icons.Default.Person, null); Text("Hasta fotoğrafı") } }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onCamera) { Icon(Icons.Default.CameraAlt, null); Spacer(Modifier.size(6.dp)); Text("Kamera") }
                OutlinedButton(onClick = onGallery) { Icon(Icons.Default.PhotoLibrary, null); Spacer(Modifier.size(6.dp)); Text("Galeri") }
            }
        }
    }
}

@Composable
fun NumericField(label: String, value: String, onValue: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = { onValue(it.filter { ch -> ch.isDigit() || ch == '.' || ch == ',' }.replace(',', '.')) },
        modifier = Modifier.fillMaxWidth(),
        label = { Text(label) },
        leadingIcon = { Icon(Icons.Default.QueryStats, null) },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        singleLine = true
    )
}

@Composable
fun DateField(label: String, value: String, onClick: () -> Unit) {
    OutlinedButton(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.CalendarMonth, null); Text(label) }
            Text(value)
        }
    }
}


@Composable
fun ReferenceStatusCard(title: String, status: ReferenceStatus) {
    val container = when (status.level) {
        ReferenceLevel.NORMAL -> MaterialTheme.colorScheme.secondaryContainer
        ReferenceLevel.LOW -> MaterialTheme.colorScheme.tertiaryContainer
        ReferenceLevel.HIGH -> MaterialTheme.colorScheme.errorContainer
        ReferenceLevel.INFO -> MaterialTheme.colorScheme.primaryContainer
    }
    ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = container)) {
        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text("Referans: ${status.rangeLabel}")
            Text(status.statusText, fontWeight = FontWeight.Bold)
            if (status.detail.isNotBlank()) {
                Text(status.detail, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ModernDatePicker(initial: Long, title: String, onDismiss: () -> Unit, onConfirm: (Long) -> Unit) {
    val state = rememberDatePickerState(initialSelectedDateMillis = initial)
    DatePickerDialog(onDismissRequest = onDismiss, confirmButton = { TextButton(onClick = { onConfirm(state.selectedDateMillis ?: initial) }) { Text("Tamam") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("İptal") } }) {
        Column {
            Text(title, modifier = Modifier.padding(16.dp), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            DatePicker(state = state)
        }
    }
}


private fun referenceForMetric(label: String, value: Double, patient: PatientEntity, measurement: MeasurementEntity): ReferenceStatus {
    val age = calculateAge(patient.birthDateMillis)
    return when (label) {
        "Kilo" -> weightReferenceStatus(value, patient.heightCm)
        "VKİ" -> bmiReferenceStatus(value)
        "Yağ" -> bodyFatReferenceStatus(patient.gender, age, value)
        "Sıvı" -> bodyWaterReferenceStatus(patient.gender, value)
        "Kas" -> muscleReferenceStatus(patient.gender, value)
        "Aktivite" -> activityReferenceStatus(value)
        "Kemik" -> boneReferenceStatus(patient.gender, value)
        "Met. Hızı" -> metabolicRateReferenceStatus(patient.gender, age, patient.heightCm, measurement.weightKg, value)
        "Met. Yaşı" -> metabolicAgeReferenceStatus(age, value.toInt())
        "İç Yağ" -> visceralFatReferenceStatus(value)
        else -> ReferenceStatus("Kişiye göre değişir", "Takip amaçlı gösterim", ReferenceLevel.INFO)
    }
}

@Composable
fun ComparisonOverview(latest: MeasurementEntity, previous: MeasurementEntity?, previousMonth: MeasurementEntity?, olderMeasurements: List<MeasurementEntity>) {
    val average = olderMeasurements.takeIf { it.isNotEmpty() }?.let { list ->
        MeasurementEntity(
            patientId = latest.patientId,
            dateMillis = list.last().dateMillis,
            weightKg = list.map { it.weightKg }.average(),
            bmi = list.map { it.bmi }.average(),
            bodyFatPercent = list.map { it.bodyFatPercent }.average(),
            bodyWaterPercent = list.map { it.bodyWaterPercent }.average(),
            muscle = list.map { it.muscle }.average(),
            physicalActivity = list.map { it.physicalActivity }.average(),
            bone = list.map { it.bone }.average(),
            metabolicRate = list.map { it.metabolicRate }.average(),
            metabolicAge = list.map { it.metabolicAge }.average().toInt(),
            visceralFat = list.map { it.visceralFat }.average()
        )
    }
    ElevatedCard {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Detaylı Kıyas Özeti", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text("Son ölçüm: ${formatDate(latest.dateMillis)}")
            HorizontalDivider()
            MetricComparisonRow("Kilo", latest.weightKg, "kg", previous?.weightKg, previousMonth?.weightKg, average?.weightKg)
            MetricComparisonRow("VKİ", latest.bmi, "", previous?.bmi, previousMonth?.bmi, average?.bmi)
            MetricComparisonRow("Yağ", latest.bodyFatPercent, "%", previous?.bodyFatPercent, previousMonth?.bodyFatPercent, average?.bodyFatPercent)
            MetricComparisonRow("Sıvı", latest.bodyWaterPercent, "%", previous?.bodyWaterPercent, previousMonth?.bodyWaterPercent, average?.bodyWaterPercent)
            MetricComparisonRow("Kas", latest.muscle, "", previous?.muscle, previousMonth?.muscle, average?.muscle)
            MetricComparisonRow("Aktivite", latest.physicalActivity, "", previous?.physicalActivity, previousMonth?.physicalActivity, average?.physicalActivity)
            MetricComparisonRow("Kemik", latest.bone, "", previous?.bone, previousMonth?.bone, average?.bone)
            MetricComparisonRow("Met. Hızı", latest.metabolicRate, "", previous?.metabolicRate, previousMonth?.metabolicRate, average?.metabolicRate)
            MetricComparisonRow("Met. Yaşı", latest.metabolicAge.toDouble(), "", previous?.metabolicAge?.toDouble(), previousMonth?.metabolicAge?.toDouble(), average?.metabolicAge?.toDouble())
            MetricComparisonRow("İç Yağ", latest.visceralFat, "", previous?.visceralFat, previousMonth?.visceralFat, average?.visceralFat)
        }
    }
}

@Composable
fun MetricComparisonRow(label: String, current: Double, unit: String, previous: Double?, previousMonth: Double?, averagePrevious: Double?) {
    ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(label, fontWeight = FontWeight.Bold)
            Text("Güncel: ${current.oneDecimal()}${if (unit.isNotBlank()) " $unit" else ""}", style = MaterialTheme.typography.titleMedium)
            Text("Önceki kayıt: ${previous?.let { deltaText(current, it, unit).ifBlank { current.oneDecimal() } } ?: "Yok"}")
            Text("Önceki ay: ${previousMonth?.let { deltaText(current, it, unit).ifBlank { current.oneDecimal() } } ?: "Yok"}")
            Text("Tüm önceki kayıt ort.: ${averagePrevious?.let { deltaText(current, it, unit).ifBlank { current.oneDecimal() } } ?: "Yok"}")
        }
    }
}

@Composable
fun MetricChartsSection(measurements: List<MeasurementEntity>) {
    if (measurements.size < 2) return
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Ayrı Grafik Detayları", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        SimpleMetricChartCard("Kilo Grafiği", measurements) { it.weightKg }
        SimpleMetricChartCard("VKİ Grafiği", measurements) { it.bmi }
        SimpleMetricChartCard("Yağ Oranı Grafiği", measurements) { it.bodyFatPercent }
        SimpleMetricChartCard("Sıvı Oranı Grafiği", measurements) { it.bodyWaterPercent }
        SimpleMetricChartCard("Kas Grafiği", measurements) { it.muscle }
        SimpleMetricChartCard("Aktivite Grafiği", measurements) { it.physicalActivity }
        SimpleMetricChartCard("Kemik Grafiği", measurements) { it.bone }
        SimpleMetricChartCard("Metabolizma Hızı Grafiği", measurements) { it.metabolicRate }
        SimpleMetricChartCard("Metabolizma Yaşı Grafiği", measurements) { it.metabolicAge.toDouble() }
        SimpleMetricChartCard("İç Yağ Grafiği", measurements) { it.visceralFat }
    }
}

@Composable
fun SimpleMetricChartCard(title: String, measurements: List<MeasurementEntity>, metric: (MeasurementEntity) -> Double) {
    val points = measurements.sortedBy { it.dateMillis }.map(metric)
    if (points.size < 2) return
    val lineColor = MaterialTheme.colorScheme.primary
    val bgColor = MaterialTheme.colorScheme.surfaceVariant
    val shape = MaterialTheme.shapes.medium
    ElevatedCard {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text("Toplam ${points.size} kayıt üzerinden karşılaştırma")
            Canvas(modifier = Modifier.fillMaxWidth().height(150.dp).background(bgColor, shape)) {
                val values = points.map { it.toFloat() }
                val min = values.minOrNull() ?: 0f
                val max = values.maxOrNull() ?: 1f
                val range = (max - min).takeIf { it > 0f } ?: 1f
                val stepX = size.width / (values.size - 1).coerceAtLeast(1)
                var prev: Offset? = null
                values.forEachIndexed { index, value ->
                    val x = stepX * index
                    val y = size.height - ((value - min) / range) * (size.height - 20f) - 10f
                    val point = Offset(x, y)
                    drawCircle(color = lineColor, radius = 5f, center = point)
                    prev?.let { drawLine(lineColor, it, point, strokeWidth = 5f, cap = StrokeCap.Round) }
                    prev = point
                }
                drawRect(color = Color.Gray.copy(alpha = 0.2f), style = Stroke(2f))
            }
        }
    }
}

@Composable
fun MetricGrid(patient: PatientEntity, m: MeasurementEntity) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Ölçüm Kartları ve Referans", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        val items = listOf(
            Triple("Kilo", m.weightKg, "kg"),
            Triple("VKİ", m.bmi, ""),
            Triple("Yağ", m.bodyFatPercent, "%"),
            Triple("Sıvı", m.bodyWaterPercent, "%"),
            Triple("Kas", m.muscle, ""),
            Triple("Aktivite", m.physicalActivity, ""),
            Triple("Kemik", m.bone, ""),
            Triple("Met. Hızı", m.metabolicRate, "kcal"),
            Triple("Met. Yaşı", m.metabolicAge.toDouble(), ""),
            Triple("İç Yağ", m.visceralFat, "")
        )
        items.chunked(2).forEach { rowItems ->
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                rowItems.forEach { (title, value, unit) ->
                    val status = referenceForMetric(title, value, patient, m)
                    ElevatedCard(modifier = Modifier.weight(1f)) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(title, fontWeight = FontWeight.SemiBold)
                            Text(
                                if (unit.isBlank()) value.oneDecimal() else "${value.oneDecimal()} $unit",
                                style = MaterialTheme.typography.titleLarge
                            )
                            Text("Referans: ${status.rangeLabel}", style = MaterialTheme.typography.bodySmall)
                            Text(status.statusText, fontWeight = FontWeight.Bold,
                                color = when (status.level) {
                                    ReferenceLevel.NORMAL -> MaterialTheme.colorScheme.primary
                                    ReferenceLevel.LOW -> MaterialTheme.colorScheme.tertiary
                                    ReferenceLevel.HIGH -> MaterialTheme.colorScheme.error
                                    ReferenceLevel.INFO -> MaterialTheme.colorScheme.primary
                                }
                            )
                            if (status.detail.isNotBlank()) {
                                Text(status.detail, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
                if (rowItems.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}
