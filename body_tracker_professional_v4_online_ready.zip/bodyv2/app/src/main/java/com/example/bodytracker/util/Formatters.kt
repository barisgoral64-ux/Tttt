package com.example.bodytracker.util

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

private val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())

fun formatDate(millis: Long): String = dateFormat.format(Date(millis))

fun calculateAge(birthMillis: Long): Int {
    val birth = Calendar.getInstance().apply { timeInMillis = birthMillis }
    val today = Calendar.getInstance()
    var age = today.get(Calendar.YEAR) - birth.get(Calendar.YEAR)
    if (today.get(Calendar.DAY_OF_YEAR) < birth.get(Calendar.DAY_OF_YEAR)) age--
    return age.coerceAtLeast(0)
}

fun calculateBmi(weightKg: Double, heightCm: Int): Double {
    val heightM = heightCm / 100.0
    return if (heightM > 0) weightKg / (heightM * heightM) else 0.0
}

fun Double.oneDecimal(): String = String.format(Locale.getDefault(), "%.1f", this)

fun deltaText(current: Double, previous: Double, unit: String): String {
    val delta = current - previous
    val sign = if (delta > 0) "+" else ""
    return "$sign${String.format(Locale.getDefault(), "%.1f", delta)} $unit"
}

fun metabolicAgeHint(age: Int, bmi: Double): Int = (age + (bmi - 21.0).roundToInt()).coerceAtLeast(1)
