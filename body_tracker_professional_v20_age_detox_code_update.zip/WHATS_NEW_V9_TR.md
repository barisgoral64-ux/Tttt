V9 Güncellemesi
- Hasta arama ekranı profesyonel hale getirildi
- Hasta kartları fotoğraf, yaş, boy ve cinsiyet rozetleriyle yenilendi
- Arama alanına temizle butonu ve boş sonuç ekranı eklendi
- Karta dokununca detay açma akışı korunarak daha görünür hale getirildi
