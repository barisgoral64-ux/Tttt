# V17 Yenilikleri

- Takviye ürün kartlarına boş görsel olduğunda kategori bazlı görsel yer tutucu eklendi
- Forever ürün seed listesi genişletildi
- Randevuya saat alanları eklendi
- Randevu kaydedildiğinde tarih+saat için bildirim planlama eklendi
- Bildirim içeriğinde hasta adı, başlık, tarih-saat ve not bilgisi gösterilir
- Bildirim için Ertele ve Tamam aksiyonları eklendi
- Randevu listesinde Ertele ve Tamam butonları eklendi
