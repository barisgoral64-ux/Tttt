package com.example.bodytracker.backup

import android.content.Context
import java.io.File

object DatabaseBackupManager {
    fun exportDatabaseCopy(context: Context): File {
        val db = context.getDatabasePath("body_tracker.db")
        val exportDir = File(context.filesDir, "backups").apply { mkdirs() }
        val out = File(exportDir, "body_tracker_backup_latest.db")
        db.copyTo(out, overwrite = true)
        db.resolveSibling("body_tracker.db-wal").takeIf { it.exists() }?.copyTo(File(exportDir, "body_tracker_backup_latest.db-wal"), overwrite = true)
        db.resolveSibling("body_tracker.db-shm").takeIf { it.exists() }?.copyTo(File(exportDir, "body_tracker_backup_latest.db-shm"), overwrite = true)
        return out
    }
}
