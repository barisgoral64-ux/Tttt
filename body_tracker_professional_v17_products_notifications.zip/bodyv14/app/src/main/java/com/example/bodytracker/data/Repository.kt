package com.example.bodytracker.data

import kotlinx.coroutines.flow.Flow

class BodyTrackerRepository(
    private val patientDao: PatientDao,
    private val measurementDao: MeasurementDao,
    private val appointmentDao: AppointmentDao,
    private val productCategoryDao: ProductCategoryDao,
    private val productDao: ProductDao,
    private val dietPlanDao: DietPlanDao,
    private val dietPlanProductDao: DietPlanProductDao,
    private val appSettingDao: AppSettingDao
) {
    fun observePatients(): Flow<List<PatientEntity>> = patientDao.observePatients()
    fun observePatient(id: Long): Flow<PatientEntity?> = patientDao.observePatient(id)
    fun observeMeasurements(patientId: Long): Flow<List<MeasurementEntity>> = measurementDao.observeMeasurements(patientId)
    fun observeMeasurement(id: Long): Flow<MeasurementEntity?> = measurementDao.observeMeasurement(id)
    fun observeAppointments(patientId: Long): Flow<List<AppointmentEntity>> = appointmentDao.observeAppointments(patientId)
    fun observeCategories(): Flow<List<ProductCategoryEntity>> = productCategoryDao.observeCategories()
    fun observeProducts(): Flow<List<ProductEntity>> = productDao.observeProducts()
    fun observeProductsByCategory(categoryId: Long): Flow<List<ProductEntity>> = productDao.observeProductsByCategory(categoryId)
    fun observeDietPlans(patientId: Long): Flow<List<DietPlanEntity>> = dietPlanDao.observeDietPlans(patientId)
    fun observeDietPlanProducts(dietPlanId: Long): Flow<List<DietPlanProductEntity>> = dietPlanProductDao.observeDietPlanProducts(dietPlanId)

    suspend fun addPatient(patient: PatientEntity): Long = patientDao.insert(patient)
    suspend fun updatePatient(patient: PatientEntity) = patientDao.update(patient)
    suspend fun deletePatient(patient: PatientEntity) = patientDao.delete(patient)

    suspend fun addMeasurement(measurement: MeasurementEntity): Long = measurementDao.insert(measurement)
    suspend fun updateMeasurement(measurement: MeasurementEntity) = measurementDao.update(measurement)
    suspend fun deleteMeasurement(measurement: MeasurementEntity) = measurementDao.delete(measurement)

    suspend fun addAppointment(appointment: AppointmentEntity): Long = appointmentDao.insert(appointment)
    suspend fun updateAppointment(appointment: AppointmentEntity) = appointmentDao.update(appointment)
    suspend fun deleteAppointment(appointment: AppointmentEntity) = appointmentDao.delete(appointment)

    suspend fun addCategory(category: ProductCategoryEntity): Long = productCategoryDao.insert(category)
    suspend fun updateCategory(category: ProductCategoryEntity) = productCategoryDao.update(category)
    suspend fun deleteCategory(category: ProductCategoryEntity) = productCategoryDao.delete(category)

    suspend fun addProduct(product: ProductEntity): Long = productDao.insert(product)
    suspend fun updateProduct(product: ProductEntity) = productDao.update(product)
    suspend fun deleteProduct(product: ProductEntity) = productDao.delete(product)

    suspend fun addDietPlan(dietPlan: DietPlanEntity): Long = dietPlanDao.insert(dietPlan)
    suspend fun updateDietPlan(dietPlan: DietPlanEntity) = dietPlanDao.update(dietPlan)
    suspend fun deleteDietPlan(dietPlan: DietPlanEntity) = dietPlanDao.delete(dietPlan)

    suspend fun addDietPlanProduct(item: DietPlanProductEntity): Long = dietPlanProductDao.insert(item)
    suspend fun updateDietPlanProduct(item: DietPlanProductEntity) = dietPlanProductDao.update(item)
    suspend fun deleteDietPlanProduct(item: DietPlanProductEntity) = dietPlanProductDao.delete(item)

    suspend fun updateLastBackupTimestamp(timestamp: Long) {
        appSettingDao.upsert(
            AppSettingEntity(
                key = "last_backup_ts",
                value = timestamp.toString(),
                updatedAt = timestamp
            )
        )
    }

    suspend fun getLastBackupTimestamp(): Long? =
        appSettingDao.get("last_backup_ts")?.value?.toLongOrNull()

    suspend fun ensureSeededProducts() {
        if (productDao.countProducts() > 0) return

        val categoryMap = mutableMapOf<String, Long>()
        ForeverSeedData.categories.forEach { category ->
            val id = productCategoryDao.insert(
                ProductCategoryEntity(
                    name = category.name,
                    iconName = category.iconName,
                    sortOrder = category.sortOrder
                )
            )
            categoryMap[category.name] = id
        }

        ForeverSeedData.products.forEach { product ->
            productDao.insert(
                ProductEntity(
                    name = product.name,
                    brand = "Forever",
                    categoryId = categoryMap[product.category],
                    imageUrl = product.imageUrl,
                    sourceUrl = product.sourceUrl,
                    description = product.description,
                    usageNote = product.usageNote,
                    defaultDose = product.defaultDose,
                    timing = product.timing
                )
            )
        }
    }
}
