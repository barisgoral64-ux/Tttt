package com.example.bodytracker.util

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

enum class ReferenceLevel { LOW, NORMAL, HIGH, INFO }

data class ReferenceStatus(
    val rangeLabel: String,
    val statusText: String,
    val level: ReferenceLevel,
    val detail: String = ""
)

private val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
private val dateTimeFormat = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())

fun formatDate(millis: Long): String = dateFormat.format(Date(millis))
fun formatDateTime(millis: Long): String = dateTimeFormat.format(Date(millis))

fun combineDateAndTime(dateMillis: Long, hour: Int, minute: Int): Long {
    val cal = Calendar.getInstance().apply { timeInMillis = dateMillis }
    cal.set(Calendar.HOUR_OF_DAY, hour.coerceIn(0, 23))
    cal.set(Calendar.MINUTE, minute.coerceIn(0, 59))
    cal.set(Calendar.SECOND, 0)
    cal.set(Calendar.MILLISECOND, 0)
    return cal.timeInMillis
}

fun calculateAge(birthMillis: Long): Int {
    val birth = Calendar.getInstance().apply { timeInMillis = birthMillis }
    val today = Calendar.getInstance()
    var age = today.get(Calendar.YEAR) - birth.get(Calendar.YEAR)
    if (today.get(Calendar.DAY_OF_YEAR) < birth.get(Calendar.DAY_OF_YEAR)) age--
    return age.coerceAtLeast(0)
}

fun calculateBmi(weightKg: Double, heightCm: Int): Double {
    val heightM = heightCm / 100.0
    return if (heightM > 0) weightKg / (heightM * heightM) else 0.0
}

fun Double.oneDecimal(): String = String.format(Locale.getDefault(), "%.1f", this)

fun deltaText(current: Double, previous: Double, unit: String): String {
    val delta = current - previous
    val sign = if (delta > 0) "+" else ""
    return "$sign${String.format(Locale.getDefault(), "%.1f", delta)} $unit"
}

fun metabolicAgeHint(age: Int, bmi: Double): Int = (age + (bmi - 21.0).roundToInt()).coerceAtLeast(1)

private fun statusForRange(value: Double, min: Double, max: Double, detail: String = ""): ReferenceStatus = when {
    value < min -> ReferenceStatus("${min.oneDecimal()} - ${max.oneDecimal()}", "Referans aralığının altında", ReferenceLevel.LOW, detail)
    value > max -> ReferenceStatus("${min.oneDecimal()} - ${max.oneDecimal()}", "Referans aralığının üstünde", ReferenceLevel.HIGH, detail)
    else -> ReferenceStatus("${min.oneDecimal()} - ${max.oneDecimal()}", "Referans aralığında", ReferenceLevel.NORMAL, detail)
}

fun bmiReferenceStatus(bmi: Double): ReferenceStatus = when {
    bmi < 20.0 -> ReferenceStatus("20.0 - 24.0", "Referans aralığının altında", ReferenceLevel.LOW, "Hedef VKİ aralığının altında")
    bmi <= 24.0 -> ReferenceStatus("20.0 - 24.0", "Referans aralığında", ReferenceLevel.NORMAL, "Hedef VKİ aralığında")
    else -> ReferenceStatus("20.0 - 24.0", "Referans aralığının üstünde", ReferenceLevel.HIGH, "VKİ hedef aralığının üstünde")
}

fun weightReferenceStatus(weightKg: Double, heightCm: Int): ReferenceStatus {
    val h = heightCm / 100.0
    val min = 20.0 * h * h
    val max = 24.0 * h * h
    return statusForRange(weightKg, min, max, "Boy bilgisine göre hedef kilo aralığı")
}

fun bodyFatReferenceStatus(gender: String, age: Int, value: Double): ReferenceStatus = when {
    value <= 27.0 -> ReferenceStatus("≤ 27.0", "Hedefe uygun", ReferenceLevel.NORMAL, "Vücut yağ oranı hedefte")
    value <= 32.0 -> ReferenceStatus("≤ 27.0", "Hedefin üstünde", ReferenceLevel.HIGH, "Yağ oranı düşürülmeli")
    else -> ReferenceStatus("≤ 27.0", "Belirgin yüksek", ReferenceLevel.HIGH, "Takip ve plan sıkılaştırılmalı")
}

fun bodyWaterReferenceStatus(gender: String, value: Double): ReferenceStatus = when {
    value >= 55.0 -> ReferenceStatus("≥ 55.0", "Hedefe uygun", ReferenceLevel.NORMAL, "Vücut sıvı oranı hedefte")
    value >= 50.0 -> ReferenceStatus("≥ 55.0", "Hedefin altında", ReferenceLevel.LOW, "Sıvı oranı desteklenmeli")
    else -> ReferenceStatus("≥ 55.0", "Belirgin düşük", ReferenceLevel.LOW, "Sıvı takibi artırılmalı")
}

fun visceralFatReferenceStatus(value: Double): ReferenceStatus = when {
    value <= 5.0 -> ReferenceStatus("≤ 5.0", "Hedefe uygun", ReferenceLevel.NORMAL, "İç yağ seviyesi hedefte")
    value <= 9.0 -> ReferenceStatus("≤ 5.0", "Sınırın üstünde", ReferenceLevel.HIGH, "İç yağ azaltılmalı")
    else -> ReferenceStatus("≤ 5.0", "Yüksek", ReferenceLevel.HIGH, "İç yağ takibi gerekli")
}

fun metabolicAgeReferenceStatus(actualAge: Int, metabolicAge: Int): ReferenceStatus = when {
    metabolicAge < actualAge -> ReferenceStatus("Gerçek yaş: $actualAge", "Gerçek yaşın altında", ReferenceLevel.NORMAL, "Olumlu metabolik yaş görünümü")
    metabolicAge == actualAge -> ReferenceStatus("Gerçek yaş: $actualAge", "Gerçek yaş ile uyumlu", ReferenceLevel.NORMAL, "Beklenen aralıkta")
    else -> ReferenceStatus("Gerçek yaş: $actualAge", "Gerçek yaşın üstünde", ReferenceLevel.HIGH, "Yaşam tarzı takibi önerilir")
}

fun metabolicRateReferenceStatus(gender: String, age: Int, heightCm: Int, weightKg: Double, metabolicRate: Double): ReferenceStatus = when {
    metabolicRate in 1500.0..1700.0 -> ReferenceStatus("1600 kcal", "Hedefe yakın", ReferenceLevel.NORMAL, "Metabolizma hızı hedef banda yakın")
    metabolicRate < 1500.0 -> ReferenceStatus("1600 kcal", "Hedefin altında", ReferenceLevel.LOW, "Metabolizma hızı düşük görünüyor")
    else -> ReferenceStatus("1600 kcal", "Hedefin üstünde", ReferenceLevel.INFO, "Metabolizma hızı hedefin üstünde")
}

fun muscleReferenceStatus(gender: String, value: Double): ReferenceStatus = when {
    value >= 55.0 -> ReferenceStatus("Kas hedefi: güçlü", "İyi seviyede", ReferenceLevel.NORMAL, "Kas oranı iyi görünüyor")
    value >= 45.0 -> ReferenceStatus("Kas hedefi: güçlü", "Takip gerekli", ReferenceLevel.INFO, "Kas desteği artırılabilir")
    else -> ReferenceStatus("Kas hedefi: güçlü", "Düşük", ReferenceLevel.LOW, "Kas gelişimi desteklenmeli")
}

fun kpsReferenceStatus(weightKg: Double, muscleKg: Double): ReferenceStatus {
    val diff = kotlin.math.abs(weightKg - muscleKg)
    return when {
        diff <= 15.0 -> ReferenceStatus("≤ 15.0", "Hedefe uygun", ReferenceLevel.NORMAL, "Kilo-kas farkı hedefte")
        diff <= 20.0 -> ReferenceStatus("≤ 15.0", "Sınırın üstünde", ReferenceLevel.HIGH, "Kilo-kas farkı azaltılmalı")
        else -> ReferenceStatus("≤ 15.0", "Yüksek", ReferenceLevel.HIGH, "Kilo-kas farkı belirgin")
    }
}

fun activityReferenceStatus(value: Double): ReferenceStatus = when {
    value in 4.0..6.0 -> ReferenceStatus("5", "Hedefe uygun", ReferenceLevel.NORMAL, "Fiziksel aktivite hedefe yakın")
    value < 4.0 -> ReferenceStatus("5", "Hedefin altında", ReferenceLevel.LOW, "Aktivite seviyesi artırılabilir")
    else -> ReferenceStatus("5", "Hedefin üstünde", ReferenceLevel.INFO, "Aktivite seviyesi yüksek")
}

fun boneReferenceStatus(gender: String, value: Double): ReferenceStatus = when {
    value in 2.5..2.9 -> ReferenceStatus("2.7", "Hedefe uygun", ReferenceLevel.NORMAL, "Kemik değeri hedefe yakın")
    value < 2.5 -> ReferenceStatus("2.7", "Hedefin altında", ReferenceLevel.LOW, "Kemik desteği takip edilmeli")
    else -> ReferenceStatus("2.7", "Hedefin üstünde", ReferenceLevel.INFO, "Kemik değeri hedefin üstünde")
}
