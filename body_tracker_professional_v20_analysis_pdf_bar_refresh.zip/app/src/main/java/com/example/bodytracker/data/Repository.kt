package com.example.bodytracker.data

import kotlinx.coroutines.flow.Flow

class BodyTrackerRepository(
    private val patientDao: PatientDao,
    private val measurementDao: MeasurementDao,
    private val appointmentDao: AppointmentDao,
    private val productCategoryDao: ProductCategoryDao,
    private val productDao: ProductDao,
    private val dietPlanDao: DietPlanDao,
    private val dietPlanProductDao: DietPlanProductDao,
    private val appSettingDao: AppSettingDao
) {
    private fun deriveProductCode(imageUrl: String): String {
        val fileName = imageUrl.substringAfterLast('/')
        return fileName.takeWhile { it.isDigit() }
    }

    fun observePatients(): Flow<List<PatientEntity>> = patientDao.observePatients()
    fun observePatient(id: Long): Flow<PatientEntity?> = patientDao.observePatient(id)
    fun observeMeasurements(patientId: Long): Flow<List<MeasurementEntity>> = measurementDao.observeMeasurements(patientId)
    fun observeMeasurement(id: Long): Flow<MeasurementEntity?> = measurementDao.observeMeasurement(id)
    fun observeAppointments(patientId: Long): Flow<List<AppointmentEntity>> = appointmentDao.observeAppointments(patientId)
    fun observeCategories(): Flow<List<ProductCategoryEntity>> = productCategoryDao.observeCategories()
    fun observeProducts(): Flow<List<ProductEntity>> = productDao.observeProducts()
    fun observeProductsByCategory(categoryId: Long): Flow<List<ProductEntity>> = productDao.observeProductsByCategory(categoryId)
    fun observeDietPlans(patientId: Long): Flow<List<DietPlanEntity>> = dietPlanDao.observeDietPlans(patientId)
    fun observeDietPlanProducts(dietPlanId: Long): Flow<List<DietPlanProductEntity>> = dietPlanProductDao.observeDietPlanProducts(dietPlanId)
    suspend fun getDietPlanProductsNow(dietPlanId: Long): List<DietPlanProductEntity> = dietPlanProductDao.getDietPlanProductsNow(dietPlanId)

    suspend fun addPatient(patient: PatientEntity): Long = patientDao.insert(patient)
    suspend fun updatePatient(patient: PatientEntity) = patientDao.update(patient)
    suspend fun deletePatient(patient: PatientEntity) = patientDao.delete(patient)

    suspend fun addMeasurement(measurement: MeasurementEntity): Long = measurementDao.insert(measurement)
    suspend fun updateMeasurement(measurement: MeasurementEntity) = measurementDao.update(measurement)
    suspend fun deleteMeasurement(measurement: MeasurementEntity) = measurementDao.delete(measurement)

    suspend fun addAppointment(appointment: AppointmentEntity): Long = appointmentDao.insert(appointment)
    suspend fun updateAppointment(appointment: AppointmentEntity) = appointmentDao.update(appointment)
    suspend fun deleteAppointment(appointment: AppointmentEntity) = appointmentDao.delete(appointment)

    suspend fun addCategory(category: ProductCategoryEntity): Long = productCategoryDao.insert(category)
    suspend fun updateCategory(category: ProductCategoryEntity) = productCategoryDao.update(category)
    suspend fun deleteCategory(category: ProductCategoryEntity) = productCategoryDao.delete(category)

    suspend fun addProduct(product: ProductEntity): Long = productDao.insert(product)
    suspend fun updateProduct(product: ProductEntity) = productDao.update(product)
    suspend fun deleteProduct(product: ProductEntity) = productDao.delete(product)

    suspend fun addDietPlan(dietPlan: DietPlanEntity): Long = dietPlanDao.insert(dietPlan)
    suspend fun updateDietPlan(dietPlan: DietPlanEntity) = dietPlanDao.update(dietPlan)
    suspend fun deleteDietPlan(dietPlan: DietPlanEntity) = dietPlanDao.delete(dietPlan)

    suspend fun addDietPlanProduct(item: DietPlanProductEntity): Long = dietPlanProductDao.insert(item)
    suspend fun updateDietPlanProduct(item: DietPlanProductEntity) = dietPlanProductDao.update(item)
    suspend fun deleteDietPlanProduct(item: DietPlanProductEntity) = dietPlanProductDao.delete(item)

    suspend fun updateLastBackupTimestamp(timestamp: Long) {
        appSettingDao.upsert(
            AppSettingEntity(
                key = "last_backup_ts",
                value = timestamp.toString(),
                updatedAt = timestamp
            )
        )
    }

    suspend fun getLastBackupTimestamp(): Long? =
        appSettingDao.get("last_backup_ts")?.value?.toLongOrNull()

    suspend fun ensureSeededProducts() {
        val existingCategories = productCategoryDao.getAll()
        val categoryMap = existingCategories.associateBy { it.name.trim().lowercase() }.toMutableMap()
        val categoryIdMap = mutableMapOf<String, Long>()

        ForeverSeedData.categories.forEach { category ->
            val key = category.name.trim().lowercase()
            val existing = categoryMap[key]
            val id = existing?.id ?: productCategoryDao.insert(
                ProductCategoryEntity(
                    name = category.name,
                    iconName = category.iconName,
                    sortOrder = category.sortOrder
                )
            )
            categoryIdMap[category.name] = id
        }

        val existingProducts = productDao.getAll()
        val grouped = existingProducts.groupBy { it.name.trim().lowercase() }
        grouped.values.forEach { sameNameProducts ->
            if (sameNameProducts.size > 1) {
                sameNameProducts.drop(1).forEach { duplicate ->
                    productDao.delete(duplicate)
                }
            }
        }

        val canonicalProducts = productDao.getAll().associateBy { it.name.trim().lowercase() }.toMutableMap()

        ForeverSeedData.products
            .distinctBy { it.name.trim().lowercase() }
            .forEach { product ->
                val key = product.name.trim().lowercase()
                val existing = canonicalProducts[key]
                if (existing == null) {
                    val id = productDao.insert(
                        ProductEntity(
                            name = product.name,
                            brand = "Forever",
                            categoryId = categoryIdMap[product.category],
                            imageUrl = product.imageUrl,
                            sourceUrl = product.sourceUrl,
                            description = product.description,
                            usageNote = product.usageNote,
                            defaultDose = product.defaultDose,
                            timing = product.timing,
                        code = deriveProductCode(product.imageUrl)
                        )
                    )
                    canonicalProducts[key] = ProductEntity(
                        id = id,
                        name = product.name,
                        brand = "Forever",
                        categoryId = categoryIdMap[product.category],
                        imageUrl = product.imageUrl,
                        sourceUrl = product.sourceUrl,
                        description = product.description,
                        usageNote = product.usageNote,
                        defaultDose = product.defaultDose,
                        timing = product.timing,
                        code = deriveProductCode(product.imageUrl)
                    )
                } else {
                    val updated = existing.copy(
                        categoryId = existing.categoryId ?: categoryIdMap[product.category],
                        imageUrl = if (existing.imageUrl.isBlank()) product.imageUrl else existing.imageUrl,
                        sourceUrl = if (existing.sourceUrl.isBlank()) product.sourceUrl else existing.sourceUrl,
                        description = if (existing.description.isBlank()) product.description else existing.description,
                        usageNote = if (existing.usageNote.isBlank()) product.usageNote else existing.usageNote,
                        defaultDose = if (existing.defaultDose.isBlank()) product.defaultDose else existing.defaultDose,
                        timing = if (existing.timing.isBlank()) product.timing else existing.timing,
                        code = if (existing.code.isBlank()) deriveProductCode(product.imageUrl) else existing.code,
                        updatedAt = System.currentTimeMillis()
                    )
                    if (updated != existing) productDao.update(updated)
                }
            }
    }
}
