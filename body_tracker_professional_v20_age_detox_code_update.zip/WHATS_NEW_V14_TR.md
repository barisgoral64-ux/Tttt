V14 - Veri Koruma Güncellemesi

Bu sürümde hasta kayıtlarının silinme riskini azaltmak için:
- Room destructive migration kaldırıldı
- 5 -> 6 migration eklendi
- Android Auto Backup kuralları eklendi
- Veritabanı kopyası almak için DatabaseBackupManager eklendi
- applicationId sabit tutuldu: com.example.bodytracker

Notlar
- Uygulamayı silmeden üstüne kurmak gerekir.
- Aynı package name ve aynı imza korunmalıdır.
- Eski APK kaldırılırsa yerel veriler yine silinebilir; bu yüzden ayrıca yedek önerilir.
