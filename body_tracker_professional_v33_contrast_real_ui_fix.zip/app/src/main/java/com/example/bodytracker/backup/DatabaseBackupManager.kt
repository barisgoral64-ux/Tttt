package com.example.bodytracker.backup

import android.content.Context
import com.example.bodytracker.data.AppDatabase
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object DatabaseBackupManager {
    fun exportDatabaseCopy(context: Context): File {
        val appContext = context.applicationContext
        val database = AppDatabase.get(appContext)
        runCatching {
            database.openHelper.writableDatabase.query("PRAGMA wal_checkpoint(FULL)").close()
        }

        val db = appContext.getDatabasePath("body_tracker.db")
        val exportDir = File(appContext.filesDir, "backups").apply { mkdirs() }
        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val out = File(exportDir, "body_tracker_backup_$timestamp.db")
        db.copyTo(out, overwrite = true)
        File(exportDir, "body_tracker_backup_latest.db").let { latest ->
            out.copyTo(latest, overwrite = true)
        }
        return out
    }
}
