package com.example.bodytracker.data
internal data class SeedCategory(
    val name: String,
    val iconName: String,
    val sortOrder: Int
)
internal data class SeedProduct(
    val name: String,
    val category: String,
    val description: String,
    val usageNote: String,
    val defaultDose: String,
    val timing: String,
    val sourceUrl: String,
    val imageUrl: String = ""
)
internal object ForeverSeedData {
    val categories = listOf(
        SeedCategory("Yeni Ürünler / Cilt Bakım Seti", "category", 12),
        SeedCategory("İçecekler", "local_drink", 1),
        SeedCategory("Beslenme / Günlük Beslenme", "medication", 2),
        SeedCategory("Beslenme / Hedefe Yönelik Beslenme", "medication", 4),
        SeedCategory("Beslenme / Beslenme Sistemi", "medication", 3),
        SeedCategory("Aktif Yaşam Tarzı", "query_stats", 5),
        SeedCategory("Kilo Kontrol Ürünleri", "monitor_weight", 6),
        SeedCategory("Kilo Kontrol Programları", "monitor_weight", 7),
        SeedCategory("Arı Ürünleri", "inventory_2", 8),
        SeedCategory("Cilt Bakımı / Yüz", "face", 9),
        SeedCategory("Cilt Bakımı / Vücut", "spa", 10),
        SeedCategory("Kişisel Bakım", "inventory_2", 11)
    )

    val products = listOf(
        SeedProduct(
            name = "Logic by Forever Aloe Gel Cleanser",
            category = "Yeni Ürünler / Cilt Bakım Seti",
            description = "Yeni ürünler bölümünde yer alan cilt bakım sistemi ürünleri.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page11.html",
            imageUrl = "file:///android_asset/forever_products/001_logic_by_forever_aloe_gel_cleanser.png"
        ),
        SeedProduct(
            name = "Logic by Forever Balancing Aloe Essence",
            category = "Yeni Ürünler / Cilt Bakım Seti",
            description = "Yeni ürünler bölümünde yer alan cilt bakım sistemi ürünleri.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page11.html",
            imageUrl = "file:///android_asset/forever_products/002_logic_by_forever_balancing_aloe_essence.png"
        ),
        SeedProduct(
            name = "Logic by Forever Soothing Gel Moisturizer",
            category = "Yeni Ürünler / Cilt Bakım Seti",
            description = "Yeni ürünler bölümünde yer alan cilt bakım sistemi ürünleri.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page11.html",
            imageUrl = "file:///android_asset/forever_products/003_logic_by_forever_soothing_gel_moisturizer.png"
        ),
        SeedProduct(
            name = "Forever Aloe Vera Gel",
            category = "İçecekler",
            description = "Aloe bazlı içecekler ve bitki çayı ürünleri.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page14.html",
            imageUrl = "file:///android_asset/forever_products/004_forever_aloe_vera_gel.png"
        ),
        SeedProduct(
            name = "Forever Aloe Berry Nectar",
            category = "İçecekler",
            description = "Aloe bazlı içecekler ve bitki çayı ürünleri.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page14.html",
            imageUrl = "file:///android_asset/forever_products/005_forever_aloe_berry_nectar.png"
        ),
        SeedProduct(
            name = "Forever Aloe Bits N' Peaches",
            category = "İçecekler",
            description = "Aloe bazlı içecekler ve bitki çayı ürünleri.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page15.html",
            imageUrl = "file:///android_asset/forever_products/006_forever_aloe_bits_n_peaches.png"
        ),
        SeedProduct(
            name = "Forever Aloe Mango",
            category = "İçecekler",
            description = "Aloe bazlı içecekler ve bitki çayı ürünleri.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page15.html",
            imageUrl = "file:///android_asset/forever_products/007_forever_aloe_mango.png"
        ),
        SeedProduct(
            name = "Forever Freedom",
            category = "İçecekler",
            description = "Aloe bazlı içecekler ve bitki çayı ürünleri.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page16.html",
            imageUrl = "file:///android_asset/forever_products/008_forever_freedom.png"
        ),
        SeedProduct(
            name = "Aloe Blossom Herbal Tea",
            category = "İçecekler",
            description = "Aloe bazlı içecekler ve bitki çayı ürünleri.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page16.html",
            imageUrl = "file:///android_asset/forever_products/009_aloe_blossom_herbal_tea.png"
        ),
        SeedProduct(
            name = "Forever Fiber",
            category = "Beslenme / Günlük Beslenme",
            description = "Günlük beslenme desteği için vitamin, mineral ve lif ürünleri.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page18.html",
            imageUrl = "file:///android_asset/forever_products/010_forever_fiber.png"
        ),
        SeedProduct(
            name = "Forever Absorbent-D",
            category = "Beslenme / Günlük Beslenme",
            description = "Günlük beslenme desteği için vitamin, mineral ve lif ürünleri.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page18.html",
            imageUrl = "file:///android_asset/forever_products/011_forever_absorbent_d.png"
        ),
        SeedProduct(
            name = "Forever Daily",
            category = "Beslenme / Günlük Beslenme",
            description = "Günlük beslenme desteği için vitamin, mineral ve lif ürünleri.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page18.html",
            imageUrl = "file:///android_asset/forever_products/012_forever_daily.png"
        ),
        SeedProduct(
            name = "Forever Active Pro B",
            category = "Beslenme / Günlük Beslenme",
            description = "Günlük beslenme desteği için vitamin, mineral ve lif ürünleri.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page19.html",
            imageUrl = "file:///android_asset/forever_products/013_forever_active_pro_b.png"
        ),
        SeedProduct(
            name = "Forever Calcium",
            category = "Beslenme / Günlük Beslenme",
            description = "Günlük beslenme desteği için vitamin, mineral ve lif ürünleri.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page19.html",
            imageUrl = "file:///android_asset/forever_products/014_forever_calcium.png"
        ),
        SeedProduct(
            name = "Arctic Sea Omega 3",
            category = "Beslenme / Günlük Beslenme",
            description = "Günlük beslenme desteği için vitamin, mineral ve lif ürünleri.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page19.html",
            imageUrl = "file:///android_asset/forever_products/015_arctic_sea_omega_3.png"
        ),
        SeedProduct(
            name = "Nature-Min",
            category = "Beslenme / Günlük Beslenme",
            description = "Günlük beslenme desteği için vitamin, mineral ve lif ürünleri.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page19.html",
            imageUrl = "file:///android_asset/forever_products/016_nature_min.png"
        ),
        SeedProduct(
            name = "Forever iVision",
            category = "Beslenme / Hedefe Yönelik Beslenme",
            description = "Belirli ihtiyaçlara yönelik beslenme destek ürünleri.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page20.html",
            imageUrl = "file:///android_asset/forever_products/017_forever_ivision.png"
        ),
        SeedProduct(
            name = "Forever B12 Plus",
            category = "Beslenme / Hedefe Yönelik Beslenme",
            description = "Belirli ihtiyaçlara yönelik beslenme destek ürünleri.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page20.html",
            imageUrl = "file:///android_asset/forever_products/018_forever_b12_plus.png"
        ),
        SeedProduct(
            name = "Forever Lycium Plus",
            category = "Beslenme / Hedefe Yönelik Beslenme",
            description = "Belirli ihtiyaçlara yönelik beslenme destek ürünleri.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page21.html",
            imageUrl = "file:///android_asset/forever_products/019_forever_lycium_plus.png"
        ),
        SeedProduct(
            name = "Vitolize",
            category = "Beslenme / Hedefe Yönelik Beslenme",
            description = "Belirli ihtiyaçlara yönelik beslenme destek ürünleri.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page21.html",
            imageUrl = "file:///android_asset/forever_products/020_vitolize.png"
        ),
        SeedProduct(
            name = "Forever AloeTurm",
            category = "Beslenme / Beslenme Sistemi",
            description = "Beslenme sistemi ve bağışıklık destek ürünleri.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page22.html",
            imageUrl = "file:///android_asset/forever_products/021_forever_aloeturm.png"
        ),
        SeedProduct(
            name = "Absorbent-C",
            category = "Beslenme / Beslenme Sistemi",
            description = "Beslenme sistemi ve bağışıklık destek ürünleri.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page23.html",
            imageUrl = "file:///android_asset/forever_products/022_absorbent_c.png"
        ),
        SeedProduct(
            name = "Forever Garlic-Thyme",
            category = "Beslenme / Beslenme Sistemi",
            description = "Beslenme sistemi ve bağışıklık destek ürünleri.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page23.html",
            imageUrl = "file:///android_asset/forever_products/023_forever_garlic_thyme.png"
        ),
        SeedProduct(
            name = "Forever Immune Gummy",
            category = "Beslenme / Beslenme Sistemi",
            description = "Beslenme sistemi ve bağışıklık destek ürünleri.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page23.html",
            imageUrl = "file:///android_asset/forever_products/024_forever_immune_gummy.png"
        ),
        SeedProduct(
            name = "Forever ImmuBlend",
            category = "Beslenme / Beslenme Sistemi",
            description = "Beslenme sistemi ve bağışıklık destek ürünleri.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page23.html",
            imageUrl = "file:///android_asset/forever_products/025_forever_immublend.png"
        ),
        SeedProduct(
            name = "ARGI+",
            category = "Aktif Yaşam Tarzı",
            description = "Aktif yaşam tarzı ve egzersiz desteği ürünleri.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page24.html",
            imageUrl = "file:///android_asset/forever_products/026_argi.png"
        ),
        SeedProduct(
            name = "Forever Marine Collagen",
            category = "Aktif Yaşam Tarzı",
            description = "Aktif yaşam tarzı ve egzersiz desteği ürünleri.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page26.html",
            imageUrl = "file:///android_asset/forever_products/027_forever_marine_collagen.png"
        ),
        SeedProduct(
            name = "Aloe Cooling Lotion",
            category = "Aktif Yaşam Tarzı",
            description = "Aktif yaşam tarzı ve egzersiz desteği ürünleri.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page26.html",
            imageUrl = "file:///android_asset/forever_products/028_aloe_cooling_lotion.png"
        ),
        SeedProduct(
            name = "Aloe Heat Lotion",
            category = "Aktif Yaşam Tarzı",
            description = "Aktif yaşam tarzı ve egzersiz desteği ürünleri.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page26.html",
            imageUrl = "file:///android_asset/forever_products/029_aloe_heat_lotion.png"
        ),
        SeedProduct(
            name = "Aloe MSM Gel",
            category = "Aktif Yaşam Tarzı",
            description = "Aktif yaşam tarzı ve egzersiz desteği ürünleri.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page26.html",
            imageUrl = "file:///android_asset/forever_products/030_aloe_msm_gel.png"
        ),
        SeedProduct(
            name = "Forever Active HA",
            category = "Aktif Yaşam Tarzı",
            description = "Aktif yaşam tarzı ve egzersiz desteği ürünleri.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page27.html",
            imageUrl = "file:///android_asset/forever_products/031_forever_active_ha.png"
        ),
        SeedProduct(
            name = "Forever Nutra Q10",
            category = "Aktif Yaşam Tarzı",
            description = "Aktif yaşam tarzı ve egzersiz desteği ürünleri.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page27.html",
            imageUrl = "file:///android_asset/forever_products/032_forever_nutra_q10.png"
        ),
        SeedProduct(
            name = "Forever Lite Ultra Chocolate Flavour",
            category = "Kilo Kontrol Ürünleri",
            description = "Kilo yönetimi için takviye ve shake ürünleri.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page28.html",
            imageUrl = "file:///android_asset/forever_products/033_forever_lite_ultra_chocolate_flavour.png"
        ),
        SeedProduct(
            name = "Forever Lite Ultra Vanilla Flavour",
            category = "Kilo Kontrol Ürünleri",
            description = "Kilo yönetimi için takviye ve shake ürünleri.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page28.html",
            imageUrl = "file:///android_asset/forever_products/034_forever_lite_ultra_vanilla_flavour.png"
        ),
        SeedProduct(
            name = "Forever Garcinia Plus",
            category = "Kilo Kontrol Ürünleri",
            description = "Kilo yönetimi için takviye ve shake ürünleri.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page29.html",
            imageUrl = "file:///android_asset/forever_products/035_forever_garcinia_plus.png"
        ),
        SeedProduct(
            name = "Forever Lean",
            category = "Kilo Kontrol Ürünleri",
            description = "Kilo yönetimi için takviye ve shake ürünleri.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page29.html",
            imageUrl = "file:///android_asset/forever_products/036_forever_lean.png"
        ),
        SeedProduct(
            name = "Forever Sensatiable",
            category = "Kilo Kontrol Ürünleri",
            description = "Kilo yönetimi için takviye ve shake ürünleri.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page29.html",
            imageUrl = "file:///android_asset/forever_products/037_forever_sensatiable.png"
        ),
        SeedProduct(
            name = "Forever Therm",
            category = "Kilo Kontrol Ürünleri",
            description = "Kilo yönetimi için takviye ve shake ürünleri.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page29.html",
            imageUrl = "file:///android_asset/forever_products/038_forever_therm.png"
        ),
        SeedProduct(
            name = "C9",
            category = "Kilo Kontrol Programları",
            description = "Program/kit formatında kilo kontrol paketleri.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page32.html",
            imageUrl = "file:///android_asset/forever_products/039_c9.png"
        ),
        SeedProduct(
            name = "Smile 5",
            category = "Kilo Kontrol Programları",
            description = "Program/kit formatında kilo kontrol paketleri.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page32.html",
            imageUrl = "file:///android_asset/forever_products/040_smile_5.png"
        ),
        SeedProduct(
            name = "MY FIT",
            category = "Kilo Kontrol Programları",
            description = "Program/kit formatında kilo kontrol paketleri.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page33.html",
            imageUrl = "file:///android_asset/forever_products/041_my_fit.png"
        ),
        SeedProduct(
            name = "ECO",
            category = "Kilo Kontrol Programları",
            description = "Program/kit formatında kilo kontrol paketleri.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page33.html",
            imageUrl = "file:///android_asset/forever_products/042_eco.png"
        ),
        SeedProduct(
            name = "Aloe Propolis Creme",
            category = "Arı Ürünleri",
            description = "Bal, propolis, polen ve royal jelly içeren ürünler.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page34.html",
            imageUrl = "file:///android_asset/forever_products/043_aloe_propolis_creme.png"
        ),
        SeedProduct(
            name = "Forever Bee Honey",
            category = "Arı Ürünleri",
            description = "Bal, propolis, polen ve royal jelly içeren ürünler.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page34.html",
            imageUrl = "file:///android_asset/forever_products/044_forever_bee_honey.png"
        ),
        SeedProduct(
            name = "Forever Royal Jelly",
            category = "Arı Ürünleri",
            description = "Bal, propolis, polen ve royal jelly içeren ürünler.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page34.html",
            imageUrl = "file:///android_asset/forever_products/045_forever_royal_jelly.png"
        ),
        SeedProduct(
            name = "Forever Bee Pollen",
            category = "Arı Ürünleri",
            description = "Bal, propolis, polen ve royal jelly içeren ürünler.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page35.html",
            imageUrl = "file:///android_asset/forever_products/046_forever_bee_pollen.png"
        ),
        SeedProduct(
            name = "Forever Bee Propolis",
            category = "Arı Ürünleri",
            description = "Bal, propolis, polen ve royal jelly içeren ürünler.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page35.html",
            imageUrl = "file:///android_asset/forever_products/047_forever_bee_propolis.png"
        ),
        SeedProduct(
            name = "Sonya Refreshing Gel Cleanser",
            category = "Cilt Bakımı / Yüz",
            description = "Yüz bakımı için temizleme, nemlendirme ve serum ürünleri.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page37.html",
            imageUrl = "file:///android_asset/forever_products/048_sonya_refreshing_gel_cleanser.png"
        ),
        SeedProduct(
            name = "Sonya Refining Gel Mask",
            category = "Cilt Bakımı / Yüz",
            description = "Yüz bakımı için temizleme, nemlendirme ve serum ürünleri.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page37.html",
            imageUrl = "file:///android_asset/forever_products/049_sonya_refining_gel_mask.png"
        ),
        SeedProduct(
            name = "Sonya Soothing Gel Moisturizer",
            category = "Cilt Bakımı / Yüz",
            description = "Yüz bakımı için temizleme, nemlendirme ve serum ürünleri.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page37.html",
            imageUrl = "file:///android_asset/forever_products/050_sonya_soothing_gel_moisturizer.png"
        ),
        SeedProduct(
            name = "Sonya Illuminating Gel",
            category = "Cilt Bakımı / Yüz",
            description = "Yüz bakımı için temizleme, nemlendirme ve serum ürünleri.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page37.html",
            imageUrl = "file:///android_asset/forever_products/051_sonya_illuminating_gel.png"
        ),
        SeedProduct(
            name = "Infinite by Forever",
            category = "Cilt Bakımı / Yüz",
            description = "Yüz bakımı için temizleme, nemlendirme ve serum ürünleri.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page38.html",
            imageUrl = "file:///android_asset/forever_products/052_infinite_by_forever.png"
        ),
        SeedProduct(
            name = "Logic by Forever Skin Care System",
            category = "Cilt Bakımı / Yüz",
            description = "Yüz bakımı için temizleme, nemlendirme ve serum ürünleri.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page39.html",
            imageUrl = "file:///android_asset/forever_products/053_logic_by_forever_skin_care_system.png"
        ),
        SeedProduct(
            name = "Infinite by Forever Hydrating Cleanser",
            category = "Cilt Bakımı / Yüz",
            description = "Yüz bakımı için temizleme, nemlendirme ve serum ürünleri.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page39.html",
            imageUrl = "file:///android_asset/forever_products/054_infinite_by_forever_hydrating_cleanser.png"
        ),
        SeedProduct(
            name = "Infinite by Forever Firming Serum",
            category = "Cilt Bakımı / Yüz",
            description = "Yüz bakımı için temizleme, nemlendirme ve serum ürünleri.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page39.html",
            imageUrl = "file:///android_asset/forever_products/055_infinite_by_forever_firming_serum.png"
        ),
        SeedProduct(
            name = "Infinite by Forever Restoring Creme",
            category = "Cilt Bakımı / Yüz",
            description = "Yüz bakımı için temizleme, nemlendirme ve serum ürünleri.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page39.html",
            imageUrl = "file:///android_asset/forever_products/056_infinite_by_forever_restoring_creme.png"
        ),
        SeedProduct(
            name = "Deep Moisturizing Cream",
            category = "Cilt Bakımı / Yüz",
            description = "Yüz bakımı için temizleme, nemlendirme ve serum ürünleri.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page40.html",
            imageUrl = "file:///android_asset/forever_products/057_deep_moisturizing_cream.png"
        ),
        SeedProduct(
            name = "Tightening Mask Powder",
            category = "Cilt Bakımı / Yüz",
            description = "Yüz bakımı için temizleme, nemlendirme ve serum ürünleri.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page40.html",
            imageUrl = "file:///android_asset/forever_products/058_tightening_mask_powder.png"
        ),
        SeedProduct(
            name = "Awakening Eye Cream",
            category = "Cilt Bakımı / Yüz",
            description = "Yüz bakımı için temizleme, nemlendirme ve serum ürünleri.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page40.html",
            imageUrl = "file:///android_asset/forever_products/059_awakening_eye_cream.png"
        ),
        SeedProduct(
            name = "Hydrating Serum",
            category = "Cilt Bakımı / Yüz",
            description = "Yüz bakımı için temizleme, nemlendirme ve serum ürünleri.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page40.html",
            imageUrl = "file:///android_asset/forever_products/060_hydrating_serum.png"
        ),
        SeedProduct(
            name = "Protecting Day Lotion",
            category = "Cilt Bakımı / Yüz",
            description = "Yüz bakımı için temizleme, nemlendirme ve serum ürünleri.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page40.html",
            imageUrl = "file:///android_asset/forever_products/061_protecting_day_lotion.png"
        ),
        SeedProduct(
            name = "Aloe Activator",
            category = "Cilt Bakımı / Yüz",
            description = "Yüz bakımı için temizleme, nemlendirme ve serum ürünleri.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page41.html",
            imageUrl = "file:///android_asset/forever_products/062_aloe_activator.png"
        ),
        SeedProduct(
            name = "Forever Replenishing Skin Oil",
            category = "Cilt Bakımı / Yüz",
            description = "Yüz bakımı için temizleme, nemlendirme ve serum ürünleri.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page41.html",
            imageUrl = "file:///android_asset/forever_products/063_forever_replenishing_skin_oil.png"
        ),
        SeedProduct(
            name = "Smoothing Exfoliator",
            category = "Cilt Bakımı / Yüz",
            description = "Yüz bakımı için temizleme, nemlendirme ve serum ürünleri.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page41.html",
            imageUrl = "file:///android_asset/forever_products/064_smoothing_exfoliator.png"
        ),
        SeedProduct(
            name = "Aloe Bio-Cellulose Mask",
            category = "Cilt Bakımı / Yüz",
            description = "Yüz bakımı için temizleme, nemlendirme ve serum ürünleri.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page41.html",
            imageUrl = "file:///android_asset/forever_products/065_aloe_bio_cellulose_mask.png"
        ),
        SeedProduct(
            name = "Aloe Lips",
            category = "Cilt Bakımı / Vücut",
            description = "Vücut bakımı, güneş koruması ve topikal ürünler.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page44.html",
            imageUrl = "file:///android_asset/forever_products/066_aloe_lips.png"
        ),
        SeedProduct(
            name = "Aloe Body Lotion",
            category = "Cilt Bakımı / Vücut",
            description = "Vücut bakımı, güneş koruması ve topikal ürünler.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page45.html",
            imageUrl = "file:///android_asset/forever_products/067_aloe_body_lotion.png"
        ),
        SeedProduct(
            name = "Aloe Moisturizing Lotion",
            category = "Cilt Bakımı / Vücut",
            description = "Vücut bakımı, güneş koruması ve topikal ürünler.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page45.html",
            imageUrl = "file:///android_asset/forever_products/068_aloe_moisturizing_lotion.png"
        ),
        SeedProduct(
            name = "Aloe Sunscreen",
            category = "Cilt Bakımı / Vücut",
            description = "Vücut bakımı, güneş koruması ve topikal ürünler.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page45.html",
            imageUrl = "file:///android_asset/forever_products/069_aloe_sunscreen.png"
        ),
        SeedProduct(
            name = "Aloe Vera Gelly",
            category = "Cilt Bakımı / Vücut",
            description = "Vücut bakımı, güneş koruması ve topikal ürünler.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page45.html",
            imageUrl = "file:///android_asset/forever_products/070_aloe_vera_gelly.png"
        ),
        SeedProduct(
            name = "Forever Aloe Scrub",
            category = "Cilt Bakımı / Vücut",
            description = "Vücut bakımı, güneş koruması ve topikal ürünler.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page45.html",
            imageUrl = "file:///android_asset/forever_products/071_forever_aloe_scrub.png"
        ),
        SeedProduct(
            name = "Gentleman's Pride",
            category = "Cilt Bakımı / Vücut",
            description = "Vücut bakımı, güneş koruması ve topikal ürünler.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page45.html",
            imageUrl = "file:///android_asset/forever_products/072_gentleman_s_pride.png"
        ),
        SeedProduct(
            name = "Forever Bright Toothgel",
            category = "Kişisel Bakım",
            description = "Ağız bakımı, saç bakımı ve kişisel hijyen ürünleri.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page46.html",
            imageUrl = "file:///android_asset/forever_products/073_forever_bright_toothgel.png"
        ),
        SeedProduct(
            name = "Aloe Avocado Face & Body Soap",
            category = "Kişisel Bakım",
            description = "Ağız bakımı, saç bakımı ve kişisel hijyen ürünleri.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page47.html",
            imageUrl = "file:///android_asset/forever_products/074_aloe_avocado_face_body_soap.png"
        ),
        SeedProduct(
            name = "Aloe Body Wash",
            category = "Kişisel Bakım",
            description = "Ağız bakımı, saç bakımı ve kişisel hijyen ürünleri.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page47.html",
            imageUrl = "file:///android_asset/forever_products/075_aloe_body_wash.png"
        ),
        SeedProduct(
            name = "Aloe First",
            category = "Kişisel Bakım",
            description = "Ağız bakımı, saç bakımı ve kişisel hijyen ürünleri.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page47.html",
            imageUrl = "file:///android_asset/forever_products/076_aloe_first.png"
        ),
        SeedProduct(
            name = "Aloe-Jojoba Shampoo",
            category = "Kişisel Bakım",
            description = "Ağız bakımı, saç bakımı ve kişisel hijyen ürünleri.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page47.html",
            imageUrl = "file:///android_asset/forever_products/077_aloe_jojoba_shampoo.png"
        ),
        SeedProduct(
            name = "Aloe-Jojoba Conditioner",
            category = "Kişisel Bakım",
            description = "Ağız bakımı, saç bakımı ve kişisel hijyen ürünleri.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page47.html",
            imageUrl = "file:///android_asset/forever_products/078_aloe_jojoba_conditioner.png"
        ),
        SeedProduct(
            name = "Aloe Liquid Soap",
            category = "Kişisel Bakım",
            description = "Ağız bakımı, saç bakımı ve kişisel hijyen ürünleri.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page47.html",
            imageUrl = "file:///android_asset/forever_products/079_aloe_liquid_soap.png"
        ),
        SeedProduct(
            name = "Forever Nourishing Hair Oil",
            category = "Kişisel Bakım",
            description = "Ağız bakımı, saç bakımı ve kişisel hijyen ürünleri.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page48.html",
            imageUrl = "file:///android_asset/forever_products/080_forever_nourishing_hair_oil.png"
        ),
        SeedProduct(
            name = "Aloe Alafa Fine Fragrance",
            category = "Kişisel Bakım",
            description = "Ağız bakımı, saç bakımı ve kişisel hijyen ürünleri.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page49.html",
            imageUrl = "file:///android_asset/forever_products/081_aloe_alafa_fine_fragrance.png"
        ),
        SeedProduct(
            name = "Aloe Malosi Fine Fragrance",
            category = "Kişisel Bakım",
            description = "Ağız bakımı, saç bakımı ve kişisel hijyen ürünleri.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page49.html",
            imageUrl = "file:///android_asset/forever_products/082_aloe_malosi_fine_fragrance.png"
        ),
        SeedProduct(
            name = "Aloe Ever-Shield",
            category = "Kişisel Bakım",
            description = "Ağız bakımı, saç bakımı ve kişisel hijyen ürünleri.",
            usageNote = "Diyet planı ve takviye önerisinde uzman notuna göre kullanılabilir.",
            defaultDose = "Uzman önerisine göre",
            timing = "Planlamaya göre",
            sourceUrl = "https://flptr.com/catalog/tr/tr/files/basic-html/page49.html",
            imageUrl = "file:///android_asset/forever_products/083_aloe_ever_shield.png"
        )
    )
}
