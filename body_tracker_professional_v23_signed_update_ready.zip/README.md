# Body Tracker Professional v23

Bu sürümde eklenen başlıca özellikler:
- Hasta arama
- Kamera ve galeri ile profil fotoğrafı
- Erkek / Kadın seçimi
- Doğum tarihi ve ölçüm tarihi için modern gg/aa/yyyy tarih seçici
- Otomatik VKİ hesaplama
- Diyet listesi oluşturma
- WhatsApp ve genel paylaşım
- PDF rapor üretimi ve paylaşımı
- Ölçüm düzenleme ve silme
- Basit trend grafiği
- Randevu / kontrol takibi
- Cihaz yeniden başlatma sonrası randevu hatırlatıcılarını yeniden kurma
- Kurumsal release imzalama: şifreler kod dışında tutulur

Not: Bu paket kaynak projedir. Android Studio veya online build ile APK oluşturulur.


## Veri kaybını azaltma
- Uygulama kimliği sabit tutuldu: `com.example.bodytracker`
- Room destructive migration kaldirildi
- Migration 5->6 eklendi
- Android backup kurallari eklendi
- Uygulamayı silmeden üstüne güncelleme önerilir
- Güncelleme APK'sı eski uygulamayla aynı `forever-release.jks` anahtarıyla imzalanmalıdır


## V23 Kurumsal Menü Notu
Ana ekran hızlı işlem kartları doğrudan ilgili modüllere yönlendirilir. Bildirim güvenliği ve randevu ekranına yönlendirme iyileştirilmiştir.
