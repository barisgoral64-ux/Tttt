package com.example.bodytracker

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.pm.PackageManager
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.RequiresApi
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Female
import androidx.compose.material.icons.filled.Man
import androidx.compose.material.icons.filled.MonitorWeight
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.Done
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.LocalDrink
import androidx.compose.material.icons.filled.Medication
import androidx.compose.material.icons.filled.QueryStats
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SmallTopAppBar
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.text.input.KeyboardType
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import androidx.compose.runtime.collectAsState
import coil.compose.AsyncImage
import com.example.bodytracker.backup.DatabaseBackupManager
import com.example.bodytracker.data.AppDatabase
import com.example.bodytracker.data.AppointmentEntity
import com.example.bodytracker.data.BodyTrackerRepository
import com.example.bodytracker.data.DailyComplianceEntity
import com.example.bodytracker.data.DecisionLogEntity
import com.example.bodytracker.data.MeasurementEntity
import com.example.bodytracker.data.PatientEntity
import com.example.bodytracker.data.PlanTemplateEntity
import com.example.bodytracker.notifications.AppointmentAlarmReceiver
import com.example.bodytracker.ui.theme.BodyTrackerTheme
import com.example.bodytracker.util.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

sealed interface Screen {
    data object Patients : Screen
    data object PatientList : Screen
    data class AddPatient(val patientId: Long? = null) : Screen
    data object About : Screen
    data class Detail(val patientId: Long) : Screen
    data class AddMeasurement(val patientId: Long, val measurementId: Long? = null) : Screen
    data class DietPlan(val patientId: Long) : Screen
    data class Appointments(val patientId: Long) : Screen
}

class MainActivity : ComponentActivity() {
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = AppDatabase.get(this)
        val repo = BodyTrackerRepository(
            db.patientDao(),
            db.measurementDao(),
            db.appointmentDao(),
            db.productCategoryDao(),
            db.productDao(),
            db.dietPlanDao(),
            db.dietPlanProductDao(),
            db.decisionLogDao(),
            db.dailyComplianceDao(),
            db.planTemplateDao(),
            db.appSettingDao()
        )
        lifecycleScope.launch { repo.ensureSeededProducts() }
        setContent {
            BodyTrackerTheme {
                BodyTrackerApp(repo)
            }
        }
    }
}

@Composable
fun BodyTrackerApp(repo: BodyTrackerRepository) {
    var screen by remember { mutableStateOf<Screen>(Screen.Patients) }
    val context = LocalContext.current
    val activity = context as? Activity
    LaunchedEffect(activity?.intent?.getLongExtra("appointment_patient_id", -1L)) {
        val patientIdFromIntent = activity?.intent?.getLongExtra("appointment_patient_id", -1L) ?: -1L
        if (patientIdFromIntent > 0L) {
            screen = Screen.Appointments(patientIdFromIntent)
        }
    }
    when (val s = screen) {
        Screen.Patients -> PatientsScreen(
            repo,
            onAdd = { screen = Screen.AddPatient() },
            onAbout = { screen = Screen.About },
            onOpen = { screen = Screen.Detail(it) },
            onEdit = { screen = Screen.AddPatient(it) },
            onAddMeasurementFor = { screen = Screen.AddMeasurement(it) },
            onOpenDietPlanFor = { screen = Screen.DietPlan(it) },
            onOpenAppointmentsFor = { screen = Screen.Appointments(it) },
            onOpenList = { screen = Screen.PatientList }
        )

        Screen.PatientList -> PatientListScreen(
            repo = repo,
            onBack = { screen = Screen.Patients },
            onAdd = { screen = Screen.AddPatient() },
            onOpen = { screen = Screen.Detail(it) },
            onEdit = { screen = Screen.AddPatient(it) }
        )
        is Screen.AddPatient -> AddPatientScreen(repo, s.patientId, onBack = {
            screen = if (s.patientId == null) Screen.Patients else Screen.Detail(s.patientId)
        }, onSaved = { screen = Screen.Detail(it) })
        Screen.About -> AboutScreen(onBack = { screen = Screen.Patients })
        is Screen.Detail -> PatientDetailScreen(
            repo = repo,
            patientId = s.patientId,
            onBack = { screen = Screen.Patients },
            onEditPatient = { screen = Screen.AddPatient(s.patientId) },
            onAddMeasurement = { screen = Screen.AddMeasurement(s.patientId) },
            onEditMeasurement = { screen = Screen.AddMeasurement(s.patientId, it) },
            onOpenDietPlan = { screen = Screen.DietPlan(s.patientId) },
            onOpenAppointments = { screen = Screen.Appointments(s.patientId) }
        )
        is Screen.AddMeasurement -> AddMeasurementScreen(repo, s.patientId, s.measurementId, onBack = { screen = Screen.Detail(s.patientId) }, onSaved = { screen = Screen.Detail(s.patientId) })
        is Screen.DietPlan -> DietPlanScreen(repo, s.patientId, onBack = { screen = Screen.Detail(s.patientId) })
        is Screen.Appointments -> AppointmentsScreen(repo, s.patientId, onBack = { screen = Screen.Detail(s.patientId) })
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PatientsScreen(
    repo: BodyTrackerRepository,
    onAdd: () -> Unit,
    onAbout: () -> Unit,
    onOpen: (Long) -> Unit,
    onEdit: (Long) -> Unit,
    onAddMeasurementFor: (Long) -> Unit,
    onOpenDietPlanFor: (Long) -> Unit,
    onOpenAppointmentsFor: (Long) -> Unit,
    onOpenList: () -> Unit
) {
    val context = LocalContext.current
    val patients by repo.observePatients().collectAsState(initial = emptyList())
    val allAppointments by repo.observeAllAppointments().collectAsState(initial = emptyList())
    val allMeasurements by repo.observeAllMeasurements().collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    var query by rememberSaveable { mutableStateOf("") }
    var patientPendingDelete by remember { mutableStateOf<PatientEntity?>(null) }
    val filtered = remember(patients, query) {
        val q = query.trim().lowercase()
        if (q.isBlank()) {
            patients
        } else {
            patients.filter {
                listOf(
                    it.firstName,
                    it.lastName,
                    "${it.firstName} ${it.lastName}",
                    it.gender,
                    patientAge(it).toString(),
                    formatDate(it.birthDateMillis),
                    it.notes,
                    it.medicalHistory,
                    it.allergies,
                    it.medications
                ).any { value -> value.lowercase().contains(q) }
            }
        }
    }
    val nowMillis = System.currentTimeMillis()
    val dayMillis = 24L * 60L * 60L * 1000L
    val todayStart = nowMillis - (nowMillis % dayMillis)
    val todayEnd = todayStart + dayMillis
    val todayAppointments = remember(allAppointments, nowMillis) { allAppointments.count { it.dateMillis in todayStart until todayEnd } }
    val weeklyAppointments = remember(allAppointments, nowMillis) { allAppointments.count { it.dateMillis in nowMillis..(nowMillis + 7L * dayMillis) } }
    val measuredPatientIds = remember(allMeasurements, nowMillis) { allMeasurements.filter { it.dateMillis >= nowMillis - 30L * dayMillis }.map { it.patientId }.toSet() }
    val waitingMeasurements = remember(patients, measuredPatientIds) { patients.count { it.id !in measuredPatientIds } }
    val latestPatient = patients.firstOrNull()
    val latestThreePatients = remember(patients) { patients.take(3) }
    val femaleCount = remember(patients) { patients.count { it.gender.equals("Kadın", true) } }
    val maleCount = remember(patients) { patients.count { it.gender.equals("Erkek", true) } }
    var lastBackupMillis by remember { mutableStateOf<Long?>(null) }
    LaunchedEffect(Unit) {
        lastBackupMillis = repo.getLastBackupTimestamp()
    }

    patientPendingDelete?.let { patient ->
        AlertDialog(
            onDismissRequest = { patientPendingDelete = null },
            title = { Text("Danışanı sil") },
            text = { Text("${patient.firstName} ${patient.lastName} kaydını silmek istediğinize emin misiniz?") },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch { repo.deletePatient(patient) }
                    patientPendingDelete = null
                }) { Text("Sil", color = Color(0xFFC62828)) }
            },
            dismissButton = { TextButton(onClick = { patientPendingDelete = null }) { Text("Vazgeç") } }
        )
    }

    Scaffold(
        containerColor = Color(0xFF06111D),
        topBar = {
            SmallTopAppBar(
                colors = TopAppBarDefaults.smallTopAppBarColors(containerColor = Color(0xFF06111D), titleContentColor = Color.White, actionIconContentColor = Color.White, navigationIconContentColor = Color.White),
                title = { Text("FOREVER PRO V42", color = Color(0xFF39E58C), fontWeight = FontWeight.Bold) },
                actions = { IconButton(onClick = onAbout) { Icon(Icons.Default.Info, contentDescription = "Hakkında") } }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onAdd,
                containerColor = Color(0xFF31D982),
                contentColor = Color(0xFF04130B),
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text("Yeni Danışan") }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                CorporateHomeHeader(
                    patientCount = patients.size,
                    todayAppointments = todayAppointments,
                    weeklyAppointments = weeklyAppointments,
                    waitingMeasurements = waitingMeasurements,
                    femaleCount = femaleCount,
                    maleCount = maleCount,
                    lastBackupMillis = lastBackupMillis,
                    onBackup = {
                        scope.launch {
                            val file = withContext(Dispatchers.IO) {
                                DatabaseBackupManager.exportDatabaseCopy(context)
                            }
                            val timestamp = System.currentTimeMillis()
                            repo.updateLastBackupTimestamp(timestamp)
                            lastBackupMillis = timestamp
                            shareBackupFile(context, file)
                            Toast.makeText(context, "Veri yedeği hazırlandı", Toast.LENGTH_SHORT).show()
                        }
                    }
                )
            }
            item {
                SmartDashboardInsightCard(
                    todayAppointments = todayAppointments,
                    weeklyAppointments = weeklyAppointments,
                    waitingMeasurements = waitingMeasurements,
                    patientCount = patients.size
                )
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                    HomeStatCard(title = "Aktif Danışan", value = patients.size.toString(), subtitle = "Kayıtlı profil", modifier = Modifier.weight(1f))
                    HomeStatCard(title = "Bugünkü Randevu", value = todayAppointments.toString(), subtitle = "Günlük ajanda", modifier = Modifier.weight(1f))
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                    HomeStatCard(title = "Bu Hafta", value = weeklyAppointments.toString(), subtitle = "Yaklaşan randevu", modifier = Modifier.weight(1f))
                    HomeStatCard(title = "Ölçüm Bekleyen", value = waitingMeasurements.toString(), subtitle = "30+ gün ölçümsüz", modifier = Modifier.weight(1f))
                }
            }
            item { SectionTitle("Hızlı İşlemler") }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                    HomeActionCard(
                        title = "Yeni Danışan",
                        subtitle = "Yeni danışan kaydı oluştur",
                        icon = Icons.Default.Add,
                        accent = Color(0xFF8BC34A),
                        modifier = Modifier.weight(1f),
                        onClick = onAdd
                    )
                    HomeActionCard(
                        title = "Danışan Yönetimi",
                        subtitle = if (filtered.isEmpty()) "Henüz kayıt yok" else "${filtered.size} danışan listede",
                        icon = Icons.Default.Person,
                        accent = Color(0xFF64B5F6),
                        modifier = Modifier.weight(1f),
                        onClick = onOpenList
                    )
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                    HomeActionCard(
                        title = "Vücut Analizi",
                        subtitle = latestPatient?.let { "${it.firstName} ${it.lastName} için ölçüm ekle" } ?: "Önce danışan ekle",
                        icon = Icons.Default.QueryStats,
                        accent = Color(0xFF5C8DF6),
                        modifier = Modifier.weight(1f),
                        onClick = {
                            latestPatient?.let { onAddMeasurementFor(it.id) }
                                ?: Toast.makeText(context, "Önce danışan ekle", Toast.LENGTH_SHORT).show()
                        }
                    )
                    HomeActionCard(
                        title = "Takviye Planı",
                        subtitle = latestPatient?.let { "Son danışan için plan oluştur" } ?: "Önce danışan ekle",
                        icon = Icons.Default.Medication,
                        accent = Color(0xFFF59E42),
                        modifier = Modifier.weight(1f),
                        onClick = {
                            latestPatient?.let { onOpenDietPlanFor(it.id) }
                                ?: Toast.makeText(context, "Önce danışan ekle", Toast.LENGTH_SHORT).show()
                        }
                    )
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                    HomeActionCard(
                        title = "Randevu Oluştur",
                        subtitle = latestPatient?.let { "Doğrudan randevu ekranını aç" } ?: "Önce danışan ekle",
                        icon = Icons.Default.Alarm,
                        accent = Color(0xFF8B7CF6),
                        modifier = Modifier.weight(1f),
                        onClick = {
                            latestPatient?.let { onOpenAppointmentsFor(it.id) }
                                ?: Toast.makeText(context, "Önce danışan ekle", Toast.LENGTH_SHORT).show()
                        }
                    )
                    HomeActionCard(
                        title = "Raporları Paylaş",
                        subtitle = latestPatient?.let { "Detaydan PDF/WhatsApp paylaş" } ?: "Önce danışan ekle",
                        icon = Icons.Default.PictureAsPdf,
                        accent = Color(0xFFE96A6A),
                        modifier = Modifier.weight(1f),
                        onClick = {
                            latestPatient?.let { onOpen(it.id) }
                                ?: Toast.makeText(context, "Önce danışan ekle", Toast.LENGTH_SHORT).show()
                        }
                    )
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                    HomeActionCard(
                        title = "Son Danışanı Aç",
                        subtitle = latestPatient?.let { "${it.firstName} ${it.lastName}" } ?: "Henüz kayıt yok",
                        icon = Icons.Default.Search,
                        accent = Color(0xFFFFB74D),
                        modifier = Modifier.weight(1f),
                        onClick = { latestPatient?.let { onOpen(it.id) } }
                    )
                    HomeActionCard(
                        title = "Veri Yedeği",
                        subtitle = lastBackupMillis?.let { "Son yedek: ${formatDateTime(it)}" } ?: "Mevcut veritabanını dışa aktar",
                        icon = Icons.Default.Description,
                        accent = Color(0xFFBA68C8),
                        modifier = Modifier.weight(1f),
                        onClick = {
                            scope.launch {
                                val file = withContext(Dispatchers.IO) {
                                    DatabaseBackupManager.exportDatabaseCopy(context)
                                }
                                val timestamp = System.currentTimeMillis()
                                repo.updateLastBackupTimestamp(timestamp)
                                lastBackupMillis = timestamp
                                shareBackupFile(context, file)
                                Toast.makeText(context, "Veri yedeği hazırlandı", Toast.LENGTH_SHORT).show()
                            }
                        }
                    )
                }
            }
            if (latestThreePatients.isNotEmpty()) {
                item { SectionTitle("Son Eklenen Danışanlar") }
                item {
                    ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = Color(0xFF0F1B2B), contentColor = Color.White)) {
                        Column(Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            latestThreePatients.forEach { patient ->
                                DashboardPatientRow(
                                    patient = patient,
                                    onOpen = { onOpen(patient.id) }
                                )
                            }
                        }
                    }
                }
            }
            item {
                HomeActionCard(
                    title = "Tüm Danışanları Aç",
                    subtitle = "Ayrı ekranda arama, düzenleme ve detay yönetimi",
                    icon = Icons.Default.Person,
                    accent = Color(0xFF39E58C),
                    onClick = onOpenList
                )
            }
            item { Spacer(Modifier.height(96.dp)) }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PatientListScreen(
    repo: BodyTrackerRepository,
    onBack: () -> Unit,
    onAdd: () -> Unit,
    onOpen: (Long) -> Unit,
    onEdit: (Long) -> Unit
) {
    val scope = rememberCoroutineScope()
    val patients by repo.observePatients().collectAsState(initial = emptyList())
    var query by rememberSaveable { mutableStateOf("") }
    var pendingDelete by remember { mutableStateOf<PatientEntity?>(null) }
    val filtered = remember(patients, query) {
        val q = query.trim().lowercase()
        if (q.isBlank()) patients else patients.filter {
            listOf(it.firstName, it.lastName, "${it.firstName} ${it.lastName}", it.gender, it.notes, it.medicalHistory, it.allergies, it.medications).any { v -> v.lowercase().contains(q) }
        }
    }

    pendingDelete?.let { patient ->
        AlertDialog(
            onDismissRequest = { pendingDelete = null },
            title = { Text("Danışanı sil") },
            text = { Text("${patient.firstName} ${patient.lastName} kaydını silmek istediğinize emin misiniz?") },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch { repo.deletePatient(patient) }
                    pendingDelete = null
                }) { Text("Sil", color = Color(0xFFFF6B6B)) }
            },
            dismissButton = { TextButton(onClick = { pendingDelete = null }) { Text("Vazgeç") } }
        )
    }

    Scaffold(
        containerColor = Color(0xFF06111D),
        topBar = {
            SmallTopAppBar(
                colors = TopAppBarDefaults.smallTopAppBarColors(containerColor = Color(0xFF06111D), titleContentColor = Color.White, actionIconContentColor = Color.White, navigationIconContentColor = Color.White),
                title = { Text("DANIŞANLAR", color = Color.White, fontWeight = FontWeight.Bold) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = Color.White) } }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = onAdd, containerColor = Color(0xFF31D982), contentColor = Color(0xFF04130B)) {
                Icon(Icons.Default.Add, contentDescription = "Yeni danışan")
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Danışan ara") },
                    placeholder = { Text("İsim, telefon/not, alerji, ilaç") },
                    leadingIcon = { Icon(Icons.Default.Search, null) },
                    trailingIcon = { if (query.isNotBlank()) IconButton(onClick = { query = "" }) { Icon(Icons.Default.Close, contentDescription = "Temizle") } },
                    singleLine = true
                )
            }
            item {
                Text("${filtered.size} danışan", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color(0xFF39E58C))
            }
            if (filtered.isEmpty()) {
                item {
                    ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = Color(0xFF0F1B2B), contentColor = Color.White)) {
                        Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.Search, contentDescription = null, tint = Color(0xFF39E58C))
                            Text("Sonuç bulunamadı", color = Color.White, fontWeight = FontWeight.Bold)
                            Text("Yeni danışan ekleyebilir veya aramayı değiştirebilirsiniz.", color = Color(0xFF9FB4C7))
                        }
                    }
                }
            }
            items(filtered) { patient ->
                PatientSearchCard(
                    patient = patient,
                    onOpen = { onOpen(patient.id) },
                    onEdit = { onEdit(patient.id) },
                    onDelete = { pendingDelete = patient }
                )
            }
            item { Spacer(Modifier.height(96.dp)) }
        }
    }
}

@Composable
private fun CorporateHomeHeader(
    patientCount: Int,
    todayAppointments: Int,
    weeklyAppointments: Int,
    waitingMeasurements: Int,
    femaleCount: Int,
    maleCount: Int,
    lastBackupMillis: Long?,
    onBackup: () -> Unit
) {
    ElevatedCard(
        colors = CardDefaults.elevatedCardColors(containerColor = Color(0xFF0B1828), contentColor = Color.White),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF203247))
    ) {
        Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("FOREVER PRO", style = MaterialTheme.typography.labelLarge, color = Color(0xFF39E58C), fontWeight = FontWeight.Bold)
                    Text("Profesyonel Danışan Takip", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = Color.White)
                    Text("Danışan, ölçüm, randevu, takviye planı ve rapor süreçleri tek kurumsal panelde.", color = Color(0xFFC9D7E3))
                }
                Surface(shape = MaterialTheme.shapes.large, color = Color(0xFF123123)) {
                    Row(Modifier.padding(horizontal = 12.dp, vertical = 9.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Done, contentDescription = null, tint = Color(0xFF39E58C), modifier = Modifier.size(18.dp))
                        Text("DB güvenli", color = Color(0xFFB9F6CA), fontWeight = FontWeight.SemiBold)
                    }
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                DashboardStatusPill("Kadın", femaleCount.toString(), Modifier.weight(1f))
                DashboardStatusPill("Erkek", maleCount.toString(), Modifier.weight(1f))
                DashboardStatusPill("Toplam", patientCount.toString(), Modifier.weight(1f))
            }

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                HomeStatCard(title = "Bugün", value = todayAppointments.toString(), subtitle = "randevu", modifier = Modifier.weight(1f))
                HomeStatCard(title = "7 Gün", value = weeklyAppointments.toString(), subtitle = "yaklaşan", modifier = Modifier.weight(1f))
                HomeStatCard(title = "Takip", value = waitingMeasurements.toString(), subtitle = "ölçüm bekleyen", modifier = Modifier.weight(1f))
            }

            Surface(shape = MaterialTheme.shapes.large, color = Color(0xFF101F31)) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Description, contentDescription = null, tint = Color(0xFF8BC34A))
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text("Güncelleme yapısı korunur", fontWeight = FontWeight.Bold, color = Color.White)
                        Text(
                            lastBackupMillis?.let { "Son yerel yedek: ${formatDateTime(it)}" } ?: "Veritabanı şeması değiştirilmeden görsel ve iş akışı güncellendi.",
                            color = Color(0xFFC9D7E3),
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    OutlinedButton(onClick = onBackup) {
                        Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.size(6.dp))
                        Text("Yedek Al")
                    }
                }
            }
        }
    }
}

@Composable
private fun DashboardStatusPill(label: String, value: String, modifier: Modifier = Modifier) {
    Surface(modifier = modifier, shape = MaterialTheme.shapes.large, color = Color(0xFF132238)) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(label, style = MaterialTheme.typography.labelMedium, color = Color(0xFF9FB4C7))
            Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Color.White)
        }
    }
}

@Composable
private fun SectionTitle(title: String) {
    Text(title.uppercase(), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color(0xFF39E58C))
}

@Composable
private fun DashboardPatientRow(patient: PatientEntity, onOpen: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onOpen)
            .padding(horizontal = 10.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Surface(
            modifier = Modifier.size(44.dp),
            shape = CircleShape,
            color = Color(0xFFE6EEF8)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Person, contentDescription = null, tint = Color(0xFF17324D))
            }
        }
        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text("${patient.firstName} ${patient.lastName}", fontWeight = FontWeight.SemiBold)
            Text("${patientAge(patient)} yaş • ${patient.gender}", style = MaterialTheme.typography.bodySmall, color = Color(0xFFC9D7E3))
        }
        Text(formatDate(patient.createdAt), style = MaterialTheme.typography.bodySmall, color = Color(0xFFC9D7E3))
    }
    HorizontalDivider()
}

@Composable
private fun PatientSearchCard(patient: PatientEntity, onOpen: () -> Unit, onEdit: () -> Unit, onDelete: () -> Unit) {
    ElevatedCard(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onOpen),
        colors = CardDefaults.elevatedCardColors(containerColor = Color(0xFF101C2B), contentColor = Color.White)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Surface(
                    modifier = Modifier.size(60.dp),
                    shape = MaterialTheme.shapes.large,
                    color = MaterialTheme.colorScheme.secondaryContainer
                ) {
                    if (patient.photoUri.isNullOrBlank()) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.Person, contentDescription = null, modifier = Modifier.size(32.dp))
                        }
                    } else {
                        AsyncImage(
                            model = patient.photoUri,
                            contentDescription = null,
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    }
                }
                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("${patient.firstName} ${patient.lastName}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(
                        text = "Yaş: ${patientAge(patient)}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color(0xFFC9D7E3)
                    )
                }
                Surface(shape = MaterialTheme.shapes.large, color = MaterialTheme.colorScheme.primaryContainer) {
                    Text(
                        text = if (patient.gender == "Erkek") "Erkek" else "Kadın",
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PatientInfoChip(icon = Icons.Default.Person, text = "${patientAge(patient)} yaş")
                PatientInfoChip(icon = Icons.Default.MonitorWeight, text = "${patient.heightCm} cm")
                PatientInfoChip(
                    icon = if (patient.gender == "Erkek") Icons.Default.Man else Icons.Default.Female,
                    text = "Profil"
                )
            }

            if (patient.notes.isNotBlank()) {
                Surface(shape = MaterialTheme.shapes.medium, color = MaterialTheme.colorScheme.tertiaryContainer) {
                    Text(
                        text = patient.notes.take(90),
                        modifier = Modifier.fillMaxWidth().padding(10.dp),
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }

            HorizontalDivider()

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text("Kayıt tarihi", style = MaterialTheme.typography.labelMedium, color = Color(0xFFC9D7E3))
                    Text(formatDate(patient.createdAt), fontWeight = FontWeight.Medium)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = onEdit) { Text("Düzenle") }
                    TextButton(onClick = onOpen) { Text("Detayı Aç") }
                    IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, contentDescription = "Sil") }
                }
            }
        }
    }
}

@Composable
private fun PatientInfoChip(icon: ImageVector, text: String) {
    Surface(shape = MaterialTheme.shapes.large, color = MaterialTheme.colorScheme.surfaceVariant) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconBadge(icon = icon, size = 32.dp)
            Text(text, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Medium)
        }
    }
}


@Composable
private fun HomeStatCard(title: String, value: String, subtitle: String, modifier: Modifier = Modifier) {
    ElevatedCard(
        modifier = modifier,
        colors = CardDefaults.elevatedCardColors(containerColor = Color(0xFF101F31), contentColor = Color.White),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF21344A))
    ) {
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(title, style = MaterialTheme.typography.labelLarge, color = Color(0xFF9FB4C7))
            Text(value, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = Color.White)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = Color(0xFF9FB4C7))
        }
    }
}

@Composable
private fun HomeActionCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    accent: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    ElevatedCard(
        modifier = modifier.clickable(onClick = onClick),
        colors = CardDefaults.elevatedCardColors(containerColor = Color(0xFF0F1B2B), contentColor = Color.White),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF203247))
    ) {
        Row(
            Modifier.fillMaxWidth().padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(shape = MaterialTheme.shapes.large, color = accent.copy(alpha = 0.18f)) {
                Box(Modifier.size(48.dp), contentAlignment = Alignment.Center) {
                    Icon(icon, contentDescription = null, tint = accent)
                }
            }
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color.White)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = Color(0xFF9FB4C7))
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddPatientScreen(repo: BodyTrackerRepository, patientId: Long?, onBack: () -> Unit, onSaved: (Long) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val existingPatient by if (patientId != null) {
        repo.observePatient(patientId).collectAsState(initial = null)
    } else {
        remember { mutableStateOf<PatientEntity?>(null) }
    }
    var initialized by remember(existingPatient?.id) { mutableStateOf(false) }
    var firstName by rememberSaveable { mutableStateOf("") }
    var lastName by rememberSaveable { mutableStateOf("") }
    var gender by rememberSaveable { mutableStateOf("Erkek") }
    var heightText by rememberSaveable { mutableStateOf("") }
    var ageText by rememberSaveable { mutableStateOf("") }
    var photoUri by rememberSaveable { mutableStateOf<String?>(null) }
    var targetWeightText by rememberSaveable { mutableStateOf("") }
    var targetFatText by rememberSaveable { mutableStateOf("") }
    var medicalHistory by rememberSaveable { mutableStateOf("") }
    var allergies by rememberSaveable { mutableStateOf("") }
    var medications by rememberSaveable { mutableStateOf("") }
    var notes by rememberSaveable { mutableStateOf("") }

    val previewLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicturePreview()) { bitmap ->
        if (bitmap != null) {
            photoUri = saveBitmapToCache(context, bitmap)?.toString()
        } else {
            Toast.makeText(context, "Kamera görüntüsü alınamadı", Toast.LENGTH_SHORT).show()
        }
    }
    val cameraPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            try {
                previewLauncher.launch(null)
            } catch (_: Exception) {
                Toast.makeText(context, "Kamera açılamadı", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(context, "Kamera izni verilmedi", Toast.LENGTH_SHORT).show()
        }
    }
    val galleryLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> photoUri = uri?.toString() }

    val existingProfile = existingPatient
    if (existingProfile != null && !initialized) {
        firstName = existingProfile.firstName
        lastName = existingProfile.lastName
        gender = existingProfile.gender
        heightText = existingProfile.heightCm.toString()
        ageText = (if (existingProfile.ageYears > 0) existingProfile.ageYears else calculateAge(existingProfile.birthDateMillis)).toString()
        photoUri = existingProfile.photoUri
        targetWeightText = if (existingProfile.targetWeightKg > 0.0) existingProfile.targetWeightKg.toString() else ""
        targetFatText = if (existingProfile.targetBodyFatPercent > 0.0) existingProfile.targetBodyFatPercent.toString() else ""
        medicalHistory = existingProfile.medicalHistory
        allergies = existingProfile.allergies
        medications = existingProfile.medications
        notes = existingProfile.notes
        initialized = true
    }


    Scaffold(topBar = { SmallTopAppBar(title = { Text(if (patientId == null) "Yeni Danışan" else "Danışan Düzenle") }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) } }) }) { padding ->
        LazyColumn(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                PatientPhotoCard(photoUri, onCamera = {
                    val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == android.content.pm.PackageManager.PERMISSION_GRANTED
                    if (granted) {
                        try {
                            previewLauncher.launch(null)
                        } catch (_: Exception) {
                            Toast.makeText(context, "Kamera açılamadı", Toast.LENGTH_SHORT).show()
                        }
                    } else {
                        cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                    }
                }, onGallery = { galleryLauncher.launch("image/*") })
            }
            item { OutlinedTextField(firstName, { firstName = it }, Modifier.fillMaxWidth(), label = { Text("Ad") }, leadingIcon = { Icon(Icons.Default.Person, null) }) }
            item { OutlinedTextField(lastName, { lastName = it }, Modifier.fillMaxWidth(), label = { Text("Soyad") }, leadingIcon = { Icon(Icons.Default.Person, null) }) }
            item { OutlinedTextField(ageText, { ageText = it.filter(Char::isDigit).take(3) }, Modifier.fillMaxWidth(), label = { Text("Yaş") }, leadingIcon = { Icon(Icons.Default.CalendarMonth, null) }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true) }
            item {
                Text("Cinsiyet", style = MaterialTheme.typography.titleMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = gender == "Erkek", onClick = { gender = "Erkek" }, label = { Text("Erkek") }, leadingIcon = { Icon(Icons.Default.Man, null) })
                    FilterChip(selected = gender == "Kadın", onClick = { gender = "Kadın" }, label = { Text("Kadın") }, leadingIcon = { Icon(Icons.Default.Female, null) })
                }
            }
            item { OutlinedTextField(heightText, { heightText = it.filter(Char::isDigit) }, Modifier.fillMaxWidth(), label = { Text("Boy (cm)") }, leadingIcon = { Icon(Icons.Default.MonitorWeight, null) }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)) }
            item { NumericField("Hedef kilo (kg)", targetWeightText) { targetWeightText = it } }
            item { NumericField("Hedef yağ oranı (%)", targetFatText) { targetFatText = it } }
            item { OutlinedTextField(medicalHistory, { medicalHistory = it }, Modifier.fillMaxWidth().height(96.dp), label = { Text("Hastalık geçmişi") }, leadingIcon = { Icon(Icons.Default.Description, null) }) }
            item { OutlinedTextField(allergies, { allergies = it }, Modifier.fillMaxWidth().height(88.dp), label = { Text("Alerjiler") }, leadingIcon = { Icon(Icons.Default.Medication, null) }) }
            item { OutlinedTextField(medications, { medications = it }, Modifier.fillMaxWidth().height(88.dp), label = { Text("Kullanılan ilaçlar") }, leadingIcon = { Icon(Icons.Default.Medication, null) }) }
            item {
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    modifier = Modifier.fillMaxWidth().height(120.dp),
                    label = { Text("Danışan Notu / Sağlık Geçmişi") },
                    leadingIcon = { Icon(Icons.Default.Info, null) }
                )
            }
            item {
                Button(onClick = {
                    val height = heightText.toIntOrNull() ?: 0
                    val age = ageText.toIntOrNull() ?: 0
                    if (firstName.isNotBlank() && lastName.isNotBlank() && height > 0 && age > 0) {
                        scope.launch {
                            val entity = PatientEntity(
                                id = existingPatient?.id ?: 0,
                                firstName = firstName.trim(),
                                lastName = lastName.trim(),
                                birthDateMillis = existingPatient?.birthDateMillis ?: 0L,
                                ageYears = age,
                                gender = gender,
                                heightCm = height,
                                photoUri = photoUri,
                                targetWeightKg = targetWeightText.toDoubleOrNull() ?: 0.0,
                                targetBodyFatPercent = targetFatText.toDoubleOrNull() ?: 0.0,
                                medicalHistory = medicalHistory.trim(),
                                allergies = allergies.trim(),
                                medications = medications.trim(),
                                notes = notes.trim(),
                                createdAt = existingPatient?.createdAt ?: System.currentTimeMillis()
                            )
                            if (existingPatient == null) {
                                val id = repo.addPatient(entity)
                                onSaved(id)
                            } else {
                                repo.updatePatient(entity)
                                onSaved(entity.id)
                            }
                        }
                    }
                }, modifier = Modifier.fillMaxWidth()) { Text(if (patientId == null) "Danışanı Kaydet" else "Danışanı Güncelle") }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PatientDetailScreen(
    repo: BodyTrackerRepository,
    patientId: Long,
    onBack: () -> Unit,
    onEditPatient: () -> Unit,
    onAddMeasurement: () -> Unit,
    onEditMeasurement: (Long) -> Unit,
    onOpenDietPlan: () -> Unit,
    onOpenAppointments: () -> Unit
) {
    val scope = rememberCoroutineScope()
    val patient by repo.observePatient(patientId).collectAsState(initial = null)
    val measurements by repo.observeMeasurements(patientId).collectAsState(initial = emptyList())
    val latest = measurements.firstOrNull()
    val previous = measurements.getOrNull(1)
    val previousMonth = latest?.let { l -> measurements.drop(1).minByOrNull { kotlin.math.abs(it.dateMillis - (l.dateMillis - 30L * 24 * 60 * 60 * 1000)) } }
    var measurementPendingDelete by remember { mutableStateOf<MeasurementEntity?>(null) }

    measurementPendingDelete?.let { measurement ->
        AlertDialog(
            onDismissRequest = { measurementPendingDelete = null },
            title = { Text("Ölçümü sil") },
            text = { Text("${formatDate(measurement.dateMillis)} tarihli vücut analizini silmek istediğinize emin misiniz?") },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch { repo.deleteMeasurement(measurement) }
                    measurementPendingDelete = null
                }) { Text("Sil", color = Color(0xFFC62828)) }
            },
            dismissButton = { TextButton(onClick = { measurementPendingDelete = null }) { Text("Vazgeç") } }
        )
    }

    Scaffold(
        topBar = {
            SmallTopAppBar(
                title = { Text("Danışan Detayı") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) } },
                actions = {
                    IconButton(onClick = onEditPatient) { Icon(Icons.Default.Edit, null) }
                    IconButton(onClick = onOpenAppointments) { Icon(Icons.Default.Event, null, tint = Color(0xFFE0A106)) }
                    IconButton(onClick = onOpenDietPlan) { Icon(Icons.Default.LocalDrink, null, tint = Color(0xFF2E7D32)) }
                    IconButton(onClick = onAddMeasurement) { Icon(Icons.Default.QueryStats, null, tint = Color(0xFF1565C0)) }
                }
            )
        }
    ) { padding ->
        val p = patient ?: return@Scaffold
        LazyColumn(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                Card {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("${p.firstName} ${p.lastName}", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        Text("${p.gender} • ${patientAge(p)} yaş • ${p.heightCm} cm")
                        Text("Yaş: ${patientAge(p)}")
                        ProfileGoalAndHealthBlock(p)
                    }
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                    QuickActionCard(
                        title = "Vücut Analizi",
                        icon = Icons.Default.QueryStats,
                        modifier = Modifier.weight(1f),
                        iconContainerColor = Color(0xFFE3F2FD),
                        iconTint = Color(0xFF1565C0),
                        onClick = onAddMeasurement
                    )
                    QuickActionCard(
                        title = "Takviye Planı",
                        icon = Icons.Default.LocalDrink,
                        modifier = Modifier.weight(1f),
                        iconContainerColor = Color(0xFFE8F5E9),
                        iconTint = Color(0xFF2E7D32),
                        onClick = onOpenDietPlan
                    )
                }
            }
            if (latest != null) {
                item {
                    ClinicalAnalysisDashboard(
                        patient = p,
                        latest = latest,
                        previous = previous,
                        measurements = measurements
                    )
                }
                item {
                    val context = LocalContext.current
                    val analysisText = remember(p.id, latest.id, measurements.size) {
                        generateAnalysisReportText(patient = p, latest = latest, previous = previous, previousMonth = previousMonth, measurements = measurements)
                    }
                    ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = Color(0xFFFFF8E1), contentColor = Color(0xFF1F2937))) {
                        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("Analiz Raporu Paylaş", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text("PDF oluşturup paylaşabilir veya kısa analiz özetini WhatsApp ile gönderebilirsin.")
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                                OutlinedButton(
                                    onClick = { shareText(context, analysisText, p, false) },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.Share, null)
                                    Spacer(Modifier.size(6.dp))
                                    Text("Özeti Paylaş")
                                }
                                Button(
                                    onClick = {
                                        val pdf = createAnalysisPdf(context, p, measurements, analysisText)
                                        shareFile(context, pdf, p, "application/pdf")
                                    },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.PictureAsPdf, null)
                                    Spacer(Modifier.size(6.dp))
                                    Text("PDF Oluştur")
                                }
                            }
                        }
                    }
                }
                item { SmartCoachCard(patient = p, measurements = measurements) }
                item { ProfessionalAnalysisReportCard(patient = p, latest = latest, previous = previous, previousMonth = previousMonth, measurements = measurements) }
                item { ComparisonOverview(latest, previous, previousMonth, measurements.drop(1)) }
                item { MetricGrid(p, latest) }
                item { MetricChartsSection(measurements) }
            } else {
                item {
                    ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = Color(0xFFE3F2FD), contentColor = Color(0xFF0F172A))) {
                        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Henüz vücut analizi yok", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text("Yukarıdaki Vücut Analizi kartı ile ilk ölçümü ekleyebilir ve rapor görünümünü burada görebilirsin.")
                        }
                    }
                }
            }
            item { Text("Vücut Analizi Geçmişi", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
            items(measurements) { m ->
                Card {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text(formatDate(m.dateMillis), fontWeight = FontWeight.SemiBold)
                            Row {
                                IconButton(onClick = { onEditMeasurement(m.id) }) { Icon(Icons.Default.Edit, null) }
                                IconButton(onClick = { measurementPendingDelete = m }) { Icon(Icons.Default.Delete, null) }
                            }
                        }
                        Text("${m.analysisMode} • Kilo: ${m.weightKg.oneDecimal()} kg  •  VKİ: ${m.bmi.oneDecimal()}")
                        Text("Yağ: ${m.bodyFatPercent.oneDecimal()}%  •  Sıvı: ${m.bodyWaterPercent.oneDecimal()}%  •  Kas: ${m.muscle.oneDecimal()} • Bel: ${if (m.waistCm > 0) m.waistCm.oneDecimal() else "-"} cm")
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddMeasurementScreen(repo: BodyTrackerRepository, patientId: Long, measurementId: Long?, onBack: () -> Unit, onSaved: () -> Unit) {
    val scope = rememberCoroutineScope()
    val patient by repo.observePatient(patientId).collectAsState(initial = null)
    val existing by if (measurementId != null) {
        repo.observeMeasurement(measurementId).collectAsState(initial = null)
    } else {
        remember { mutableStateOf<MeasurementEntity?>(null) }
    }
    val p = patient ?: return

    var initialized by remember(existing?.id) { mutableStateOf(false) }
    var dateMillis by rememberSaveable { mutableStateOf(System.currentTimeMillis()) }
    var showDatePicker by remember { mutableStateOf(false) }
    var weightText by rememberSaveable { mutableStateOf("") }
    var fatText by rememberSaveable { mutableStateOf("") }
    var waterText by rememberSaveable { mutableStateOf("") }
    var muscleText by rememberSaveable { mutableStateOf("") }
    var waistText by rememberSaveable { mutableStateOf("") }
    var activityText by rememberSaveable { mutableStateOf("") }
    var boneText by rememberSaveable { mutableStateOf("") }
    var rateText by rememberSaveable { mutableStateOf("") }
    var metabolicAgeText by rememberSaveable { mutableStateOf("") }
    var visceralText by rememberSaveable { mutableStateOf("") }
    var analysisMode by rememberSaveable { mutableStateOf("Standart") }

    val existingMeasurement = existing
    if (existingMeasurement != null && !initialized) {
        dateMillis = existingMeasurement.dateMillis
        weightText = existingMeasurement.weightKg.toString()
        fatText = existingMeasurement.bodyFatPercent.toString()
        waterText = existingMeasurement.bodyWaterPercent.toString()
        muscleText = existingMeasurement.muscle.toString()
        waistText = if (existingMeasurement.waistCm > 0.0) existingMeasurement.waistCm.toString() else ""
        activityText = existingMeasurement.physicalActivity.toString()
        boneText = existingMeasurement.bone.toString()
        rateText = existingMeasurement.metabolicRate.toString()
        metabolicAgeText = existingMeasurement.metabolicAge.toString()
        visceralText = existingMeasurement.visceralFat.toString()
        analysisMode = existingMeasurement.analysisMode
        initialized = true
    }

    val bmi = calculateBmi(weightText.toDoubleOrNull() ?: 0.0, p.heightCm)

    Scaffold(topBar = { SmallTopAppBar(title = { Text(if (measurementId == null) "Yeni Ölçüm" else "Ölçüm Düzenle") }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) } }) }) { padding ->
        LazyColumn(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("${p.firstName} ${p.lastName}", fontWeight = FontWeight.Bold)
                        Text("Boy: ${p.heightCm} cm • Yaş: ${patientAge(p)}")
                        Text("VKİ otomatik hesaplanır.")
                        Text("Analiz türü: $analysisMode")
                    }
                }
            }
            item { DateField("Ölçüm Tarihi", formatDate(dateMillis)) { showDatePicker = true } }
            item {
                Text("Analiz tipi", style = MaterialTheme.typography.titleMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = analysisMode == "Standart", onClick = { analysisMode = "Standart" }, label = { Text("Vücut Analizi") })
                    FilterChip(selected = analysisMode == "Detoks", onClick = { analysisMode = "Detoks" }, label = { Text("Detoks") })
                }
            }
            item { NumericField("Kilo (kg)", weightText) { weightText = it } }
            item { ReferenceStatusCard("Kilo Referansı", weightReferenceStatus(weightText.toDoubleOrNull() ?: 0.0, p.heightCm)) }
            item {
                ElevatedCard { Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween) { Text("Otomatik VKİ", fontWeight = FontWeight.SemiBold); Text(bmi.oneDecimal(), style = MaterialTheme.typography.titleLarge) } }
            }
            item { ReferenceStatusCard("VKİ Referansı", bmiReferenceStatus(bmi)) }
            item { NumericField("Vücut Yağ Oranı (%)", fatText) { fatText = it } }
            item { ReferenceStatusCard("Yağ Oranı Referansı", bodyFatReferenceStatus(p.gender, patientAge(p), fatText.toDoubleOrNull() ?: 0.0)) }
            item { NumericField("Vücut Sıvı Oranı (%)", waterText) { waterText = it } }
            item { ReferenceStatusCard("Sıvı Oranı Referansı", bodyWaterReferenceStatus(p.gender, waterText.toDoubleOrNull() ?: 0.0)) }
            item { NumericField("Kas", muscleText) { muscleText = it } }
            item { ReferenceStatusCard("KPS Referansı", kpsReferenceStatus(weightText.toDoubleOrNull() ?: 0.0, muscleText.toDoubleOrNull() ?: 0.0)) }
            item { NumericField("Bel çevresi (cm)", waistText) { waistText = it } }
            item { NumericField("Fiziksel Aktivite", activityText) { activityText = it } }
            item { ReferenceStatusCard("Aktivite Referansı", activityReferenceStatus(activityText.toDoubleOrNull() ?: 0.0)) }
            item { NumericField("Kemik", boneText) { boneText = it } }
            item { ReferenceStatusCard("Kemik Referansı", boneReferenceStatus(p.gender, boneText.toDoubleOrNull() ?: 0.0)) }
            item { NumericField("Metabolizma Hızı", rateText) { rateText = it } }
            item { ReferenceStatusCard("Metabolizma Hızı Referansı", metabolicRateReferenceStatus(p.gender, patientAge(p), p.heightCm, weightText.toDoubleOrNull() ?: 0.0, rateText.toDoubleOrNull() ?: 0.0)) }
            item { NumericField("Metabolizma Yaşı", metabolicAgeText) { metabolicAgeText = it } }
            item { NumericField("İç Yağ", visceralText) { visceralText = it } }
            item { ReferenceStatusCard("İç Yağ Referansı", visceralFatReferenceStatus(visceralText.toDoubleOrNull() ?: 0.0)) }
            item {
                MeasurementLivePreviewCard(
                    patient = p,
                    bmi = bmi,
                    weight = weightText.toDoubleOrNull() ?: 0.0,
                    fat = fatText.toDoubleOrNull() ?: 0.0,
                    water = waterText.toDoubleOrNull() ?: 0.0,
                    muscle = muscleText.toDoubleOrNull() ?: 0.0,
                    visceral = visceralText.toDoubleOrNull() ?: 0.0
                )
            }
            item {
                Button(onClick = {
                    val weight = weightText.toDoubleOrNull() ?: 0.0
                    if (weight > 0) {
                        val entity = MeasurementEntity(
                            id = existing?.id ?: 0,
                            patientId = patientId,
                            dateMillis = dateMillis,
                            weightKg = weight,
                            bmi = bmi,
                            bodyFatPercent = fatText.toDoubleOrNull() ?: 0.0,
                            bodyWaterPercent = waterText.toDoubleOrNull() ?: 0.0,
                            muscle = muscleText.toDoubleOrNull() ?: 0.0,
                            waistCm = waistText.toDoubleOrNull() ?: 0.0,
                            physicalActivity = activityText.toDoubleOrNull() ?: 0.0,
                            bone = boneText.toDoubleOrNull() ?: 0.0,
                            metabolicRate = rateText.toDoubleOrNull() ?: 0.0,
                            metabolicAge = metabolicAgeText.toIntOrNull() ?: metabolicAgeHint(patientAge(p), bmi),
                            visceralFat = visceralText.toDoubleOrNull() ?: 0.0,
                            analysisMode = analysisMode
                        )
                        scope.launch {
                            if (existing == null) repo.addMeasurement(entity) else repo.updateMeasurement(entity)
                            onSaved()
                        }
                    }
                }, modifier = Modifier.fillMaxWidth()) { Text(if (measurementId == null) "Ölçümü Kaydet" else "Değişiklikleri Kaydet") }
            }
        }
    }
    if (showDatePicker) {
        ModernDatePicker(
            initial = dateMillis,
            title = "Ölçüm Tarihi",
            onDismiss = { showDatePicker = false },
            onConfirm = {
                dateMillis = it
                showDatePicker = false
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppointmentsScreen(repo: BodyTrackerRepository, patientId: Long, onBack: () -> Unit) {
    val context = LocalContext.current
    val activity = context as? Activity
    val scope = rememberCoroutineScope()
    val notificationPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        Toast.makeText(
            context,
            if (granted) "Bildirim izni verildi. Randevu bildirimi kurulabilir." else "Bildirim izni verilmedi. Randevu kaydedilir ama bildirim gösterilemeyebilir.",
            Toast.LENGTH_LONG
        ).show()
    }
    val patient by repo.observePatient(patientId).collectAsState(initial = null)
    val appointments by repo.observeAppointments(patientId).collectAsState(initial = emptyList())
    val measurements by repo.observeMeasurements(patientId).collectAsState(initial = emptyList())
    val dietPlans by repo.observeDietPlans(patientId).collectAsState(initial = emptyList())
    val products by repo.observeProducts().collectAsState(initial = emptyList())
    val p = patient ?: return
    val latest = measurements.firstOrNull()
    val previous = measurements.getOrNull(1)
    val currentPlan = remember(dietPlans, latest?.id) {
        dietPlans.firstOrNull { it.linkedMeasurementId == latest?.id } ?: dietPlans.firstOrNull()
    }
    var appointmentPlanProducts by remember(currentPlan?.id) { mutableStateOf(emptyList<com.example.bodytracker.data.DietPlanProductEntity>()) }
    LaunchedEffect(currentPlan?.id) {
        appointmentPlanProducts = currentPlan?.let { repo.getDietPlanProductsNow(it.id) } ?: emptyList()
    }
    val appointmentStockAlerts = remember(appointmentPlanProducts, products) {
        appointmentPlanProducts.mapNotNull { item ->
            val product = products.firstOrNull { it.id == item.productId } ?: return@mapNotNull null
            buildStockAlert(product, item)
        }
    }
    val appointmentStatus = remember(latest, previous, appointmentStockAlerts, appointmentPlanProducts) {
        buildTrackingStatus(latest, previous, appointmentStockAlerts, emptyList(), appointmentPlanProducts)
    }
    var title by rememberSaveable { mutableStateOf("") }
    var note by rememberSaveable { mutableStateOf("") }
    var dateMillis by rememberSaveable { mutableStateOf(System.currentTimeMillis()) }
    var hourText by rememberSaveable { mutableStateOf("09") }
    var minuteText by rememberSaveable { mutableStateOf("00") }
    var showDatePicker by remember { mutableStateOf(false) }

    fun ensureNotificationPermission(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return true
        return if (ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
            true
        } else {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            false
        }
    }

    LaunchedEffect(Unit) {
        ensureNotificationPermission()
    }

    fun hasExactAlarmPermission(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return true
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        return alarmManager.canScheduleExactAlarms()
    }

    fun openExactAlarmSettings() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return
        val requestIntent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
            data = Uri.parse("package:${context.packageName}")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        runCatching { activity?.startActivity(requestIntent) ?: context.startActivity(requestIntent) }
    }

    fun parseAppointmentMillis(selectedDateMillis: Long, hourValue: String, minuteValue: String): Long? {
        val hour = hourValue.toIntOrNull()
        val minute = minuteValue.toIntOrNull()
        if (hour == null || hour !in 0..23 || minute == null || minute !in 0..59) {
            Toast.makeText(context, "Lütfen geçerli saat girin. Saat 00-23, dakika 00-59 olmalı.", Toast.LENGTH_LONG).show()
            return null
        }
        return combineDateAndTime(selectedDateMillis, hour, minute)
    }

    fun scheduleAppointmentNotification(appointmentId: Long, whenMillis: Long, titleValue: String, noteValue: String): Boolean {
        if (whenMillis <= System.currentTimeMillis()) return false
        if (!ensureNotificationPermission()) return false
        if (!hasExactAlarmPermission()) {
            Toast.makeText(context, "Kesin alarm izni kapalı. Hatırlatıcı yine kurulacak fakat bazı cihazlarda birkaç dakika gecikebilir.", Toast.LENGTH_LONG).show()
        }
        val patientName = "${p.firstName} ${p.lastName}"
        val intent = AppointmentAlarmReceiver.buildAlarmIntent(
            context = context,
            appointmentId = appointmentId,
            patientId = patientId,
            patientName = patientName,
            title = titleValue,
            note = noteValue,
            whenMillis = whenMillis,
            whenText = formatDateTime(whenMillis)
        )
        AppointmentAlarmReceiver.scheduleBestEffort(context, intent, whenMillis)
        return true
    }

    fun cancelAppointmentNotification(appointmentId: Long) {
        AppointmentAlarmReceiver.cancel(context, appointmentId)
    }

    Scaffold(topBar = { SmallTopAppBar(title = { Text("Randevu Takibi") }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) } }) }) { padding ->
        LazyColumn(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("${p.firstName} ${p.lastName}", fontWeight = FontWeight.Bold)
                        Text("Randevu tarihini değiştirdiğinizde kayıt ve hatırlatıcı birlikte güncellenir. Geçmiş tarih için bildirim kurulmaz.")
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !hasExactAlarmPermission()) {
                            OutlinedButton(onClick = { openExactAlarmSettings() }) {
                                Icon(Icons.Default.Alarm, null)
                                Spacer(Modifier.size(6.dp))
                                Text("Kesin alarm iznini aç")
                            }
                        }
                    }
                }
            }
            item {
                AppointmentPlanIntegrationPanel(
                    status = appointmentStatus,
                    latest = latest,
                    previous = previous,
                    plan = currentPlan,
                    productCount = appointmentPlanProducts.size,
                    stockAlerts = appointmentStockAlerts
                )
            }
            item { OutlinedTextField(title, { title = it }, Modifier.fillMaxWidth(), label = { Text("Randevu Başlığı") }, leadingIcon = { Icon(Icons.Default.Event, null) }) }
            item { DateField("Randevu Tarihi", formatDate(dateMillis)) { showDatePicker = true } }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = hourText,
                        onValueChange = { hourText = it.filter(Char::isDigit).take(2) },
                        modifier = Modifier.weight(1f),
                        label = { Text("Saat") },
                        leadingIcon = { Icon(Icons.Default.AccessTime, null) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = minuteText,
                        onValueChange = { minuteText = it.filter(Char::isDigit).take(2) },
                        modifier = Modifier.weight(1f),
                        label = { Text("Dakika") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true
                    )
                }
            }
            item { OutlinedTextField(note, { note = it }, Modifier.fillMaxWidth().height(120.dp), label = { Text("Not") }) }
            item {
                Button(onClick = {
                    val cleanTitle = title.trim()
                    if (cleanTitle.isNotBlank()) {
                        val whenMillis = parseAppointmentMillis(dateMillis, hourText, minuteText) ?: return@Button
                        if (whenMillis <= System.currentTimeMillis()) {
                            Toast.makeText(context, "Geçmiş tarihli randevu kaydedilmez. Lütfen gelecek bir tarih/saat seçin.", Toast.LENGTH_LONG).show()
                            return@Button
                        }
                        scope.launch {
                            val appointmentId = repo.addAppointment(AppointmentEntity(patientId = patientId, dateMillis = whenMillis, title = cleanTitle, note = note.trim()))
                            val scheduled = scheduleAppointmentNotification(appointmentId, whenMillis, cleanTitle, note.trim())
                            title = ""
                            note = ""
                            dateMillis = System.currentTimeMillis()
                            hourText = "09"
                            minuteText = "00"
                            Toast.makeText(
                                context,
                                if (scheduled) "Randevu kaydedildi ve bildirim kuruldu" else "Randevu kaydedildi. Gelecek tarih ve bildirim/alarm izinlerini kontrol edin.",
                                Toast.LENGTH_LONG
                            ).show()
                        }
                    }
                }, modifier = Modifier.fillMaxWidth()) { Text("Randevu Kaydet ve Bildirim Kur") }
            }
            item { Text("Kayıtlı Randevular", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
            items(appointments, key = { it.id }) { appt ->
                var showEditDialog by rememberSaveable(appt.id) { mutableStateOf(false) }
                var editTitle by rememberSaveable(appt.id) { mutableStateOf(appt.title) }
                var editNote by rememberSaveable(appt.id) { mutableStateOf(appt.note) }
                var editDateMillis by rememberSaveable(appt.id) { mutableStateOf(appt.dateMillis) }
                var editHourText by rememberSaveable(appt.id) { mutableStateOf(java.util.Calendar.getInstance().apply { timeInMillis = appt.dateMillis }.get(java.util.Calendar.HOUR_OF_DAY).toString().padStart(2, '0')) }
                var editMinuteText by rememberSaveable(appt.id) { mutableStateOf(java.util.Calendar.getInstance().apply { timeInMillis = appt.dateMillis }.get(java.util.Calendar.MINUTE).toString().padStart(2, '0')) }
                var showEditDatePicker by remember { mutableStateOf(false) }

                Card {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(appt.title, fontWeight = FontWeight.SemiBold)
                                Text(formatDateTime(appt.dateMillis))
                                Text("Danışan: ${p.firstName} ${p.lastName}", style = MaterialTheme.typography.bodySmall)
                            }
                            Row {
                                IconButton(onClick = {
                                    editTitle = appt.title
                                    editNote = appt.note
                                    editDateMillis = appt.dateMillis
                                    val cal = java.util.Calendar.getInstance().apply { timeInMillis = appt.dateMillis }
                                    editHourText = cal.get(java.util.Calendar.HOUR_OF_DAY).toString().padStart(2, '0')
                                    editMinuteText = cal.get(java.util.Calendar.MINUTE).toString().padStart(2, '0')
                                    showEditDialog = true
                                }) { Icon(Icons.Default.Edit, null) }
                                IconButton(onClick = {
                                    scope.launch {
                                        cancelAppointmentNotification(appt.id)
                                        repo.deleteAppointment(appt)
                                    }
                                }) { Icon(Icons.Default.Delete, null) }
                            }
                        }
                        if (appt.note.isNotBlank()) Text("Not: ${appt.note}")
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = {
                                scope.launch {
                                    val newMillis = appt.dateMillis + 60 * 60 * 1000L
                                    val updated = appt.copy(dateMillis = newMillis)
                                    repo.updateAppointment(updated)
                                    cancelAppointmentNotification(updated.id)
                                    val scheduled = scheduleAppointmentNotification(updated.id, newMillis, updated.title, updated.note)
                                    Toast.makeText(context, if (scheduled) "1 saat ertelendi ve bildirim güncellendi" else "Randevu ertelendi; bildirim için izinleri kontrol edin", Toast.LENGTH_LONG).show()
                                }
                            }) { Icon(Icons.Default.Alarm, null); Spacer(Modifier.size(6.dp)); Text("Ertele") }
                            Button(onClick = {
                                scope.launch {
                                    cancelAppointmentNotification(appt.id)
                                    repo.deleteAppointment(appt)
                                }
                            }) { Icon(Icons.Default.Done, null); Spacer(Modifier.size(6.dp)); Text("Tamam") }
                        }
                    }
                }

                if (showEditDialog) {
                    AlertDialog(
                        onDismissRequest = { showEditDialog = false },
                        title = { Text("Randevuyu Düzenle") },
                        text = {
                            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                OutlinedTextField(editTitle, { editTitle = it }, Modifier.fillMaxWidth(), label = { Text("Başlık") }, singleLine = true)
                                DateField("Tarih", formatDate(editDateMillis)) { showEditDatePicker = true }
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                    OutlinedTextField(editHourText, { editHourText = it.filter(Char::isDigit).take(2) }, Modifier.weight(1f), label = { Text("Saat") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                                    OutlinedTextField(editMinuteText, { editMinuteText = it.filter(Char::isDigit).take(2) }, Modifier.weight(1f), label = { Text("Dakika") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                                }
                                OutlinedTextField(editNote, { editNote = it }, Modifier.fillMaxWidth().height(100.dp), label = { Text("Not") })
                            }
                        },
                        confirmButton = {
                            TextButton(onClick = {
                                val cleanTitle = editTitle.trim()
                                if (cleanTitle.isNotBlank()) {
                                    val updatedMillis = parseAppointmentMillis(editDateMillis, editHourText, editMinuteText) ?: return@TextButton
                                    if (updatedMillis <= System.currentTimeMillis()) {
                                        Toast.makeText(context, "Randevu tarihi geçmişte olamaz. Lütfen gelecek tarih/saat seçin.", Toast.LENGTH_LONG).show()
                                        return@TextButton
                                    }
                                    val updated = appt.copy(dateMillis = updatedMillis, title = cleanTitle, note = editNote.trim())
                                    scope.launch {
                                        repo.updateAppointment(updated)
                                        cancelAppointmentNotification(updated.id)
                                        val scheduled = scheduleAppointmentNotification(updated.id, updatedMillis, updated.title, updated.note)
                                        showEditDialog = false
                                        Toast.makeText(context, if (scheduled) "Randevu ve hatırlatıcı güncellendi" else "Randevu güncellendi; bildirim için izinleri ve tarih/saat bilgisini kontrol edin", Toast.LENGTH_LONG).show()
                                    }
                                }
                            }) { Text("Kaydet") }
                        },
                        dismissButton = { TextButton(onClick = { showEditDialog = false }) { Text("İptal") } }
                    )
                }
                if (showEditDatePicker) {
                    ModernDatePicker(
                        initial = editDateMillis,
                        title = "Randevu Tarihi",
                        onDismiss = { showEditDatePicker = false },
                        onConfirm = {
                            editDateMillis = it
                            showEditDatePicker = false
                        }
                    )
                }
            }
        }
    }
    if (showDatePicker) {
        ModernDatePicker(
            initial = dateMillis,
            title = "Randevu Tarihi",
            onDismiss = { showDatePicker = false },
            onConfirm = {
                dateMillis = it
                showDatePicker = false
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DietPlanScreen(repo: BodyTrackerRepository, patientId: Long, onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val patient by repo.observePatient(patientId).collectAsState(initial = null)
    val measurements by repo.observeMeasurements(patientId).collectAsState(initial = emptyList())
    val categories by repo.observeCategories().collectAsState(initial = emptyList())
    val products by repo.observeProducts().collectAsState(initial = emptyList())
    val dietPlans by repo.observeDietPlans(patientId).collectAsState(initial = emptyList())
    val decisionLogs by repo.observeDecisionLogs(patientId).collectAsState(initial = emptyList())
    val complianceLogs by repo.observeCompliance(patientId).collectAsState(initial = emptyList())
    val planTemplates by repo.observePlanTemplates().collectAsState(initial = emptyList())
    val p = patient ?: return
    val latest = measurements.firstOrNull()
    var selectedMeasurementId by rememberSaveable(latest?.id) { mutableStateOf(latest?.id) }
    val currentPlan = remember(dietPlans, selectedMeasurementId) {
        dietPlans.firstOrNull { it.linkedMeasurementId == selectedMeasurementId }
            ?: if (selectedMeasurementId == null) dietPlans.firstOrNull() else null
    }
    val selectedPlanProducts by if (currentPlan != null) {
        repo.observeDietPlanProducts(currentPlan.id).collectAsState(initial = emptyList())
    } else {
        remember(currentPlan) { mutableStateOf(emptyList()) }
    }

    var goal by rememberSaveable { mutableStateOf("Kilo kontrolü") }
    var meals by rememberSaveable { mutableStateOf("3 ana öğün + 2 ara öğün") }
    var water by rememberSaveable { mutableStateOf("Günde 2-2.5 litre su") }
    var targetWeightText by rememberSaveable { mutableStateOf("") }
    var targetFatText by rememberSaveable { mutableStateOf("") }
    var medicalHistory by rememberSaveable { mutableStateOf("") }
    var allergies by rememberSaveable { mutableStateOf("") }
    var medications by rememberSaveable { mutableStateOf("") }
    var notes by rememberSaveable { mutableStateOf("") }
    var productQuery by rememberSaveable { mutableStateOf("") }
    var selectedCategoryId by rememberSaveable { mutableStateOf<Long?>(null) }
    var showAddSupplementDialog by remember { mutableStateOf(false) }
    var selectedProductIdForAdd by rememberSaveable { mutableStateOf<Long?>(null) }
    var editingCatalogProduct by remember { mutableStateOf<com.example.bodytracker.data.ProductEntity?>(null) }
    var addApplicationMethod by rememberSaveable { mutableStateOf("Ağızdan") }
    var addUsagePattern by rememberSaveable { mutableStateOf("1x2") }
    var addQuantityValue by rememberSaveable { mutableStateOf("1") }
    var addQuantityUnit by rememberSaveable { mutableStateOf("adet") }
    var addPackageCount by rememberSaveable { mutableStateOf("1") }
    var addPackageSize by rememberSaveable { mutableStateOf("60") }
    var addPackageUnit by rememberSaveable { mutableStateOf("adet") }
    var addDailyUsage by rememberSaveable { mutableStateOf("2") }
    var addTimingNote by rememberSaveable { mutableStateOf("") }
    var addNote by rememberSaveable { mutableStateOf("") }

    val selectedMeasurement = measurements.firstOrNull { it.id == selectedMeasurementId } ?: latest
    val previousForSelected = remember(measurements, selectedMeasurement?.id) {
        val index = measurements.indexOfFirst { it.id == selectedMeasurement?.id }
        if (index >= 0) measurements.getOrNull(index + 1) else measurements.getOrNull(1)
    }
    val previousPlan = remember(dietPlans, previousForSelected?.id) {
        dietPlans.firstOrNull { it.linkedMeasurementId == previousForSelected?.id }
    }
    var previousPlanProducts by remember(previousPlan?.id) { mutableStateOf(emptyList<com.example.bodytracker.data.DietPlanProductEntity>()) }
    LaunchedEffect(previousPlan?.id) {
        previousPlanProducts = previousPlan?.let { repo.getDietPlanProductsNow(it.id) } ?: emptyList()
    }

    val selectedProducts = remember(products, selectedPlanProducts) {
        val ids = selectedPlanProducts.map { it.productId }.toSet()
        products.filter { it.id in ids }
    }
    val filteredProducts = remember(products, productQuery, selectedCategoryId) {
        products.filter { product ->
            val categoryOk = selectedCategoryId == null || product.categoryId == selectedCategoryId
            val q = productQuery.trim().lowercase()
            val queryOk = q.isBlank() || listOf(product.name, product.brand, product.description, product.defaultDose, product.timing)
                .plus(product.code)
                .any { it.lowercase().contains(q) }
            categoryOk && queryOk
        }
    }
    val browseProducts = remember(filteredProducts, selectedPlanProducts) {
        val selectedIds = selectedPlanProducts.map { it.productId }.toSet()
        filteredProducts.filterNot { it.id in selectedIds }
    }

    val supplementLines = remember(selectedProducts, selectedPlanProducts) {
        selectedProducts.mapNotNull { product ->
            val item = selectedPlanProducts.firstOrNull { it.productId == product.id } ?: return@mapNotNull null
            formatSupplementLine(product, item)
        }
    }
    val stockAlerts = remember(selectedProducts, selectedPlanProducts) {
        selectedPlanProducts.mapNotNull { item ->
            val product = selectedProducts.firstOrNull { it.id == item.productId } ?: return@mapNotNull null
            buildStockAlert(product, item)
        }
    }
    val smartRecommendations = remember(products, selectedPlanProducts, selectedMeasurement, goal, p.allergies, p.medications, p.gender, p.ageYears) {
        buildProductRecommendations(
            patient = p,
            latest = selectedMeasurement,
            products = products,
            selectedProductIds = selectedPlanProducts.map { it.productId }.toSet(),
            goal = goal
        )
    }
    val planActions = remember(p.id, selectedMeasurement?.id, previousForSelected?.id, latest?.id) {
        buildPlanActions(p, selectedMeasurement ?: latest, previousForSelected)
    }
    val nutritionActions = remember(p.id, selectedMeasurement?.id, latest?.id, goal) {
        buildNutritionActions(p, selectedMeasurement ?: latest, goal)
    }
    val historyInsights = remember(measurements, dietPlans, currentPlan?.id, selectedMeasurement?.id) {
        buildPlanHistoryInsights(measurements, dietPlans, currentPlan, selectedMeasurement)
    }
    val planComparisonInsights = remember(selectedPlanProducts, previousPlanProducts, products, selectedMeasurement?.id, previousForSelected?.id) {
        buildPlanComparisonInsights(
            currentItems = selectedPlanProducts,
            previousItems = previousPlanProducts,
            products = products,
            currentMeasurement = selectedMeasurement,
            previousMeasurement = previousForSelected
        )
    }
    val planQuality = remember(selectedMeasurement, selectedPlanProducts, stockAlerts, nutritionActions, planActions, complianceLogs, notes, currentPlan?.id) {
        buildPlanQualityScore(
            measurement = selectedMeasurement,
            selectedItems = selectedPlanProducts,
            stockAlerts = stockAlerts,
            nutritionActions = nutritionActions,
            planActions = planActions,
            complianceLogs = complianceLogs,
            notes = notes
        )
    }
    val trackingStatus = remember(selectedMeasurement, previousForSelected, stockAlerts, complianceLogs, selectedPlanProducts) {
        buildTrackingStatus(selectedMeasurement, previousForSelected, stockAlerts, complianceLogs, selectedPlanProducts)
    }
    val selectedProductForAdd = products.firstOrNull { it.id == selectedProductIdForAdd }
    editingCatalogProduct?.let { product ->
        ProductCatalogEditDialog(
            product = product,
            onDismiss = { editingCatalogProduct = null },
            onSave = { updated ->
                scope.launch { repo.updateProduct(updated) }
                editingCatalogProduct = null
            }
        )
    }

    val planText = remember(p, measurements, goal, meals, water, notes, supplementLines) {
        generateDietPlanText(p, measurements, goal, meals, water, notes, supplementLines)
    }

    fun addOrRemoveProduct(product: com.example.bodytracker.data.ProductEntity, remove: Boolean) {
        scope.launch {
            val planId = currentPlan?.id ?: repo.addDietPlan(
                com.example.bodytracker.data.DietPlanEntity(
                    patientId = patientId,
                    linkedMeasurementId = selectedMeasurementId,
                    title = "${p.firstName} ${p.lastName} Takviye Kaydı",
                    description = selectedMeasurementId?.let { "Analiz kaydına bağlı takviye önerisi" } ?: "Genel takviye önerisi"
                )
            )
            val existing = selectedPlanProducts.firstOrNull { it.productId == product.id }
            if (remove) {
                if (existing != null) repo.deleteDietPlanProduct(existing)
            } else if (existing == null) {
                repo.addDietPlanProduct(
                    com.example.bodytracker.data.DietPlanProductEntity(
                        dietPlanId = planId,
                        productId = product.id,
                        customDose = product.defaultDose,
                        customTiming = product.timing,
                        applicationMethod = suggestApplicationMethod(product, categories.firstOrNull { it.id == product.categoryId }?.name.orEmpty()),
                        usagePattern = suggestUsagePattern(product),
                        quantityValue = suggestQuantityValue(product),
                        quantityUnit = suggestQuantityUnit(product),
                        packageCount = "1",
                        packageSize = suggestPackageSize(product),
                        packageUnit = suggestQuantityUnit(product),
                        dailyUsage = suggestDailyUsage(suggestUsagePattern(product), suggestQuantityValue(product)),
                        timingNote = product.timing,
                        goalTag = goal,
                        customNote = product.usageNote,
                        sortOrder = selectedPlanProducts.size + 1
                    )
                )
            }
        }
    }

    fun addProductWithDetails(product: com.example.bodytracker.data.ProductEntity) {
        scope.launch {
            val planId = currentPlan?.id ?: repo.addDietPlan(
                com.example.bodytracker.data.DietPlanEntity(
                    patientId = patientId,
                    linkedMeasurementId = selectedMeasurementId,
                    title = "${p.firstName} ${p.lastName} Takviye Kaydı",
                    description = selectedMeasurementId?.let { "Analiz kaydına bağlı takviye önerisi" } ?: "Genel takviye önerisi"
                )
            )
            val existing = selectedPlanProducts.firstOrNull { it.productId == product.id }
            if (existing == null) {
                repo.addDietPlanProduct(
                    com.example.bodytracker.data.DietPlanProductEntity(
                        dietPlanId = planId,
                        productId = product.id,
                        customDose = listOf(addQuantityValue, addQuantityUnit).filter { it.isNotBlank() }.joinToString(" "),
                        customTiming = addTimingNote,
                        applicationMethod = addApplicationMethod,
                        usagePattern = addUsagePattern,
                        quantityValue = addQuantityValue,
                        quantityUnit = addQuantityUnit,
                        packageCount = addPackageCount,
                        packageSize = addPackageSize,
                        packageUnit = addPackageUnit,
                        dailyUsage = addDailyUsage,
                        timingNote = addTimingNote,
                        goalTag = goal,
                        customNote = addNote,
                        sortOrder = selectedPlanProducts.size + 1
                    )
                )
            }
            showAddSupplementDialog = false
            selectedProductIdForAdd = null
            addNote = ""
            productQuery = ""
        }
    }

    fun createStockReminder(alert: StockAlert) {
        scope.launch {
            val whenMillis = System.currentTimeMillis() + 24L * 60L * 60L * 1000L
            val titleValue = "${p.firstName} ${p.lastName} - Stok yenileme"
            val noteValue = "${alert.title}\n${alert.detail}"
            val appointmentId = repo.addAppointment(
                AppointmentEntity(
                    patientId = patientId,
                    dateMillis = whenMillis,
                    title = titleValue,
                    note = noteValue
                )
            )
            val intent = AppointmentAlarmReceiver.buildAlarmIntent(
                context = context,
                appointmentId = appointmentId,
                patientId = patientId,
                patientName = "${p.firstName} ${p.lastName}",
                title = titleValue,
                note = noteValue,
                whenMillis = whenMillis,
                whenText = formatDateTime(whenMillis)
            )
            AppointmentAlarmReceiver.scheduleBestEffort(context, intent, whenMillis)
            Toast.makeText(context, "Stok hatırlatıcısı randevuya eklendi", Toast.LENGTH_LONG).show()
        }
    }

    if (showAddSupplementDialog) {
        AlertDialog(
            onDismissRequest = { showAddSupplementDialog = false },
            properties = DialogProperties(usePlatformDefaultWidth = false),
            confirmButton = {
                TextButton(onClick = {
                    selectedProductForAdd?.let { addProductWithDetails(it) }
                }, enabled = selectedProductForAdd != null) { Text("Takviyeyi ekle") }
            },
            dismissButton = { TextButton(onClick = { showAddSupplementDialog = false }) { Text("Kapat") } },
            title = { Text("Bu analize takviye ekle") },
            text = {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth().height(520.dp)
                ) {
                    item {
                        Text(
                            "Önce kategori seç. Arama alanı sadece istersen filtrelemek için kullanılır.",
                            color = Color(0xFFC9D7E3),
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    item {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                FilterChip(
                                    selected = selectedCategoryId == null,
                                    onClick = { selectedCategoryId = null },
                                    label = { Text("Tümü") }
                                )
                            }
                            categories.chunked(2).forEach { chunk ->
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    chunk.forEach { cat ->
                                        FilterChip(
                                            selected = selectedCategoryId == cat.id,
                                            onClick = {
                                                selectedCategoryId = if (selectedCategoryId == cat.id) null else cat.id
                                            },
                                            label = { Text(cat.name) }
                                        )
                                    }
                                }
                            }
                        }
                    }
                    item {
                        OutlinedTextField(
                            value = productQuery,
                            onValueChange = { productQuery = it },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            label = { Text("Kod veya isim ara") },
                            leadingIcon = { Icon(Icons.Default.Search, null) }
                        )
                    }
                    item {
                        val categoryLabel = categories.firstOrNull { it.id == selectedCategoryId }?.name ?: "Tüm takviyeler"
                        Surface(shape = MaterialTheme.shapes.medium, color = MaterialTheme.colorScheme.secondaryContainer) {
                            Text(
                                "$categoryLabel • ${browseProducts.size} ürün",
                                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                    if (browseProducts.isEmpty()) {
                        item {
                            ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                                Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text("Bu seçim için ürün bulunamadı", fontWeight = FontWeight.Bold)
                                    Text("Kategoriyi değiştir veya arama alanını temizleyerek tekrar dene.")
                                }
                            }
                        }
                    } else {
                        items(browseProducts) { product ->
                            val selected = selectedProductIdForAdd == product.id
                            val categoryName = categories.firstOrNull { it.id == product.categoryId }?.name.orEmpty()
                            ProductSelectionCard(
                                product = product,
                                categoryName = categoryName,
                                selected = selected,
                                onEdit = { editingCatalogProduct = product },
                                onToggle = {
                                    selectedProductIdForAdd = product.id
                                    addApplicationMethod = suggestApplicationMethod(product, categoryName)
                                    addUsagePattern = suggestUsagePattern(product)
                                    addQuantityValue = suggestQuantityValue(product)
                                    addQuantityUnit = suggestQuantityUnit(product)
                                    addPackageCount = "1"
                                    addPackageSize = suggestPackageSize(product)
                                    addPackageUnit = suggestQuantityUnit(product)
                                    addDailyUsage = suggestDailyUsage(addUsagePattern, addQuantityValue)
                                    addTimingNote = product.timing
                                    addNote = product.usageNote
                                }
                            )
                        }
                    }
                    if (selectedProductForAdd != null) {
                        item {
                            ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = Color(0xFFF5F9FF), contentColor = Color(0xFF0F172A))) {
                                Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Text("Seçilen takviye detayları", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                    Text(selectedProductForAdd.name)
                                    Text("Uygulama türü", fontWeight = FontWeight.SemiBold)
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        listOf("Ağızdan", "Çiğneme", "Saça", "Dış deriye").forEach { option ->
                                            FilterChip(selected = addApplicationMethod == option, onClick = { addApplicationMethod = option }, label = { Text(option) })
                                        }
                                    }
                                    Text("Kullanım şekli", fontWeight = FontWeight.SemiBold)
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        listOf("1x1", "1x2", "2x1", "2x2").forEach { option ->
                                            FilterChip(
                                                selected = addUsagePattern == option,
                                                onClick = {
                                                    addUsagePattern = option
                                                    addDailyUsage = suggestDailyUsage(option, addQuantityValue)
                                                },
                                                label = { Text(option) }
                                            )
                                        }
                                    }
                                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                                        OutlinedTextField(
                                            addQuantityValue,
                                            {
                                                addQuantityValue = it
                                                addDailyUsage = suggestDailyUsage(addUsagePattern, it)
                                            },
                                            modifier = Modifier.weight(0.8f),
                                            label = { Text("Kullanım miktarı") },
                                            singleLine = true
                                        )
                                        OutlinedTextField(addQuantityUnit, { addQuantityUnit = it }, modifier = Modifier.weight(1.2f), label = { Text("Birim") }, singleLine = true)
                                    }
                                    Text("Stok / kutu bilgisi", fontWeight = FontWeight.SemiBold)
                                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                                        OutlinedTextField(addPackageCount, { addPackageCount = it.filterStockNumber() }, modifier = Modifier.weight(1f), label = { Text("Kutu") }, singleLine = true)
                                        OutlinedTextField(addPackageSize, { addPackageSize = it.filterStockNumber() }, modifier = Modifier.weight(1f), label = { Text("Kutu içi") }, singleLine = true)
                                        OutlinedTextField(addPackageUnit, { addPackageUnit = it }, modifier = Modifier.weight(1f), label = { Text("Birim") }, singleLine = true)
                                    }
                                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                                        OutlinedTextField(addDailyUsage, { addDailyUsage = it.filterStockNumber() }, modifier = Modifier.weight(1f), label = { Text("Günlük tüketim") }, singleLine = true)
                                        StockProjectionCard(
                                            item = com.example.bodytracker.data.DietPlanProductEntity(
                                                dietPlanId = 0,
                                                productId = selectedProductForAdd.id,
                                                quantityValue = addQuantityValue,
                                                quantityUnit = addQuantityUnit,
                                                packageCount = addPackageCount,
                                                packageSize = addPackageSize,
                                                packageUnit = addPackageUnit,
                                                dailyUsage = addDailyUsage,
                                                usagePattern = addUsagePattern
                                            ),
                                            compact = true,
                                            modifier = Modifier.weight(1f)
                                        )
                                    }
                                    OutlinedTextField(addTimingNote, { addTimingNote = it }, Modifier.fillMaxWidth(), label = { Text("Zaman") })
                                    OutlinedTextField(addNote, { addNote = it }, Modifier.fillMaxWidth(), label = { Text("Ek not") })
                                }
                            }
                        }
                    }
                }
            }
        )
    }


    Scaffold(
        topBar = {
            SmallTopAppBar(
                title = { Text("Takviye ve Beslenme Planı") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) } }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = Color(0xFFF2F8F4), contentColor = Color(0xFF0F172A))) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("${p.firstName} ${p.lastName}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Text("Analizden beslenme planına uzanan tek ekran", color = Color(0xFFC9D7E3))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            AnalysisBadge("Kilo", latest?.weightKg?.oneDecimal()?.plus(" kg") ?: "-")
                            AnalysisBadge("VKİ", latest?.bmi?.oneDecimal() ?: "-")
                            AnalysisBadge("Yağ", latest?.bodyFatPercent?.oneDecimal()?.plus("%") ?: "-")
                        }
                    }
                }
            }
            item {
                Text("Plan odağı", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            }
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(
                        listOf("Kilo kontrolü", "Sindirim desteği"),
                        listOf("Enerji", "Cilt ve saç")
                    ).forEach { rowItems ->
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            rowItems.forEach { label ->
                                FilterChip(
                                    selected = goal == label,
                                    onClick = { goal = label },
                                    label = { Text(label) }
                                )
                            }
                        }
                    }
                }
            }
            item {
                ElevatedCard {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Beslenme omurgası", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        OutlinedTextField(meals, { meals = it }, Modifier.fillMaxWidth(), label = { Text("Öğün planı") })
                        OutlinedTextField(water, { water = it }, Modifier.fillMaxWidth(), label = { Text("Su planı") })
                        OutlinedTextField(notes, { notes = it }, Modifier.fillMaxWidth().height(120.dp), label = { Text("Uzman notu") })
                    }
                }
            }
            item {
                TrackingStatusAndQualityPanel(status = trackingStatus, quality = planQuality)
            }
            item {
                PlanTemplatePanel(
                    templates = planTemplates,
                    actions = planActions,
                    onApply = { template ->
                        meals = template.meals
                        water = template.water
                        notes = listOf(notes, template.nutritionNotes, "Ürün odağı: ${template.productFocus}", "Aktivite: ${template.activityFocus}")
                            .filter { it.isNotBlank() }
                            .joinToString("\n")
                    }
                )
            }
            item {
                ComplianceTrackerPanel(
                    patientId = patientId,
                    dietPlanId = currentPlan?.id,
                    logs = complianceLogs,
                    onSave = { item -> scope.launch { repo.saveCompliance(item) } }
                )
            }
            item {
                SmartNutritionPanel(nutritionActions)
            }
            item {
                ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = Color(0xFFE9F4EE), contentColor = Color(0xFF0F172A))) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Takviye kaydını bağlayacağın analiz", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text("Takviyeler haftalık değil, seçtiğin analiz kaydına bağlı olarak saklanır. PDF içinde ilk, sondan bir önceki ve son kayıt ayrı ayrı gösterilir.")
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(measurements.take(6)) { measurement ->
                                val label = when (measurement.id) {
                                    measurements.lastOrNull()?.id -> "İlk Kayıt"
                                    measurements.getOrNull(1)?.id -> "Sondan Bir Önceki"
                                    measurements.firstOrNull()?.id -> "Son Kayıt"
                                    else -> formatDate(measurement.dateMillis)
                                }
                                FilterChip(
                                    selected = selectedMeasurementId == measurement.id,
                                    onClick = { selectedMeasurementId = measurement.id },
                                    label = { Text("$label · ${formatDate(measurement.dateMillis)}") }
                                )
                            }
                        }
                        selectedMeasurement?.let {
                            Surface(shape = MaterialTheme.shapes.medium, color = MaterialTheme.colorScheme.surfaceVariant) {
                                Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text("Seçili analiz özeti", fontWeight = FontWeight.SemiBold)
                                    Text("Tarih: ${formatDate(it.dateMillis)}")
                                    Text("Kilo: ${it.weightKg.oneDecimal()} kg · Yağ: ${it.bodyFatPercent.oneDecimal()}% · Sıvı: ${it.bodyWaterPercent.oneDecimal()}%")
                                    Text("Bu kayda ait kullanılan takviyeler aşağıda düzenlenir.", color = MaterialTheme.colorScheme.primary)
                                }
                            }
                        }
                    }
                }
            }
            item {
                PlanHistoryInsightPanel(historyInsights)
            }
            item {
                PreviousPlanComparisonPanel(planComparisonInsights)
            }
            item {
                DecisionLogPanel(
                    logs = decisionLogs,
                    patientId = patientId,
                    measurementId = selectedMeasurement?.id,
                    dietPlanId = currentPlan?.id,
                    suggestedActions = planActions,
                    onAdd = { log -> scope.launch { repo.addDecisionLog(log) } }
                )
            }
            item {
                SupplementOperationsSummary(
                    selectedCount = selectedPlanProducts.size,
                    alertCount = stockAlerts.size,
                    criticalCount = stockAlerts.count { it.level == ReferenceLevel.HIGH },
                    missingCount = stockAlerts.count { it.level == ReferenceLevel.INFO }
                )
            }
            item {
                SmartPlanActionPanel(planActions)
            }
            item {
                SmartProductRecommendationPanel(
                    recommendations = smartRecommendations,
                    onAdd = { product -> addOrRemoveProduct(product, false) }
                )
            }
            item {
                ElevatedCard {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Takviye seçimi", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text("Kategori seç, sonra küçük seçim penceresinden takviyeyi kullanım detaylarıyla birlikte ekle.")
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                FilterChip(selected = selectedCategoryId == null, onClick = { selectedCategoryId = null }, label = { Text("Tüm takviyeler") })
                            }
                            categories.chunked(2).forEach { chunk ->
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    chunk.forEach { cat ->
                                        FilterChip(
                                            selected = selectedCategoryId == cat.id,
                                            onClick = { selectedCategoryId = if (selectedCategoryId == cat.id) null else cat.id },
                                            label = { Text(cat.name) }
                                        )
                                    }
                                }
                            }
                        }
                        Button(onClick = { showAddSupplementDialog = true }, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.Add, null)
                            Spacer(Modifier.size(6.dp))
                            Text("Bu analize takviye ekle")
                        }
                        Surface(shape = MaterialTheme.shapes.medium, color = MaterialTheme.colorScheme.surfaceVariant) {
                            Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("Seçilen kategoriye göre görünen ürünler", fontWeight = FontWeight.SemiBold)
                                if (browseProducts.isEmpty()) {
                                    Text("Bu seçim için ürün görünmüyor.")
                                } else {
                                    browseProducts.take(5).forEach { product ->
                                        val categoryName = categories.firstOrNull { it.id == product.categoryId }?.name.orEmpty()
                                        Text("• ${product.name}${if (categoryName.isNotBlank()) " — $categoryName" else ""}")
                                    }
                                    if (browseProducts.size > 5) {
                                        Text("+ ${browseProducts.size - 5} ürün daha", color = MaterialTheme.colorScheme.primary)
                                    }
                                }
                            }
                        }
                        if (selectedPlanProducts.isNotEmpty()) {
                            Text("Eklenen kart sayısı: ${selectedPlanProducts.size}", color = Color(0xFFC9D7E3))
                        }
                    }
                }
            }
            item {
                ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = Color(0xFFFFF8EA), contentColor = Color(0xFF1F2937))) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Seçili analiz kaydındaki takviyeler", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        if (selectedProducts.isEmpty()) {
                            Text("Bu analiz kaydı için henüz takviye seçilmedi. Üstteki listeden ekleyebilirsin.")
                        } else {
                            selectedProducts.forEach { product ->
                                val item = selectedPlanProducts.firstOrNull { it.productId == product.id } ?: return@forEach
                                SupplementPlanEditorCard(
                                    product = product,
                                    categoryName = categories.firstOrNull { it.id == product.categoryId }?.name.orEmpty(),
                                    item = item,
                                    onRemove = { addOrRemoveProduct(product, true) },
                                    onSave = { updated -> scope.launch { repo.updateDietPlanProduct(updated) } }
                                )
                            }
                        }
                    }
                }
            }
            if (stockAlerts.isNotEmpty()) {
                item {
                    InventoryAlertPanel(stockAlerts)
                }
                item {
                    StockReminderActionPanel(
                        alerts = stockAlerts.filter { it.level == ReferenceLevel.HIGH },
                        onCreateReminder = { createStockReminder(it) }
                    )
                }
            }
            item {
                ElevatedCard {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Takviye kayıt özeti", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text(planText)
                    }
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = { shareText(context, planText, p, false) }, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Default.Share, null); Spacer(Modifier.size(6.dp)); Text("Paylaş")
                    }
                    Button(onClick = { shareText(context, planText, p, true) }, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Default.Share, null); Spacer(Modifier.size(6.dp)); Text("WhatsApp")
                    }
                }
            }
            item {
                OutlinedButton(onClick = {
                    scope.launch {
                        val measurementSnapshots = listOf(
                            "İlk Kayıt" to measurements.lastOrNull(),
                            "Önceki Kayıt" to measurements.getOrNull(1),
                            "Son Kayıt" to measurements.firstOrNull()
                        )
                        val planSnapshots = measurementSnapshots.mapNotNull { (label, measurement) ->
                            val linkedPlan = dietPlans.firstOrNull { it.linkedMeasurementId == measurement?.id } ?: return@mapNotNull null
                            label to repo.getDietPlanProductsNow(linkedPlan.id)
                        }.associate { (label, items) ->
                            label to items.mapNotNull { item ->
                                val product = products.firstOrNull { it.id == item.productId } ?: return@mapNotNull null
                                formatSupplementLine(product, item)
                            }
                        }
                        val pdf = createDietPdf(
                            context = context,
                            patient = p,
                            measurements = measurements,
                            supplementSnapshots = planSnapshots,
                            goal = goal,
                            notes = notes,
                            trackingStatus = trackingStatus,
                            planQuality = planQuality,
                            stockAlerts = stockAlerts,
                            nutritionActions = nutritionActions,
                            planActions = planActions,
                            comparisonInsights = planComparisonInsights,
                            complianceLogs = complianceLogs,
                            decisionLogs = decisionLogs
                        )
                        shareFile(context, pdf, p, "application/pdf")
                    }
                }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.PictureAsPdf, null); Spacer(Modifier.size(6.dp)); Text("Takviye PDF Oluştur ve Paylaş")
                }
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}

@Composable
private fun AnalysisBadge(label: String, value: String) {
    Surface(shape = MaterialTheme.shapes.large, color = MaterialTheme.colorScheme.primaryContainer) {
        Column(Modifier.padding(horizontal = 14.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(label, style = MaterialTheme.typography.labelMedium, color = Color(0xFFC9D7E3))
            Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun AppointmentPlanIntegrationPanel(
    status: TrackingStatus,
    latest: MeasurementEntity?,
    previous: MeasurementEntity?,
    plan: com.example.bodytracker.data.DietPlanEntity?,
    productCount: Int,
    stockAlerts: List<StockAlert>
) {
    val statusColor = when (status.level) {
        ReferenceLevel.HIGH -> Color(0xFFFFEBEE)
        ReferenceLevel.LOW -> Color(0xFFFFF8E1)
        ReferenceLevel.INFO -> Color(0xFFE3F2FD)
        ReferenceLevel.NORMAL -> Color(0xFFE8F5E9)
    }
    ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = Color(0xFFF8FAFC), contentColor = Color(0xFF0F172A))) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Randevu + Plan Özeti", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color(0xFF14532D))
            Surface(shape = MaterialTheme.shapes.medium, color = statusColor) {
                Column(Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text(status.label, fontWeight = FontWeight.Bold)
                    Text(status.detail, style = MaterialTheme.typography.bodySmall, color = Color(0xFF334155))
                }
            }
            val deltaText = if (latest != null && previous != null) {
                "Kilo ${(latest.weightKg - previous.weightKg).oneDecimal()} kg, yağ ${(latest.bodyFatPercent - previous.bodyFatPercent).oneDecimal()}%, sıvı ${(latest.bodyWaterPercent - previous.bodyWaterPercent).oneDecimal()}%"
            } else {
                "Ölçüm farkı için en az iki kayıt gerekli"
            }
            Text("Son ölçüm farkı: $deltaText", style = MaterialTheme.typography.bodySmall, color = Color(0xFF334155))
            Text(
                "Son plan: ${plan?.title ?: "Plan yok"} • $productCount ürün",
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.SemiBold,
                color = Color(0xFF14532D)
            )
            if (stockAlerts.isNotEmpty()) {
                stockAlerts.take(3).forEach { alert ->
                    Surface(shape = MaterialTheme.shapes.medium, color = if (alert.level == ReferenceLevel.HIGH) Color(0xFFFFEBEE) else Color(0xFFFFF8E1)) {
                        Text(alert.title, Modifier.fillMaxWidth().padding(9.dp), style = MaterialTheme.typography.bodySmall, color = Color(0xFF7F1D1D), fontWeight = FontWeight.SemiBold)
                    }
                }
            } else {
                Text("Kritik stok uyarısı yok veya stok bilgisi henüz girilmedi.", style = MaterialTheme.typography.bodySmall, color = Color(0xFF64748B))
            }
        }
    }
}

private fun suggestApplicationMethod(product: com.example.bodytracker.data.ProductEntity, categoryName: String): String = when {
    product.name.contains("creme", true) || product.name.contains("lotion", true) || product.name.contains("gelly", true) || categoryName.contains("Cilt", true) -> "Dış deriye"
    product.name.contains("shampoo", true) || product.name.contains("conditioner", true) || categoryName.contains("Saç", true) -> "Saça"
    product.name.contains("tooth", true) -> "Ağız içi"
    product.name.contains("spray", true) -> "Sprey"
    product.name.contains("gummy", true) -> "Çiğneme"
    else -> "Ağızdan"
}

private fun suggestUsagePattern(product: com.example.bodytracker.data.ProductEntity): String = when {
    product.timing.contains("sabah", true) && product.timing.contains("akşam", true) -> "1x2"
    product.defaultDose.contains("2", true) -> "2x2"
    else -> "1x2"
}

private fun suggestQuantityValue(product: com.example.bodytracker.data.ProductEntity): String = when {
    product.defaultDose.contains("30") -> "30"
    product.defaultDose.contains("2") -> "2"
    else -> "1"
}

private fun suggestQuantityUnit(product: com.example.bodytracker.data.ProductEntity): String = when {
    product.defaultDose.contains("ml", true) -> "ml"
    product.defaultDose.contains("tablet", true) -> "tablet"
    product.defaultDose.contains("kaps", true) -> "kapsül"
    product.name.contains("tablet", true) -> "tablet"
    product.name.contains("gummy", true) -> "adet"
    product.name.contains("caps", true) || product.name.contains("omega", true) || product.name.contains("pro b", true) -> "kapsül"
    product.name.contains("aloe vera gel", true) || product.name.contains("berry nectar", true) || product.name.contains("freedom", true) || product.name.contains("mango", true) || product.name.contains("peaches", true) -> "ml"
    product.name.contains("shampoo", true) || product.name.contains("conditioner", true) || product.name.contains("body wash", true) || product.name.contains("liquid soap", true) -> "ml"
    product.name.contains("toothgel", true) || product.name.contains("creme", true) || product.name.contains("cream", true) || product.name.contains("lotion", true) || product.name.contains("gelly", true) -> "ml"
    product.name.contains("gel", true) || product.name.contains("creme", true) || product.name.contains("lotion", true) -> "ince tabaka"
    else -> "adet"
}

private fun suggestPackageSize(product: com.example.bodytracker.data.ProductEntity): String = when {
    product.name.contains("aloe vera gel", true) ||
        product.name.contains("berry nectar", true) ||
        product.name.contains("bits n' peaches", true) ||
        product.name.contains("aloe mango", true) ||
        product.name.contains("forever freedom", true) -> "1000"
    product.name.contains("tea", true) -> "25"
    product.name.contains("fiber", true) -> "30"
    product.name.contains("lite ultra", true) -> "15"
    product.name.contains("argi", true) -> "30"
    product.name.contains("gummy", true) -> "60"
    product.name.contains("daily", true) ||
        product.name.contains("active pro b", true) ||
        product.name.contains("calcium", true) ||
        product.name.contains("omega", true) ||
        product.name.contains("nature-min", true) ||
        product.name.contains("ivision", true) ||
        product.name.contains("b12", true) ||
        product.name.contains("lycium", true) ||
        product.name.contains("vitolize", true) ||
        product.name.contains("garlic", true) ||
        product.name.contains("garcinia", true) ||
        product.name.contains("lean", true) ||
        product.name.contains("therm", true) ||
        product.name.contains("royal jelly", true) ||
        product.name.contains("bee pollen", true) ||
        product.name.contains("bee propolis", true) ||
        product.name.contains("active ha", true) ||
        product.name.contains("q10", true) -> "60"
    product.name.contains("absorbent", true) -> "100"
    product.name.contains("first", true) -> "473"
    product.name.contains("toothgel", true) -> "130"
    product.name.contains("shampoo", true) || product.name.contains("conditioner", true) || product.name.contains("body wash", true) || product.name.contains("liquid soap", true) -> "296"
    product.name.contains("aloe lips", true) -> "4.25"
    product.name.contains("deodorant", true) || product.name.contains("shield", true) -> "92"
    product.name.contains("cream", true) || product.name.contains("creme", true) || product.name.contains("lotion", true) || product.name.contains("gelly", true) -> "118"
    else -> "60"
}

private fun suggestDailyUsage(usagePattern: String, quantityValue: String): String {
    val amount = quantityValue.replace(",", ".").toDoubleOrNull() ?: 1.0
    val timesPerDay = when (usagePattern) {
        "1x1" -> 1.0
        "1x2" -> 2.0
        "2x1" -> 1.0
        "2x2" -> 2.0
        else -> 1.0
    }
    val unitsPerUse = when (usagePattern) {
        "2x1", "2x2" -> 2.0
        else -> amount
    }
    val daily = (unitsPerUse * timesPerDay).coerceAtLeast(0.0)
    return if (daily % 1.0 == 0.0) daily.toInt().toString() else daily.oneDecimal()
}

private fun String.filterStockNumber(): String =
    filter { it.isDigit() || it == ',' || it == '.' }.take(8)

private data class StockProjection(
    val totalStock: Double,
    val dailyUsage: Double,
    val days: Int?,
    val unit: String
)

private fun stockProjection(item: com.example.bodytracker.data.DietPlanProductEntity): StockProjection {
    val packageCount = item.packageCount.replace(",", ".").toDoubleOrNull() ?: 0.0
    val packageSize = item.packageSize.replace(",", ".").toDoubleOrNull() ?: 0.0
    val dailyUsage = item.dailyUsage.replace(",", ".").toDoubleOrNull()
        ?: suggestDailyUsage(item.usagePattern, item.quantityValue).replace(",", ".").toDoubleOrNull()
        ?: 0.0
    val total = packageCount * packageSize
    val days = if (total > 0.0 && dailyUsage > 0.0) kotlin.math.floor(total / dailyUsage).toInt() else null
    return StockProjection(totalStock = total, dailyUsage = dailyUsage, days = days, unit = item.packageUnit.ifBlank { item.quantityUnit })
}

private data class StockAlert(
    val title: String,
    val detail: String,
    val level: ReferenceLevel
)

private fun buildStockAlert(
    product: com.example.bodytracker.data.ProductEntity,
    item: com.example.bodytracker.data.DietPlanProductEntity
): StockAlert? {
    val projection = stockProjection(item)
    val missingStock = item.packageCount.isBlank() || item.packageSize.isBlank() || projection.dailyUsage <= 0.0
    return when {
        missingStock -> StockAlert(
            title = "${product.name}: stok bilgisi eksik",
            detail = "Kutu sayısı, kutu içi miktar ve günlük tüketim girilirse bitiş tarihi hesaplanır.",
            level = ReferenceLevel.INFO
        )
        projection.days != null && projection.days <= 7 -> StockAlert(
            title = "${product.name}: bitmek üzere",
            detail = "Yaklaşık ${projection.days} gün kaldı. Toplam ${projection.totalStock.oneDecimal()} ${projection.unit}, günlük ${projection.dailyUsage.oneDecimal()} tüketim.",
            level = ReferenceLevel.HIGH
        )
        projection.days != null && projection.days <= 14 -> StockAlert(
            title = "${product.name}: stok azaldı",
            detail = "Yaklaşık ${projection.days} gün kaldı. Yenileme planı yapılabilir.",
            level = ReferenceLevel.LOW
        )
        else -> null
    }
}

private data class ProductRecommendation(
    val product: com.example.bodytracker.data.ProductEntity,
    val score: Int,
    val reason: String,
    val warning: String,
    val tags: List<String>
)

private data class PlanAction(
    val title: String,
    val detail: String,
    val level: ReferenceLevel,
    val category: String = "Takip",
    val metric: String = "",
    val productFocus: String = "",
    val followUp: String = "",
    val priority: Int = 3
)

private data class NutritionAction(
    val title: String,
    val detail: String,
    val examples: List<String>,
    val level: ReferenceLevel
)

private data class PlanQuality(
    val score: Int,
    val missing: List<String>,
    val strengths: List<String>
)

private data class TrackingStatus(
    val label: String,
    val detail: String,
    val level: ReferenceLevel
)

private data class PlanHistoryInsight(
    val title: String,
    val detail: String,
    val level: ReferenceLevel
)

private data class PlanComparisonInsight(
    val title: String,
    val detail: String,
    val level: ReferenceLevel
)

private fun buildPlanComparisonInsights(
    currentItems: List<com.example.bodytracker.data.DietPlanProductEntity>,
    previousItems: List<com.example.bodytracker.data.DietPlanProductEntity>,
    products: List<com.example.bodytracker.data.ProductEntity>,
    currentMeasurement: MeasurementEntity?,
    previousMeasurement: MeasurementEntity?
): List<PlanComparisonInsight> {
    if (currentMeasurement == null || previousMeasurement == null) {
        return listOf(
            PlanComparisonInsight(
                title = "Önceki plan kıyası için veri bekleniyor",
                detail = "En az iki ölçüm ve önceki ölçüme bağlı bir plan olduğunda sistem iyi/kötü değişimi kıyaslar.",
                level = ReferenceLevel.INFO
            )
        )
    }
    if (previousItems.isEmpty()) {
        return listOf(
            PlanComparisonInsight(
                title = "Önceki ölçümde plan yok",
                detail = "Bu plan ilk karşılaştırılabilir ürün planı olacak. Bir sonraki ölçümde ürün etkisi değil, plan uyumu ve trend kıyası yapılabilir.",
                level = ReferenceLevel.INFO
            )
        )
    }

    val currentIds = currentItems.map { it.productId }.toSet()
    val previousIds = previousItems.map { it.productId }.toSet()
    val keptIds = currentIds intersect previousIds
    val addedIds = currentIds - previousIds
    val removedIds = previousIds - currentIds
    val fatDelta = currentMeasurement.bodyFatPercent - previousMeasurement.bodyFatPercent
    val weightDelta = currentMeasurement.weightKg - previousMeasurement.weightKg
    val waterDelta = currentMeasurement.bodyWaterPercent - previousMeasurement.bodyWaterPercent
    val muscleDelta = currentMeasurement.muscle - previousMeasurement.muscle

    fun names(ids: Set<Long>): String = ids.take(3).mapNotNull { id -> products.firstOrNull { it.id == id }?.name }.joinToString(", ")
    fun hasCurrent(values: List<String>): Boolean {
        val selectedText = currentIds.mapNotNull { id -> products.firstOrNull { it.id == id } }
            .joinToString(" ") { "${it.name} ${it.description}" }
            .lowercase()
        return values.any { selectedText.contains(it, true) }
    }

    val insights = mutableListOf<PlanComparisonInsight>()
    insights += PlanComparisonInsight(
        title = "Plan değişim özeti",
        detail = "${keptIds.size} ürün sürdü, ${addedIds.size} ürün eklendi, ${removedIds.size} ürün çıkarıldı.${addedIds.takeIf { it.isNotEmpty() }?.let { " Eklenen: ${names(it)}." } ?: ""}",
        level = ReferenceLevel.INFO
    )
    if ((fatDelta > 1.0 || weightDelta > 1.5) && keptIds.size >= previousIds.size.coerceAtLeast(1) / 2) {
        insights += PlanComparisonInsight(
            title = "Önceki plan yeterli görünmüyor",
            detail = "Yağ/kilo artışı var ve ürünlerin önemli kısmı aynı kalmış. Aynı planı sürdürmek yerine öğün, aktivite, kullanım uyumu ve ürün önceliği yeniden düzenlenmeli.",
            level = ReferenceLevel.HIGH
        )
    }
    if (fatDelta <= -0.5 || weightDelta <= -1.0) {
        insights += PlanComparisonInsight(
            title = "Önceki plan olumlu trend vermiş",
            detail = "Yağ veya kilo düşüşü var. İyi giden ürün/kullanım düzeni korunup stok ve uyum takibi yapılabilir.",
            level = ReferenceLevel.NORMAL
        )
    }
    if (waterDelta < -2.0 && !hasCurrent(listOf("aloe", "berry", "freedom", "mango", "peaches"))) {
        insights += PlanComparisonInsight(
            title = "Sıvı trendi bozulmuş",
            detail = "Sıvı oranı düşmüş; mevcut planda sıvı/içecek odağı zayıf görünüyor. Su planı ve ilgili ürün grubu önceliklendirilmeli.",
            level = ReferenceLevel.LOW
        )
    }
    if (muscleDelta < -1.0 && !hasCurrent(listOf("lite", "argi", "daily", "nature", "calcium", "omega"))) {
        insights += PlanComparisonInsight(
            title = "Kas trendi zayıflıyor",
            detail = "Kas değeri önceki ölçüme göre düşmüş. Öğün/protein, aktivite ve günlük beslenme destekleri tekrar değerlendirilmelidir.",
            level = ReferenceLevel.LOW
        )
    }
    if (removedIds.isNotEmpty() && (fatDelta > 0.5 || waterDelta < -1.0 || muscleDelta < -0.5)) {
        insights += PlanComparisonInsight(
            title = "Çıkarılan ürünleri kontrol et",
            detail = "Bazı ürünler çıkarıldıktan sonra trend kötüleşmiş olabilir. Çıkarılanlar: ${names(removedIds)}. Nedeni notlara eklenmeli.",
            level = ReferenceLevel.INFO
        )
    }
    return insights.take(6)
}

private fun buildPlanQualityScore(
    measurement: MeasurementEntity?,
    selectedItems: List<DietPlanProductEntity>,
    stockAlerts: List<StockAlert>,
    nutritionActions: List<NutritionAction>,
    planActions: List<PlanAction>,
    complianceLogs: List<DailyComplianceEntity>,
    notes: String
): PlanQuality {
    var score = 0
    val missing = mutableListOf<String>()
    val strengths = mutableListOf<String>()
    if (measurement != null) {
        score += 15
        strengths += "Ölçüm bağlı"
    } else missing += "Ölçüm seçilmedi"
    if (selectedItems.isNotEmpty()) {
        score += 15
        strengths += "${selectedItems.size} ürün seçili"
    } else missing += "Ürün planı yok"
    if (selectedItems.any { it.packageCount.isNotBlank() && it.packageSize.isNotBlank() && it.dailyUsage.isNotBlank() }) {
        score += 15
        strengths += "Stok takibi var"
    } else missing += "Stok/kutu bilgisi eksik"
    if (nutritionActions.isNotEmpty()) {
        score += 15
        strengths += "Beslenme aksiyonu var"
    } else missing += "Beslenme aksiyonu yok"
    if (planActions.isNotEmpty()) {
        score += 15
        strengths += "Akıllı aksiyon var"
    } else missing += "Plan aksiyonu yok"
    if (complianceLogs.isNotEmpty()) {
        score += 15
        strengths += "Uyum takibi başladı"
    } else missing += "Günlük uyum takibi yok"
    if (notes.isNotBlank()) {
        score += 10
        strengths += "Uzman notu var"
    } else missing += "Uzman notu boş"
    if (stockAlerts.any { it.level == ReferenceLevel.HIGH }) {
        score -= 10
        missing += "Kritik stok uyarısı var"
    }
    return PlanQuality(score = score.coerceIn(0, 100), missing = missing.distinct().take(5), strengths = strengths.distinct().take(5))
}

private fun buildTrackingStatus(
    measurement: MeasurementEntity?,
    previous: MeasurementEntity?,
    stockAlerts: List<StockAlert>,
    complianceLogs: List<DailyComplianceEntity>,
    selectedItems: List<DietPlanProductEntity>
): TrackingStatus {
    val criticalStock = stockAlerts.any { it.level == ReferenceLevel.HIGH }
    val fatDelta = if (measurement != null && previous != null) measurement.bodyFatPercent - previous.bodyFatPercent else null
    val weightDelta = if (measurement != null && previous != null) measurement.weightKg - previous.weightKg else null
    val avgCompliance = complianceLogs.take(7).takeIf { it.isNotEmpty() }?.map { compliancePercent(it) }?.average() ?: -1.0
    return when {
        measurement == null -> TrackingStatus("Ölçüm bekliyor", "Plan zekası için ölçüm girilmeli.", ReferenceLevel.INFO)
        selectedItems.isEmpty() -> TrackingStatus("Plan eksik", "Seçili ölçüme bağlı ürün/takviye planı yok.", ReferenceLevel.LOW)
        criticalStock -> TrackingStatus("Stok kritik", "Bir veya daha fazla ürün bitmek üzere.", ReferenceLevel.HIGH)
        fatDelta != null && fatDelta > 1.0 -> TrackingStatus("Plan değişmeli", "Yağ trendi yükselmiş; ürün, öğün ve aktivite önceliği değişmeli.", ReferenceLevel.HIGH)
        weightDelta != null && weightDelta > 1.5 -> TrackingStatus("Riskli trend", "Kilo trendi yükselmiş; plan sıkılaştırılmalı.", ReferenceLevel.HIGH)
        avgCompliance >= 0.0 && avgCompliance < 60.0 -> TrackingStatus("Uyum düşük", "Son takiplerde uyum yüzdesi düşük.", ReferenceLevel.LOW)
        avgCompliance >= 80.0 -> TrackingStatus("İyi gidiyor", "Uyum yüksek ve kritik uyarı yok.", ReferenceLevel.NORMAL)
        else -> TrackingStatus("Takipte", "Plan uygulanıyor; sonraki ölçüm ve uyum verisi izlenmeli.", ReferenceLevel.INFO)
    }
}

private fun compliancePercent(item: DailyComplianceEntity): Int {
    val checks = listOf(item.productsTaken, item.waterDone, item.vegetablesDone, item.proteinDone, item.activityDone, item.sleepDone)
    return ((checks.count { it } / checks.size.toDouble()) * 100.0).toInt()
}

private fun buildPlanHistoryInsights(
    measurements: List<MeasurementEntity>,
    dietPlans: List<com.example.bodytracker.data.DietPlanEntity>,
    currentPlan: com.example.bodytracker.data.DietPlanEntity?,
    selectedMeasurement: MeasurementEntity?
): List<PlanHistoryInsight> {
    val insights = mutableListOf<PlanHistoryInsight>()
    insights += PlanHistoryInsight(
        title = "Ölçüm geçmişi",
        detail = "${measurements.size} ölçüm kaydı var. Seçili plan ${selectedMeasurement?.let { formatDate(it.dateMillis) } ?: "genel"} ölçümüne bağlı çalışıyor.",
        level = if (measurements.size >= 2) ReferenceLevel.NORMAL else ReferenceLevel.INFO
    )
    insights += PlanHistoryInsight(
        title = "Plan geçmişi",
        detail = "${dietPlans.size} takviye/beslenme planı var. ${if (currentPlan != null) "Bu ölçüme bağlı plan düzenleniyor." else "Bu ölçüm için yeni plan oluşturulabilir."}",
        level = if (currentPlan != null) ReferenceLevel.NORMAL else ReferenceLevel.LOW
    )
    val latest = measurements.firstOrNull()
    val previous = measurements.getOrNull(1)
    if (latest != null && previous != null) {
        val fatDelta = latest.bodyFatPercent - previous.bodyFatPercent
        val weightDelta = latest.weightKg - previous.weightKg
        val waterDelta = latest.bodyWaterPercent - previous.bodyWaterPercent
        insights += PlanHistoryInsight(
            title = "Son ölçüm farkı",
            detail = "Kilo ${weightDelta.oneDecimal()} kg, yağ ${fatDelta.oneDecimal()}%, sıvı ${waterDelta.oneDecimal()}%. Akıllı öneriler seçili ölçüm ve bu trendle birlikte değerlendirilir.",
            level = when {
                fatDelta > 1.0 || weightDelta > 1.5 -> ReferenceLevel.HIGH
                waterDelta < -2.0 -> ReferenceLevel.LOW
                else -> ReferenceLevel.INFO
            }
        )
    }
    return insights
}

private fun buildNutritionActions(patient: PatientEntity, latest: MeasurementEntity?, goal: String): List<NutritionAction> {
    if (latest == null) {
        return listOf(
            NutritionAction(
                title = "Temel tabak modeli",
                detail = "İlk ölçüm girilene kadar basit ve sürdürülebilir tabak düzeni kullanılır.",
                examples = listOf("Her ana öğünde sebze", "Avuç içi kadar protein", "Günlük su takibi"),
                level = ReferenceLevel.INFO
            )
        )
    }
    val targetFat = patient.targetBodyFatPercent.takeIf { it > 0.0 } ?: 27.0
    val actions = mutableListOf<NutritionAction>()

    if (latest.bodyFatPercent > targetFat || latest.bmi > 24.0 || goal.contains("kilo", true)) {
        actions += NutritionAction(
            title = "Yağ/kilo kontrol tabağı",
            detail = "Ana öğünlerde sebze hacmi artırılıp protein sabitlenir; şekerli içecek ve kontrolsüz atıştırma azaltılır.",
            examples = listOf("Bol salata veya pişmiş sebze", "Izgara et/tavuk/balık veya yumurta", "Yoğurt/kefir", "Tam tahıl küçük porsiyon"),
            level = ReferenceLevel.HIGH
        )
    }
    if (latest.bodyWaterPercent in 1.0..52.0) {
        actions += NutritionAction(
            title = "Sıvı planı",
            detail = "Sıvı oranı düşükse su hedefi görünür yazılmalı ve gün içine bölünmelidir.",
            examples = listOf("Sabah 1 bardak su", "Öğün aralarında su", "Çay/kahve yerine su takibi", "Günlük 2-2.5 litre hedef"),
            level = ReferenceLevel.LOW
        )
    }
    if (latest.muscle < 45.0 || kotlin.math.abs(latest.weightKg - latest.muscle) >= 15.0) {
        actions += NutritionAction(
            title = "Kas koruma öğünü",
            detail = "Kas/KPS odağında her ana öğünde protein kaynağı ve düzenli aktivite birlikte planlanır.",
            examples = listOf("Yumurta", "Et/tavuk/balık", "Baklagil", "Yoğurt", "Peynir", "Antrenman sonrası dengeli öğün"),
            level = ReferenceLevel.INFO
        )
    }
    if (latest.visceralFat >= 10.0 || latest.waistCm >= 90.0) {
        actions += NutritionAction(
            title = "İç yağ / bel çevresi odağı",
            detail = "Bel ve iç yağ yüksekse akşam geç atıştırma, rafine karbonhidrat ve porsiyon kontrolü özellikle takip edilir.",
            examples = listOf("Akşam sebze + protein", "Tatlı/hamur işi azalt", "Ara öğünleri planla", "Haftalık bel ölçümü"),
            level = ReferenceLevel.HIGH
        )
    }
    if (latest.physicalActivity in 0.1..3.9) {
        actions += NutritionAction(
            title = "Aktiviteye hazırlık",
            detail = "Aktivite düşükse önce sürdürülebilir yürüyüş ve basit öğün düzeni hedeflenir.",
            examples = listOf("Yürüyüş öncesi hafif öğün", "Aç kalmadan plan", "Protein + sebze", "Su takibi"),
            level = ReferenceLevel.LOW
        )
    }
    if (patient.allergies.isNotBlank()) {
        actions += NutritionAction(
            title = "Alerji/hassasiyet kontrolü",
            detail = "Beslenme ve ürün planında alerji notları açıkça kontrol edilmelidir.",
            examples = listOf("Alerjen içerik kontrolü", "Arı ürünü/koku/parfüm uyarısı", "Yeni ürünleri tek tek takip"),
            level = ReferenceLevel.HIGH
        )
    }
    if (actions.isEmpty()) {
        actions += NutritionAction(
            title = "Koruma beslenmesi",
            detail = "Değerler dengeli görünüyorsa sürdürülebilir öğün ve su düzeni korunur.",
            examples = listOf("Sebze + protein", "Düzenli su", "Kontrollü ara öğün", "Aylık ölçüm"),
            level = ReferenceLevel.NORMAL
        )
    }
    return actions.take(6)
}

private fun buildPlanActions(patient: PatientEntity, latest: MeasurementEntity?, previous: MeasurementEntity? = null): List<PlanAction> {
    if (latest == null) {
        return listOf(
            PlanAction(
                title = "İlk ölçüm gerekli",
                detail = "Ürün, spor ve beslenme önerilerini netleştirmek için kilo, yağ, sıvı, kas, bel ve iç yağ ölçümü ekleyin.",
                level = ReferenceLevel.INFO
            )
        )
    }
    val age = patientAge(patient)
    val targetWeight = patient.targetWeightKg.takeIf { it > 0.0 } ?: idealWeight(patient.heightCm)
    val targetFat = patient.targetBodyFatPercent.takeIf { it > 0.0 } ?: 27.0
    val kps = kotlin.math.abs(latest.weightKg - latest.muscle)
    val fatDelta = previous?.let { latest.bodyFatPercent - it.bodyFatPercent }
    val weightDelta = previous?.let { latest.weightKg - it.weightKg }
    val waterDelta = previous?.let { latest.bodyWaterPercent - it.bodyWaterPercent }
    val actions = mutableListOf<PlanAction>()

    if (latest.bodyFatPercent > targetFat || latest.bmi > 24.0) {
        actions += PlanAction(
            title = "Yağ oranı / kilo odağı",
            detail = "Kilo kontrol ürünleri, lif/sindirim desteği, düzenli ölçüm ve haftalık aktivite hedefi birlikte planlanmalı. Hedef yağ: ≤ %${targetFat.oneDecimal()}, mevcut: %${latest.bodyFatPercent.oneDecimal()}${fatDelta?.let { ", önceki farka göre ${it.oneDecimal()}%" } ?: ""}.",
            level = ReferenceLevel.HIGH,
            category = "Kompozisyon",
            metric = "Yağ %${latest.bodyFatPercent.oneDecimal()} • VKİ ${latest.bmi.oneDecimal()}",
            productFocus = "Kilo kontrol, lif/sindirim, öğün destek ürünleri",
            followUp = "7-14 gün içinde kilo/yağ trend kontrolü",
            priority = 1
        )
    }
    if (latest.visceralFat >= 10.0 || latest.waistCm >= 90.0) {
        actions += PlanAction(
            title = "İç yağ ve bel çevresi takibi",
            detail = "Bel çevresi, iç yağ ve kilo aynı haftalık raporda izlenmeli. Yağ yakımı iddiası yerine ölçülebilir aktivite ve beslenme düzeni hedeflenmeli.",
            level = ReferenceLevel.HIGH,
            category = "Risk Takibi",
            metric = "İç yağ ${latest.visceralFat.oneDecimal()}${if (latest.waistCm > 0.0) " • Bel ${latest.waistCm.oneDecimal()} cm" else ""}",
            productFocus = "Kilo kontrol + aktivite planı ile birlikte değerlendir",
            followUp = "Haftalık bel çevresi ve iç yağ notu",
            priority = 1
        )
    }
    if (latest.bodyWaterPercent in 1.0..52.0) {
        actions += PlanAction(
            title = "Sıvı oranı düşük",
            detail = "Su planı görünür hale getirilmeli; içecek/aloe grubu ürünler seçilecekse günlük ml tüketimi ve stok takibiyle planlanmalı${waterDelta?.let { ". Önceki ölçüme göre sıvı farkı ${it.oneDecimal()}%" } ?: "."}",
            level = ReferenceLevel.LOW,
            category = "Sıvı",
            metric = "Sıvı %${latest.bodyWaterPercent.oneDecimal()}",
            productFocus = "Aloe/içecek grubu ve günlük su planı",
            followUp = "3-7 gün su tüketim takibi",
            priority = 2
        )
    }
    if (kps >= 15.0 || latest.muscle < 45.0) {
        actions += PlanAction(
            title = "Kas/KPS kompozisyon odağı",
            detail = "Kilo-kas farkı ve kas değeri takip edilmeli. Aktivite seviyesi, protein/öğün planı ve kas destekli ürün grubu birlikte değerlendirilir.",
            level = ReferenceLevel.INFO,
            category = "Kas",
            metric = "KPS ${kps.oneDecimal()} • Kas ${latest.muscle.oneDecimal()}",
            productFocus = "Öğün/protein odağı, mineral ve aktif yaşam ürünleri",
            followUp = "2-4 hafta kas ve KPS trendi",
            priority = 2
        )
    }
    if (latest.physicalActivity in 0.1..3.9) {
        actions += PlanAction(
            title = "Aktivite seviyesi düşük",
            detail = "Danışana haftalık yürüyüş/direnç egzersizi hedefi yazılmalı. Enerji ürünleri seçilse bile aktivite planı olmadan sonuç takibi eksik kalır.",
            level = ReferenceLevel.LOW,
            category = "Aktivite",
            metric = "Aktivite ${latest.physicalActivity.oneDecimal()}",
            productFocus = "Enerji-mineral grubu ancak aktivite hedefiyle birlikte",
            followUp = "Haftalık aktivite hedefi ve notu",
            priority = 2
        )
    }
    if (fatDelta != null && fatDelta > 1.0) {
        actions += PlanAction(
            title = "Yağ trendi yükseliyor",
            detail = "Seçili ölçüm önceki ölçüme göre yağ oranında artış gösteriyor. Plan sadece ürün eklemekle kalmamalı; öğün, su ve aktivite hedefleri de güncellenmeli.",
            level = ReferenceLevel.HIGH,
            category = "Trend",
            metric = "Yağ farkı +${fatDelta.oneDecimal()}%",
            productFocus = "Kilo kontrol + lif/sindirim grubu",
            followUp = "Bir sonraki ölçümde yağ trendi kontrolü",
            priority = 1
        )
    }
    if (weightDelta != null && weightDelta > 1.5) {
        actions += PlanAction(
            title = "Kilo trendi yükseliyor",
            detail = "Önceki ölçüme göre kilo artışı belirgin. Porsiyon, akşam öğünü ve aktivite notu plana eklenmeli.",
            level = ReferenceLevel.HIGH,
            category = "Trend",
            metric = "Kilo farkı +${weightDelta.oneDecimal()} kg",
            productFocus = "Kilo kontrol ve öğün destek ürünleri",
            followUp = "7-14 gün kilo kontrolü",
            priority = 1
        )
    }
    if (latest.metabolicAge > age + 5) {
        actions += PlanAction(
            title = "Metabolik yaş yüksek",
            detail = "Metabolik yaş gerçek yaştan yüksek. Kilo, iç yağ, sıvı ve aktivite trendleri birlikte izlenmeli.",
            level = ReferenceLevel.HIGH,
            category = "Metabolik",
            metric = "Met. yaş ${latest.metabolicAge} • Gerçek yaş $age",
            productFocus = "Kilo kontrol + aktivite + günlük beslenme desteği",
            followUp = "Aylık metabolik yaş karşılaştırması",
            priority = 1
        )
    }
    if (latest.bone in 0.1..2.4) {
        actions += PlanAction(
            title = "Kemik değeri düşük takipte",
            detail = "Kemik değeri düşük görünüyorsa kalsiyum/mineral grubu ve aktivite planı uzman değerlendirmesiyle düşünülmeli.",
            level = ReferenceLevel.LOW,
            category = "Mineral",
            metric = "Kemik ${latest.bone.oneDecimal()}",
            productFocus = "Kalsiyum/mineral grubu",
            followUp = "Aylık kemik ve aktivite takibi",
            priority = 3
        )
    }
    if (latest.weightKg <= targetWeight + 2.0 && latest.bodyFatPercent <= targetFat && latest.bodyWaterPercent >= 55.0) {
        actions += PlanAction(
            title = "Koruma ve süreklilik",
            detail = "Ana değerler hedefe yakın. Mevcut plan korunup stok, kullanım düzeni ve aylık ölçüm trendi takip edilebilir.",
            level = ReferenceLevel.NORMAL,
            category = "Koruma",
            metric = "Hedefe yakın",
            productFocus = "Mevcut ürün düzenini sürdür",
            followUp = "Aylık trend kontrolü",
            priority = 4
        )
    }
    if (patient.allergies.isNotBlank()) {
        actions += PlanAction(
            title = "Alerji notu var",
            detail = "Ürün seçerken arı ürünleri, koku/parfüm ve içerik hassasiyetleri ayrıca kontrol edilmeli.",
            level = ReferenceLevel.HIGH,
            category = "Güvenlik",
            metric = "Alerji notu",
            productFocus = "Arı ürünleri ve hassas içerikler uyarı ile seçilmeli",
            followUp = "Her ürün eklemede kontrol",
            priority = 1
        )
    }
    if (patient.medications.isNotBlank()) {
        actions += PlanAction(
            title = "İlaç kullanımı notu var",
            detail = "Takviye seçiminde etkileşim riski nedeniyle ürünler uyarı ile değerlendirilmelidir.",
            level = ReferenceLevel.HIGH,
            category = "Güvenlik",
            metric = "İlaç notu",
            productFocus = "Etkileşim riski olan ürünlerde uzman kontrolü",
            followUp = "Her plan güncellemesinde kontrol",
            priority = 1
        )
    }
    if (actions.isEmpty()) {
        actions += PlanAction(
            title = "Rutin takip",
            detail = "Belirgin kritik uyarı oluşmadı. Seçilen ürünlerin kullanım düzeni, stok durumu ve aylık ölçüm trendi izlenebilir.",
            level = ReferenceLevel.NORMAL,
            category = "Rutin",
            metric = "Kritik uyarı yok",
            productFocus = "Mevcut ürün düzeni",
            followUp = "Aylık ölçüm",
            priority = 4
        )
    }
    return actions.sortedWith(compareBy<PlanAction> { it.priority }.thenBy { it.category }).take(8)
}

private fun buildProductRecommendations(
    patient: PatientEntity,
    latest: MeasurementEntity?,
    products: List<com.example.bodytracker.data.ProductEntity>,
    selectedProductIds: Set<Long>,
    goal: String
): List<ProductRecommendation> {
    val age = patientAge(patient)
    val bmi = latest?.bmi ?: 0.0
    val fat = latest?.bodyFatPercent ?: 0.0
    val water = latest?.bodyWaterPercent ?: 0.0
    val visceral = latest?.visceralFat ?: 0.0
    val activity = latest?.physicalActivity ?: 0.0
    val kps = latest?.let { kotlin.math.abs(it.weightKg - it.muscle) } ?: 0.0
    val healthText = listOf(patient.allergies, patient.medications, patient.medicalHistory, patient.notes).joinToString(" ").lowercase()
    val goalText = goal.lowercase()

    fun containsAny(source: String, values: List<String>): Boolean = values.any { source.contains(it, true) }

    return products
        .filter { it.id !in selectedProductIds }
        .mapNotNull { product ->
            val text = listOf(product.name, product.description, product.usageNote, product.defaultDose, product.timing).joinToString(" ").lowercase()
            var score = 0
            val tags = mutableListOf<String>()
            val reasons = mutableListOf<String>()
            val warnings = mutableListOf<String>()

            val kiloTags = containsAny(text, listOf("garcinia", "lean", "therm", "sensatiable", "lite ultra", "fiber", "c9", "fit"))
            val aloeHydrationTags = containsAny(text, listOf("aloe vera gel", "berry nectar", "bits n", "freedom", "mango"))
            val digestionTags = containsAny(text, listOf("fiber", "active pro b", "tea", "aloeturm"))
            val energyTags = containsAny(text, listOf("argi", "b12", "daily", "nature-min", "bee pollen", "royal jelly"))
            val skinTags = containsAny(text, listOf("skin", "cilt", "sonya", "infinite", "logic", "collagen", "propolis creme", "gelly", "moisturizing", "hydrating", "firming"))
            val jointTags = containsAny(text, listOf("freedom", "msm", "active ha", "calcium", "omega", "marine collagen"))

            if (goalText.contains("kilo") && kiloTags) {
                score += 34
                tags += "Kilo kontrolü"
                reasons += "plan odağı kilo kontrolü"
            }
            if ((bmi > 24.0 || fat > 27.0 || visceral >= 6.0 || kps >= 15.0) && kiloTags) {
                score += 28
                tags += "Kompozisyon"
                reasons += "VKİ/yağ/iç yağ verileri kilo yönetimi takibi gerektiriyor"
            }
            if ((water in 1.0..52.0) && aloeHydrationTags) {
                score += 26
                tags += "Sıvı takibi"
                reasons += "sıvı oranı düşük görünüyor"
            }
            if (goalText.contains("sindirim") && digestionTags) {
                score += 30
                tags += "Sindirim"
                reasons += "plan odağı sindirim desteği"
            }
            if ((activity in 1.0..4.0 || age >= 45) && energyTags) {
                score += 22
                tags += "Enerji"
                reasons += "aktivite/yaş profili enerji-mineral takibini öne çıkarıyor"
            }
            if (goalText.contains("enerji") && energyTags) {
                score += 28
                tags += "Enerji"
                reasons += "plan odağı enerji"
            }
            if (goalText.contains("cilt") && skinTags) {
                score += 32
                tags += "Cilt"
                reasons += "plan odağı cilt ve saç"
            }
            if ((patient.gender.equals("Kadın", true) || age >= 40) && jointTags) {
                score += 14
                tags += "Eklem/kolajen"
                reasons += "yaş/cinsiyet profili eklem-kolajen takibini destekliyor"
            }
            if (product.code.isNotBlank()) score += 4
            if (product.imageUrl.isNotBlank()) score += 4

            if (healthText.contains("alerji") && containsAny(text, listOf("bee", "arı", "honey", "pollen", "royal jelly", "propolis"))) {
                score -= 35
                warnings += "Alerji notu var; arı ürünleri uzman kontrolü olmadan önerilmemeli."
            }
            if (healthText.contains("ilaç") && containsAny(text, listOf("garlic", "ginkgo", "therm", "argi"))) {
                score -= 18
                warnings += "İlaç kullanımı notu var; etkileşim açısından kontrol edilmeli."
            }
            if (healthText.contains("tansiyon") && containsAny(text, listOf("therm", "argi"))) {
                score -= 18
                warnings += "Tansiyon notu varsa uyarı ile değerlendirilmelidir."
            }

            if (score <= 0) return@mapNotNull null
            ProductRecommendation(
                product = product,
                score = score.coerceIn(0, 100),
                reason = reasons.distinct().take(2).joinToString("; ").ifBlank { "ürün profili plan odağı ile eşleşiyor" },
                warning = warnings.distinct().joinToString(" "),
                tags = tags.distinct().take(3)
            )
        }
        .sortedWith(compareByDescending<ProductRecommendation> { it.score }.thenBy { it.product.name })
        .take(8)
}

@Composable
private fun InventoryAlertPanel(alerts: List<StockAlert>) {
    ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = Color(0xFF102A24), contentColor = Color.White)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Stok ve Kullanım Uyarıları", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color(0xFF39E58C))
            alerts.forEach { alert ->
                Surface(
                    shape = MaterialTheme.shapes.medium,
                    color = when (alert.level) {
                        ReferenceLevel.HIGH -> Color(0xFF4A2020)
                        ReferenceLevel.LOW -> Color(0xFF3A2F16)
                        ReferenceLevel.INFO -> Color(0xFF152A44)
                        ReferenceLevel.NORMAL -> Color(0xFF123123)
                    }
                ) {
                    Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text(alert.title, fontWeight = FontWeight.Bold)
                        Text(alert.detail, color = Color(0xFFC9D7E3), style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}

@Composable
private fun StockReminderActionPanel(
    alerts: List<StockAlert>,
    onCreateReminder: (StockAlert) -> Unit
) {
    ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = Color(0xFFFFF8E1), contentColor = Color(0xFF1F2937))) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Stok Bildirimi", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            if (alerts.isEmpty()) {
                Text("7 gün altına düşen kritik stok yok. Stok bilgisi eksik ürünleri tamamladığında sistem tekrar hesaplar.")
            } else {
                alerts.take(3).forEach { alert ->
                    Surface(shape = MaterialTheme.shapes.medium, color = Color.White) {
                        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(alert.title, fontWeight = FontWeight.Bold, color = Color(0xFF7F1D1D))
                            Text(alert.detail, style = MaterialTheme.typography.bodySmall, color = Color(0xFF334155))
                            OutlinedButton(onClick = { onCreateReminder(alert) }, modifier = Modifier.fillMaxWidth()) {
                                Icon(Icons.Default.Alarm, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.size(6.dp))
                                Text("Stok randevusu / bildirimi kur")
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SmartProductRecommendationPanel(
    recommendations: List<ProductRecommendation>,
    onAdd: (com.example.bodytracker.data.ProductEntity) -> Unit
) {
    ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = Color(0xFF0B1828), contentColor = Color.White)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Akıllı Ürün Eşleşmesi", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color(0xFF39E58C))
            Text(
                "Bu bölüm garanti etki değil; ölçüm, hedef, ürün etiketi, alerji ve ilaç notlarına göre uygunluk skorudur.",
                color = Color(0xFFC9D7E3),
                style = MaterialTheme.typography.bodySmall
            )
            if (recommendations.isEmpty()) {
                Surface(shape = MaterialTheme.shapes.medium, color = Color(0xFF132238)) {
                    Text(
                        "Öneri üretmek için ölçüm, hedef veya danışan sağlık notlarını tamamlayın.",
                        modifier = Modifier.fillMaxWidth().padding(12.dp),
                        color = Color(0xFFC9D7E3)
                    )
                }
            } else {
                recommendations.take(5).forEach { recommendation ->
                    SmartProductRecommendationCard(recommendation = recommendation, onAdd = { onAdd(recommendation.product) })
                }
            }
        }
    }
}

@Composable
private fun SmartPlanActionPanel(actions: List<PlanAction>) {
    ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = Color(0xFF102A24), contentColor = Color.White)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Akıllı Plan Aksiyonları", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color(0xFF39E58C))
            Text(
                "Yağ, sıvı, kas, aktivite, iç yağ, bel ve güvenlik notlarına göre danışman kontrol listesi.",
                color = Color(0xFFC9D7E3),
                style = MaterialTheme.typography.bodySmall
            )
            actions.forEach { action ->
                Surface(
                    shape = MaterialTheme.shapes.large,
                    color = when (action.level) {
                        ReferenceLevel.HIGH -> Color(0xFF4A2020)
                        ReferenceLevel.LOW -> Color(0xFF3A2F16)
                        ReferenceLevel.INFO -> Color(0xFF152A44)
                        ReferenceLevel.NORMAL -> Color(0xFF123123)
                    }
                ) {
                    Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Top) {
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                Text(action.title, fontWeight = FontWeight.Bold)
                                if (action.metric.isNotBlank()) {
                                    Text(action.metric, color = Color(0xFFEAF2F8), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                                }
                            }
                            Surface(shape = MaterialTheme.shapes.medium, color = Color.White.copy(alpha = 0.12f)) {
                                Text("P${action.priority}", Modifier.padding(horizontal = 8.dp, vertical = 5.dp), fontWeight = FontWeight.Bold, color = Color.White)
                            }
                        }
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(listOf(action.category, action.followUp).filter { it.isNotBlank() }) { chip ->
                                Surface(shape = MaterialTheme.shapes.medium, color = Color.White.copy(alpha = 0.10f)) {
                                    Text(chip, Modifier.padding(horizontal = 8.dp, vertical = 4.dp), color = Color.White, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                        Text(action.detail, color = Color(0xFFC9D7E3), style = MaterialTheme.typography.bodySmall)
                        if (action.productFocus.isNotBlank()) {
                            Surface(shape = MaterialTheme.shapes.medium, color = Color(0xFF0B1828)) {
                                Text(
                                    "Ürün odağı: ${action.productFocus}",
                                    modifier = Modifier.fillMaxWidth().padding(10.dp),
                                    color = Color(0xFFB9F6CA),
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PlanHistoryInsightPanel(insights: List<PlanHistoryInsight>) {
    ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = Color(0xFF0F1B2B), contentColor = Color.White)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Ölçüm ve Plan Geçmişi", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color(0xFF39E58C))
            insights.forEach { insight ->
                Surface(
                    shape = MaterialTheme.shapes.medium,
                    color = when (insight.level) {
                        ReferenceLevel.HIGH -> Color(0xFF4A2020)
                        ReferenceLevel.LOW -> Color(0xFF3A2F16)
                        ReferenceLevel.INFO -> Color(0xFF152A44)
                        ReferenceLevel.NORMAL -> Color(0xFF123123)
                    }
                ) {
                    Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text(insight.title, fontWeight = FontWeight.Bold)
                        Text(insight.detail, color = Color(0xFFC9D7E3), style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}

@Composable
private fun PreviousPlanComparisonPanel(insights: List<PlanComparisonInsight>) {
    ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = Color(0xFF111827), contentColor = Color.White)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Önceki Plana Göre Değerlendirme", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color(0xFF39E58C))
            Text(
                "Birden fazla ölçüm ve plan olduğunda sistem iyi/kötü trendi karşılaştırır; neye öncelik verileceğini çıkarır.",
                color = Color(0xFFC9D7E3),
                style = MaterialTheme.typography.bodySmall
            )
            insights.forEach { insight ->
                Surface(
                    shape = MaterialTheme.shapes.medium,
                    color = when (insight.level) {
                        ReferenceLevel.HIGH -> Color(0xFF4A2020)
                        ReferenceLevel.LOW -> Color(0xFF3A2F16)
                        ReferenceLevel.INFO -> Color(0xFF152A44)
                        ReferenceLevel.NORMAL -> Color(0xFF123123)
                    }
                ) {
                    Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(insight.title, fontWeight = FontWeight.Bold)
                        Text(insight.detail, color = Color(0xFFC9D7E3), style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}

@Composable
private fun TrackingStatusAndQualityPanel(status: TrackingStatus, quality: PlanQuality) {
    val statusColor = when (status.level) {
        ReferenceLevel.HIGH -> Color(0xFF4A2020)
        ReferenceLevel.LOW -> Color(0xFF3A2F16)
        ReferenceLevel.INFO -> Color(0xFF152A44)
        ReferenceLevel.NORMAL -> Color(0xFF123123)
    }
    ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = Color(0xFF0B1828), contentColor = Color.White)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Danışan Takip Durumu", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color(0xFF39E58C))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.Top) {
                Surface(shape = MaterialTheme.shapes.large, color = statusColor, modifier = Modifier.weight(1f)) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text(status.label, fontWeight = FontWeight.Bold)
                        Text(status.detail, color = Color(0xFFC9D7E3), style = MaterialTheme.typography.bodySmall)
                    }
                }
                Surface(shape = MaterialTheme.shapes.large, color = Color(0xFF102A24), modifier = Modifier.weight(1f)) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("%${quality.score}", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = Color(0xFF39E58C))
                        Text("Plan kalite skoru", color = Color(0xFFC9D7E3), style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            if (quality.strengths.isNotEmpty()) {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(quality.strengths) { item ->
                        Surface(shape = MaterialTheme.shapes.medium, color = Color(0xFF123123)) {
                            Text(item, Modifier.padding(horizontal = 9.dp, vertical = 5.dp), style = MaterialTheme.typography.labelSmall, color = Color.White, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
            if (quality.missing.isNotEmpty()) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    quality.missing.forEach { item ->
                        Surface(shape = MaterialTheme.shapes.medium, color = Color(0xFF3A2F16)) {
                            Text(item, Modifier.fillMaxWidth().padding(10.dp), color = Color(0xFFFFF3CD), style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PlanTemplatePanel(
    templates: List<PlanTemplateEntity>,
    actions: List<PlanAction>,
    onApply: (PlanTemplateEntity) -> Unit
) {
    val suggestedTags = actions.joinToString(" ") { "${it.category} ${it.title} ${it.metric}" }.lowercase()
    fun isSuggested(template: PlanTemplateEntity): Boolean {
        return when (template.triggerTag) {
            "fat_high", "visceral_waist" -> suggestedTags.contains("yağ") || suggestedTags.contains("kilo") || suggestedTags.contains("bel")
            "water_low" -> suggestedTags.contains("sıvı") || suggestedTags.contains("su")
            "muscle_low" -> suggestedTags.contains("kas") || suggestedTags.contains("protein")
            else -> false
        }
    }
    ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = Color(0xFFF2F8F4), contentColor = Color(0xFF0F172A))) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Profesyonel Plan Şablonları", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color(0xFF14532D))
            Text("Yağ, sıvı, kas, iç yağ ve bel durumuna göre hazır beslenme, su, ürün ve aktivite omurgası.", color = Color(0xFF334155), style = MaterialTheme.typography.bodySmall)
            if (templates.isEmpty()) {
                Text("Şablonlar hazırlanıyor. Uygulama veri tohumu tamamlandığında burada görünecek.", color = Color(0xFF334155))
            } else {
                templates.sortedWith(compareByDescending<PlanTemplateEntity> { isSuggested(it) }.thenBy { it.priority }).take(4).forEach { template ->
                    Surface(shape = MaterialTheme.shapes.large, color = if (isSuggested(template)) Color(0xFFE0F2E9) else Color.White) {
                        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Top) {
                                Column(Modifier.weight(1f)) {
                                    Text(template.name, fontWeight = FontWeight.Bold)
                                    Text(template.triggerTag, color = Color(0xFF64748B), style = MaterialTheme.typography.labelSmall)
                                }
                                if (isSuggested(template)) {
                                    Surface(shape = MaterialTheme.shapes.medium, color = Color(0xFF14532D)) {
                                        Text("Önerilir", Modifier.padding(horizontal = 8.dp, vertical = 4.dp), color = Color.White, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                            Text(template.meals, color = Color(0xFF334155), style = MaterialTheme.typography.bodySmall)
                            Text("Su: ${template.water}", color = Color(0xFF334155), style = MaterialTheme.typography.bodySmall)
                            Text("Ürün odağı: ${template.productFocus}", color = Color(0xFF14532D), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                            Text("Aktivite: ${template.activityFocus}", color = Color(0xFF334155), style = MaterialTheme.typography.bodySmall)
                            OutlinedButton(onClick = { onApply(template) }, modifier = Modifier.fillMaxWidth()) {
                                Text("Şablonu plana uygula")
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ComplianceTrackerPanel(
    patientId: Long,
    dietPlanId: Long?,
    logs: List<DailyComplianceEntity>,
    onSave: (DailyComplianceEntity) -> Unit
) {
    val dayMillis = 24L * 60L * 60L * 1000L
    val todayMillis = System.currentTimeMillis() / dayMillis * dayMillis
    val todayLog = logs.firstOrNull { it.dateMillis == todayMillis }
        ?: DailyComplianceEntity(patientId = patientId, dietPlanId = dietPlanId, dateMillis = todayMillis)
    var productsTaken by remember(todayLog.id, todayLog.updatedAt) { mutableStateOf(todayLog.productsTaken) }
    var waterDone by remember(todayLog.id, todayLog.updatedAt) { mutableStateOf(todayLog.waterDone) }
    var vegetablesDone by remember(todayLog.id, todayLog.updatedAt) { mutableStateOf(todayLog.vegetablesDone) }
    var proteinDone by remember(todayLog.id, todayLog.updatedAt) { mutableStateOf(todayLog.proteinDone) }
    var activityDone by remember(todayLog.id, todayLog.updatedAt) { mutableStateOf(todayLog.activityDone) }
    var sleepDone by remember(todayLog.id, todayLog.updatedAt) { mutableStateOf(todayLog.sleepDone) }
    var note by remember(todayLog.id, todayLog.updatedAt) { mutableStateOf(todayLog.note) }
    val edited = todayLog.copy(
        dietPlanId = dietPlanId,
        productsTaken = productsTaken,
        waterDone = waterDone,
        vegetablesDone = vegetablesDone,
        proteinDone = proteinDone,
        activityDone = activityDone,
        sleepDone = sleepDone,
        note = note,
        updatedAt = System.currentTimeMillis()
    )
    val avg = logs.take(7).takeIf { it.isNotEmpty() }?.map { compliancePercent(it) }?.average()?.toInt()

    ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = Color(0xFF111827), contentColor = Color.White)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text("Günlük Uyum Takibi", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color(0xFF39E58C))
                    Text("Ürün, su, sebze, protein, aktivite ve uyku kontrol listesi.", color = Color(0xFFC9D7E3), style = MaterialTheme.typography.bodySmall)
                }
                Surface(shape = MaterialTheme.shapes.medium, color = Color(0xFF102A24)) {
                    Text("Bugün %${compliancePercent(edited)}", Modifier.padding(horizontal = 9.dp, vertical = 6.dp), color = Color(0xFF39E58C), fontWeight = FontWeight.Bold)
                }
            }
            if (avg != null) {
                Text("Son 7 kayıt ortalaması: %$avg", color = Color(0xFFC9D7E3), style = MaterialTheme.typography.bodySmall)
            }
            listOf(
                "Ürünler kullanıldı" to productsTaken,
                "Su hedefi tamam" to waterDone,
                "Sebze tüketildi" to vegetablesDone,
                "Protein alındı" to proteinDone,
                "Aktivite yapıldı" to activityDone,
                "Uyku takip edildi" to sleepDone
            ).chunked(2).forEach { rowItems ->
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    rowItems.forEach { (label, selected) ->
                        FilterChip(
                            selected = selected,
                            onClick = {
                                when (label) {
                                    "Ürünler kullanıldı" -> productsTaken = !productsTaken
                                    "Su hedefi tamam" -> waterDone = !waterDone
                                    "Sebze tüketildi" -> vegetablesDone = !vegetablesDone
                                    "Protein alındı" -> proteinDone = !proteinDone
                                    "Aktivite yapıldı" -> activityDone = !activityDone
                                    "Uyku takip edildi" -> sleepDone = !sleepDone
                                }
                            },
                            label = { Text(label) }
                        )
                    }
                }
            }
            OutlinedTextField(note, { note = it }, Modifier.fillMaxWidth(), label = { Text("Bugünkü uyum notu") })
            Button(onClick = { onSave(edited) }, modifier = Modifier.fillMaxWidth()) {
                Text("Günlük uyumu kaydet")
            }
        }
    }
}

@Composable
private fun DecisionLogPanel(
    logs: List<DecisionLogEntity>,
    patientId: Long,
    measurementId: Long?,
    dietPlanId: Long?,
    suggestedActions: List<PlanAction>,
    onAdd: (DecisionLogEntity) -> Unit
) {
    val firstAction = suggestedActions.firstOrNull()
    var title by remember(firstAction?.title) { mutableStateOf(firstAction?.title ?: "Plan kararı") }
    var reason by remember(firstAction?.detail) { mutableStateOf(firstAction?.detail ?: "") }
    var action by remember(firstAction?.productFocus) { mutableStateOf(firstAction?.productFocus ?: "") }

    ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = Color(0xFF0F1B2B), contentColor = Color.White)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Danışman Notları / Karar Günlüğü", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color(0xFF39E58C))
            Text("Plan neden verildi, ürün neden değişti, hangi ölçüm önceliklendirildi bilgisi burada saklanır.", color = Color(0xFFC9D7E3), style = MaterialTheme.typography.bodySmall)
            OutlinedTextField(title, { title = it }, Modifier.fillMaxWidth(), label = { Text("Karar başlığı") })
            OutlinedTextField(reason, { reason = it }, Modifier.fillMaxWidth().height(96.dp), label = { Text("Gerekçe") })
            OutlinedTextField(action, { action = it }, Modifier.fillMaxWidth().height(88.dp), label = { Text("Aksiyon / ürün değişimi") })
            Button(
                onClick = {
                    onAdd(
                        DecisionLogEntity(
                            patientId = patientId,
                            measurementId = measurementId,
                            dietPlanId = dietPlanId,
                            title = title.ifBlank { "Plan kararı" },
                            reason = reason.ifBlank { "Danışman tarafından eklendi." },
                            action = action.ifBlank { "Takipte değerlendirilecek." },
                            priority = firstAction?.priority ?: 3
                        )
                    )
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Kararı günlüğe ekle")
            }
            if (logs.isNotEmpty()) {
                HorizontalDivider(color = Color.White.copy(alpha = 0.12f))
                logs.take(4).forEach { log ->
                    Surface(shape = MaterialTheme.shapes.medium, color = Color(0xFF152A44)) {
                        Column(Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text(log.title, fontWeight = FontWeight.Bold)
                            Text(log.reason, color = Color(0xFFC9D7E3), style = MaterialTheme.typography.bodySmall)
                            Text(log.action, color = Color(0xFFB9F6CA), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SmartNutritionPanel(actions: List<NutritionAction>) {
    ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = Color(0xFFF2F8F4), contentColor = Color(0xFF0F172A))) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Akıllı Beslenme Planı", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color(0xFF14532D))
            Text(
                "Sebze, protein, su, lif ve aktivite uyumunu ölçüm sonuçlarına göre planlamak için kullanılır.",
                color = Color(0xFF334155),
                style = MaterialTheme.typography.bodySmall
            )
            actions.forEach { action ->
                Surface(
                    shape = MaterialTheme.shapes.large,
                    color = when (action.level) {
                        ReferenceLevel.HIGH -> Color(0xFFFFEBEE)
                        ReferenceLevel.LOW -> Color(0xFFFFF8E1)
                        ReferenceLevel.INFO -> Color(0xFFE3F2FD)
                        ReferenceLevel.NORMAL -> Color(0xFFE8F5E9)
                    }
                ) {
                    Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(action.title, fontWeight = FontWeight.Bold)
                        Text(action.detail, color = Color(0xFF334155), style = MaterialTheme.typography.bodySmall)
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(action.examples) { example ->
                                Surface(shape = MaterialTheme.shapes.medium, color = Color.White) {
                                    Text(example, Modifier.padding(horizontal = 8.dp, vertical = 5.dp), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.SemiBold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SmartProductRecommendationCard(
    recommendation: ProductRecommendation,
    onAdd: () -> Unit
) {
    Surface(shape = MaterialTheme.shapes.large, color = Color(0xFF101F31)) {
        Row(
            Modifier.fillMaxWidth().padding(12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(color = MaterialTheme.colorScheme.primaryContainer, shape = MaterialTheme.shapes.medium, modifier = Modifier.size(64.dp)) {
                if (recommendation.product.imageUrl.isNotBlank()) {
                    AsyncImage(
                        model = recommendation.product.imageUrl,
                        contentDescription = recommendation.product.name,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Inventory2, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    }
                }
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Top) {
                    Column(Modifier.weight(1f)) {
                        Text(recommendation.product.name, fontWeight = FontWeight.Bold, color = Color.White)
                        if (recommendation.product.code.isNotBlank()) {
                            Text("Kod: ${recommendation.product.code}", style = MaterialTheme.typography.bodySmall, color = Color(0xFFC9D7E3))
                        }
                    }
                    Surface(shape = MaterialTheme.shapes.medium, color = Color(0xFF123123)) {
                        Text("%${recommendation.score}", Modifier.padding(horizontal = 8.dp, vertical = 5.dp), color = Color(0xFFB9F6CA), fontWeight = FontWeight.Bold)
                    }
                }
                Text(recommendation.reason, color = Color(0xFFC9D7E3), style = MaterialTheme.typography.bodySmall)
                if (recommendation.tags.isNotEmpty()) {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(recommendation.tags) { tag ->
                            Surface(shape = MaterialTheme.shapes.medium, color = Color(0xFF152A44)) {
                                Text(tag, Modifier.padding(horizontal = 8.dp, vertical = 4.dp), color = Color(0xFF93C5FD), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
                if (recommendation.warning.isNotBlank()) {
                    Text(recommendation.warning, color = Color(0xFFFFB4B4), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                }
                OutlinedButton(onClick = onAdd, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.size(6.dp))
                    Text("Plana Ekle")
                }
            }
        }
    }
}

@Composable
private fun StockProjectionCard(
    item: com.example.bodytracker.data.DietPlanProductEntity,
    compact: Boolean = false,
    modifier: Modifier = Modifier
) {
    val projection = stockProjection(item)
    Surface(modifier = modifier, shape = MaterialTheme.shapes.medium, color = Color(0xFFE9F4EE)) {
        Column(
            Modifier.fillMaxWidth().padding(if (compact) 10.dp else 12.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text("Stok takibi", fontWeight = FontWeight.Bold, color = Color(0xFF14532D))
            Text(
                projection.days?.let { "Yaklaşık $it gün gider" } ?: "Kutu/adet bilgisi girilince hesaplanır",
                style = if (compact) MaterialTheme.typography.bodySmall else MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                color = Color(0xFF0F172A)
            )
            if (!compact) {
                Text(
                    "Toplam: ${projection.totalStock.oneDecimal()} ${projection.unit.ifBlank { "birim" }} • Günlük: ${projection.dailyUsage.oneDecimal()}",
                    color = Color(0xFF334155),
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}

private fun formatSupplementLine(product: com.example.bodytracker.data.ProductEntity, item: com.example.bodytracker.data.DietPlanProductEntity): String {
    val stock = stockProjection(item)
    val stockText = stock.days?.let { "${stock.totalStock.oneDecimal()} ${stock.unit} stok / ${stock.dailyUsage.oneDecimal()} günlük tüketim / yaklaşık $it gün" }
    val pieces = listOf(
        product.name,
        item.applicationMethod.ifBlank { suggestApplicationMethod(product, "") },
        item.usagePattern.ifBlank { suggestUsagePattern(product) },
        listOf(item.quantityValue, item.quantityUnit).filter { it.isNotBlank() }.joinToString(" ").ifBlank { product.defaultDose },
        item.timingNote.ifBlank { item.customTiming.ifBlank { product.timing } },
        stockText,
        item.customNote
    ).filter { it.isNotBlank() }
    return pieces.joinToString(" — ")
}

@Composable
private fun SupplementOperationsSummary(
    selectedCount: Int,
    alertCount: Int,
    criticalCount: Int,
    missingCount: Int
) {
    ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = Color(0xFF0F1B2B), contentColor = Color.White)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Takviye Operasyon Özeti", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color(0xFF39E58C))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                DashboardStatusPill("Seçili", selectedCount.toString(), Modifier.weight(1f))
                DashboardStatusPill("Uyarı", alertCount.toString(), Modifier.weight(1f))
                DashboardStatusPill("Kritik", criticalCount.toString(), Modifier.weight(1f))
            }
            val message = when {
                selectedCount == 0 -> "Bu analiz için henüz takviye seçilmedi."
                criticalCount > 0 -> "$criticalCount ürün bitmek üzere. Yenileme planı kontrol edilmeli."
                missingCount > 0 -> "$missingCount üründe stok/kutu bilgisi eksik."
                alertCount == 0 -> "Seçili ürünlerde kritik stok uyarısı görünmüyor."
                else -> "Takviye planı takipte."
            }
            Text(message, color = Color(0xFFC9D7E3))
        }
    }
}

@Composable
private fun SupplementPlanEditorCard(
    product: com.example.bodytracker.data.ProductEntity,
    categoryName: String,
    item: com.example.bodytracker.data.DietPlanProductEntity,
    onRemove: () -> Unit,
    onSave: (com.example.bodytracker.data.DietPlanProductEntity) -> Unit
) {
    var applicationMethod by remember(item.id) { mutableStateOf(item.applicationMethod.ifBlank { suggestApplicationMethod(product, categoryName) }) }
    var usagePattern by remember(item.id) { mutableStateOf(item.usagePattern.ifBlank { suggestUsagePattern(product) }) }
    var quantityValue by remember(item.id) { mutableStateOf(item.quantityValue.ifBlank { suggestQuantityValue(product) }) }
    var quantityUnit by remember(item.id) { mutableStateOf(item.quantityUnit.ifBlank { suggestQuantityUnit(product) }) }
    var packageCount by remember(item.id) { mutableStateOf(item.packageCount.ifBlank { "1" }) }
    var packageSize by remember(item.id) { mutableStateOf(item.packageSize.ifBlank { suggestPackageSize(product) }) }
    var packageUnit by remember(item.id) { mutableStateOf(item.packageUnit.ifBlank { quantityUnit }) }
    var dailyUsage by remember(item.id) { mutableStateOf(item.dailyUsage.ifBlank { suggestDailyUsage(usagePattern, quantityValue) }) }
    var timingNote by remember(item.id) { mutableStateOf(item.timingNote.ifBlank { item.customTiming.ifBlank { product.timing } }) }
    var note by remember(item.id) { mutableStateOf(item.customNote) }
    val previewItem = item.copy(
        applicationMethod = applicationMethod,
        usagePattern = usagePattern,
        quantityValue = quantityValue,
        quantityUnit = quantityUnit,
        packageCount = packageCount,
        packageSize = packageSize,
        packageUnit = packageUnit,
        dailyUsage = dailyUsage,
        timingNote = timingNote,
        customNote = note
    )

    Surface(shape = MaterialTheme.shapes.large, color = MaterialTheme.colorScheme.surface) {
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Surface(color = MaterialTheme.colorScheme.primaryContainer, shape = MaterialTheme.shapes.medium, modifier = Modifier.size(58.dp)) {
                    if (product.imageUrl.isNotBlank()) {
                        AsyncImage(
                            model = product.imageUrl,
                            contentDescription = product.name,
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    } else {
                        IconBadge(
                            icon = when {
                                applicationMethod.contains("Saça", true) -> Icons.Default.PhotoLibrary
                                applicationMethod.contains("Dış", true) -> Icons.Default.Category
                                else -> Icons.Default.LocalDrink
                            },
                            size = 42.dp
                        )
                    }
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(product.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    if (product.code.isNotBlank()) Text("Kod: ${product.code}", style = MaterialTheme.typography.bodySmall, color = Color(0xFFC9D7E3))
                    if (categoryName.isNotBlank()) Text(categoryName, color = MaterialTheme.colorScheme.primary)
                }
                IconButton(onClick = onRemove) { Icon(Icons.Default.Delete, null, tint = Color(0xFFC62828)) }
            }

            Text("Uygulama yöntemi", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Ağızdan", "Çiğneme", "Saça", "Dış deriye").forEach { option ->
                    FilterChip(selected = applicationMethod == option, onClick = { applicationMethod = option }, label = { Text(option) })
                }
            }

            Text("Kullanım şekli", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("1x1", "1x2", "2x1", "2x2").forEach { option ->
                    FilterChip(
                        selected = usagePattern == option,
                        onClick = {
                            usagePattern = option
                            dailyUsage = suggestDailyUsage(option, quantityValue)
                        },
                        label = { Text(option) }
                    )
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    quantityValue,
                    {
                        quantityValue = it
                        dailyUsage = suggestDailyUsage(usagePattern, it)
                    },
                    modifier = Modifier.weight(0.8f),
                    label = { Text("Kullanım miktarı") },
                    singleLine = true
                )
                OutlinedTextField(quantityUnit, { quantityUnit = it }, modifier = Modifier.weight(1.2f), label = { Text("Birim") }, singleLine = true)
            }
            Text("Eldeki stok", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(packageCount, { packageCount = it.filterStockNumber() }, modifier = Modifier.weight(1f), label = { Text("Kutu") }, singleLine = true)
                OutlinedTextField(packageSize, { packageSize = it.filterStockNumber() }, modifier = Modifier.weight(1f), label = { Text("Kutu içi") }, singleLine = true)
                OutlinedTextField(packageUnit, { packageUnit = it }, modifier = Modifier.weight(1f), label = { Text("Birim") }, singleLine = true)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(dailyUsage, { dailyUsage = it.filterStockNumber() }, modifier = Modifier.weight(1f), label = { Text("Günlük tüketim") }, singleLine = true)
                StockProjectionCard(previewItem, compact = true, modifier = Modifier.weight(1f))
            }
            OutlinedTextField(timingNote, { timingNote = it }, Modifier.fillMaxWidth(), label = { Text("Zaman / kullanım notu") })
            OutlinedTextField(note, { note = it }, Modifier.fillMaxWidth(), label = { Text("Ek not") })

            Surface(shape = MaterialTheme.shapes.medium, color = MaterialTheme.colorScheme.secondaryContainer) {
                Text(
                    text = formatSupplementLine(product, previewItem),
                    modifier = Modifier.fillMaxWidth().padding(12.dp)
                )
            }

            Button(onClick = {
                onSave(item.copy(
                    applicationMethod = applicationMethod,
                    usagePattern = usagePattern,
                    quantityValue = quantityValue,
                    quantityUnit = quantityUnit,
                    packageCount = packageCount,
                    packageSize = packageSize,
                    packageUnit = packageUnit,
                    dailyUsage = dailyUsage,
                    timingNote = timingNote,
                    customTiming = timingNote,
                    goalTag = item.goalTag.ifBlank { "Plan" },
                    customNote = note,
                    customDose = listOf(quantityValue, quantityUnit).filter { it.isNotBlank() }.joinToString(" ")
                ))
            }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.Done, null)
                Spacer(Modifier.size(6.dp))
                Text("Takviye kartını kaydet")
            }
        }
    }
}

@Composable
private fun ProductSelectionCard(
    product: com.example.bodytracker.data.ProductEntity,
    categoryName: String,
    selected: Boolean,
    onEdit: () -> Unit,
    onToggle: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
            .clickable(onClick = onToggle),
        colors = CardDefaults.cardColors(
            containerColor = if (selected) MaterialTheme.colorScheme.tertiaryContainer else MaterialTheme.colorScheme.surface
        )
    ) {
        Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(color = MaterialTheme.colorScheme.primaryContainer, shape = MaterialTheme.shapes.medium, modifier = Modifier.size(72.dp)) {
                if (product.imageUrl.isNotBlank()) {
                    AsyncImage(
                        model = product.imageUrl,
                        contentDescription = product.name,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                        val categoryIcon = when {
                            categoryName.contains("Aloe", true) -> Icons.Default.LocalDrink
                            categoryName.contains("Vitamin", true) || categoryName.contains("Mineral", true) -> Icons.Default.Medication
                            categoryName.contains("Performans", true) -> Icons.Default.QueryStats
                            else -> Icons.Default.Inventory2
                        }
                        Icon(categoryIcon, contentDescription = null, modifier = Modifier.size(30.dp))
                    }
                }
            }
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(product.name, fontWeight = FontWeight.Bold)
                if (product.code.isNotBlank()) Text("Kod: ${product.code}", style = MaterialTheme.typography.bodySmall, color = Color(0xFFC9D7E3))
                if (categoryName.isNotBlank()) Text(categoryName, color = MaterialTheme.colorScheme.primary)
                if (product.description.isNotBlank()) Text(product.description, maxLines = 2)
                val info = listOf(product.defaultDose, product.timing).filter { it.isNotBlank() }.joinToString(" • ")
                if (info.isNotBlank()) Text(info, style = MaterialTheme.typography.bodySmall)
            }
            Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                IconButton(onClick = onEdit) {
                    Icon(Icons.Default.Edit, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                }
                Button(onClick = onToggle) {
                    Text(if (selected) "Çıkar" else "Ekle")
                }
            }
        }
    }
}

@Composable
private fun ProductCatalogEditDialog(
    product: com.example.bodytracker.data.ProductEntity,
    onDismiss: () -> Unit,
    onSave: (com.example.bodytracker.data.ProductEntity) -> Unit
) {
    var name by remember(product.id) { mutableStateOf(product.name) }
    var code by remember(product.id) { mutableStateOf(product.code) }
    var imageUrl by remember(product.id) { mutableStateOf(product.imageUrl) }
    var description by remember(product.id) { mutableStateOf(product.description) }
    var usageNote by remember(product.id) { mutableStateOf(product.usageNote) }
    var defaultDose by remember(product.id) { mutableStateOf(product.defaultDose) }
    var timing by remember(product.id) { mutableStateOf(product.timing) }
    AlertDialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false),
        title = { Text("Ürün Kataloğu Yönetimi") },
        text = {
            LazyColumn(
                modifier = Modifier.fillMaxWidth().height(560.dp).padding(end = 4.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Surface(color = MaterialTheme.colorScheme.primaryContainer, shape = MaterialTheme.shapes.medium, modifier = Modifier.size(72.dp)) {
                            if (imageUrl.isNotBlank()) {
                                AsyncImage(imageUrl, contentDescription = name, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                            } else {
                                Icon(Icons.Default.Inventory2, contentDescription = null, modifier = Modifier.padding(18.dp))
                            }
                        }
                        Column(Modifier.weight(1f)) {
                            Text(product.brand, fontWeight = FontWeight.Bold)
                            Text("Kod, görsel, açıklama, varsayılan kullanım ve zamanlama düzenlenir.", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
                item { OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), label = { Text("Ürün adı") }) }
                item { OutlinedTextField(code, { code = it }, Modifier.fillMaxWidth(), label = { Text("Ürün kodu") }) }
                item { OutlinedTextField(imageUrl, { imageUrl = it }, Modifier.fillMaxWidth(), label = { Text("Görsel URL / asset yolu") }) }
                item { OutlinedTextField(defaultDose, { defaultDose = it }, Modifier.fillMaxWidth(), label = { Text("Varsayılan kullanım / kutu içi bilgi") }) }
                item { OutlinedTextField(timing, { timing = it }, Modifier.fillMaxWidth(), label = { Text("Varsayılan zamanlama") }) }
                item { OutlinedTextField(description, { description = it }, Modifier.fillMaxWidth().height(100.dp), label = { Text("Açıklama") }) }
                item { OutlinedTextField(usageNote, { usageNote = it }, Modifier.fillMaxWidth().height(100.dp), label = { Text("Kullanım notu") }) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                onSave(
                    product.copy(
                        name = name.trim().ifBlank { product.name },
                        code = code.trim(),
                        imageUrl = imageUrl.trim(),
                        description = description.trim(),
                        usageNote = usageNote.trim(),
                        defaultDose = defaultDose.trim(),
                        timing = timing.trim(),
                        updatedAt = System.currentTimeMillis()
                    )
                )
            }) { Text("Kaydet") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("İptal") } }
    )
}


private fun patientAge(patient: PatientEntity): Int = if (patient.ageYears > 0) patient.ageYears else calculateAge(patient.birthDateMillis)

private fun shareText(context: Context, content: String, patient: PatientEntity, whatsappOnly: Boolean) {
    val file = File(context.cacheDir, "diyet_${patient.firstName}_${patient.lastName}.txt")
    file.writeText(content)
    val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, content)
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    try {
        if (whatsappOnly) {
            intent.setPackage("com.whatsapp")
            context.startActivity(intent)
        } else context.startActivity(Intent.createChooser(intent, "Belgeyi paylaş"))
    } catch (_: ActivityNotFoundException) {
        context.startActivity(Intent.createChooser(intent.apply { `package` = null }, "Belgeyi paylaş"))
    }
}

private fun generateAnalysisReportText(
    patient: PatientEntity,
    latest: MeasurementEntity,
    previous: MeasurementEntity?,
    previousMonth: MeasurementEntity?,
    measurements: List<MeasurementEntity>
): String {
    val targetWeight = patient.targetWeightKg.takeIf { it > 0.0 } ?: ((22.0 * patient.heightCm * patient.heightCm) / 10000.0)
    val first = measurements.lastOrNull()
    return buildString {
        appendLine("VUCUT ANALIZ RAPORU")
        appendLine("Danışan: ${patient.firstName} ${patient.lastName}")
        appendLine("Tarih: ${formatDate(latest.dateMillis)}")
        appendLine("Cinsiyet / Yaş: ${patient.gender} / ${patientAge(patient)}")
        appendLine("Boy: ${patient.heightCm} cm")
        appendLine()
        appendLine("GENEL OZET")
        appendLine("• Kilo: ${latest.weightKg.oneDecimal()} kg")
        appendLine("• VKI: ${latest.bmi.oneDecimal()}")
        appendLine("• Yag Orani: %${latest.bodyFatPercent.oneDecimal()}")
        appendLine("• Sivi Orani: %${latest.bodyWaterPercent.oneDecimal()}")
        appendLine("• Kas: ${latest.muscle.oneDecimal()}")
        appendLine("• Bel Cevresi: ${if (latest.waistCm > 0) latest.waistCm.oneDecimal() else "-"} cm")
        appendLine("• Kemik: ${latest.bone.oneDecimal()} kg")
        appendLine("• Metabolizma Hizi: ${latest.metabolicRate.oneDecimal()} kcal")
        appendLine("• Metabolizma Yasi: ${latest.metabolicAge}")
        appendLine("• Ic Yag: ${latest.visceralFat.oneDecimal()}")
        appendLine()
        appendLine("HEDEF KILO KONTROLU")
        appendLine("• Ideal kilo: ${targetWeight.oneDecimal()} kg")
        appendLine("• Fark: ${(latest.weightKg - targetWeight).oneDecimal()} kg")
        appendLine("• Durum: ${buildSmartCoachSummary(patient, measurements)}")
        appendLine()
        appendLine("REFERANS YORUMU")
        appendLine("• VKI: ${bmiReferenceStatus(latest.bmi).statusText}")
        appendLine("• Yag: ${bodyFatReferenceStatus(patient.gender, patientAge(patient), latest.bodyFatPercent).statusText}")
        appendLine("• Sivi: ${bodyWaterReferenceStatus(patient.gender, latest.bodyWaterPercent).statusText}")
        appendLine("• Kas: ${muscleReferenceStatus(patient.gender, latest.muscle).statusText}")
        appendLine("• Kemik: ${boneReferenceStatus(patient.gender, latest.bone).statusText}")
        previous?.let {
            appendLine()
            appendLine("ONCEKI OLCUME GORE")
            appendLine("• Kilo farki: ${(latest.weightKg - it.weightKg).oneDecimal()} kg")
            appendLine("• Yag farki: ${(latest.bodyFatPercent - it.bodyFatPercent).oneDecimal()} %")
            appendLine("• Sivi farki: ${(latest.bodyWaterPercent - it.bodyWaterPercent).oneDecimal()} %")
        }
        previousMonth?.let {
            appendLine()
            appendLine("ONCEKI AYA GORE")
            appendLine("• Kilo farki: ${(latest.weightKg - it.weightKg).oneDecimal()} kg")
            appendLine("• Yag farki: ${(latest.bodyFatPercent - it.bodyFatPercent).oneDecimal()} %")
            appendLine("• Sivi farki: ${(latest.bodyWaterPercent - it.bodyWaterPercent).oneDecimal()} %")
        }
        first?.let {
            appendLine()
            appendLine("ILK KAYDA GORE")
            appendLine("• Kilo farki: ${(latest.weightKg - it.weightKg).oneDecimal()} kg")
            appendLine("• Yag farki: ${(latest.bodyFatPercent - it.bodyFatPercent).oneDecimal()} %")
            appendLine("• Sivi farki: ${(latest.bodyWaterPercent - it.bodyWaterPercent).oneDecimal()} %")
        }
    }
}

private fun createAnalysisPdf(context: Context, patient: PatientEntity, measurements: List<MeasurementEntity>, content: String): File {
    val pdf = PdfDocument()
    val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
    val page = pdf.startPage(pageInfo)
    val canvas = page.canvas

    val navy = android.graphics.Color.rgb(32, 64, 112)
    val border = android.graphics.Color.rgb(146, 160, 178)
    val soft = android.graphics.Color.rgb(243, 246, 250)
    val green = android.graphics.Color.rgb(116, 154, 66)
    val amber = android.graphics.Color.rgb(196, 141, 55)
    val red = android.graphics.Color.rgb(189, 87, 87)
    val white = android.graphics.Color.WHITE
    val blueBar = android.graphics.Color.rgb(79, 124, 172)
    val grayBar = android.graphics.Color.rgb(149, 165, 166)
    val greenBar = android.graphics.Color.rgb(106, 153, 78)

    val titlePaint = Paint().apply {
        color = navy
        textSize = 18f
        isFakeBoldText = true
        textAlign = Paint.Align.CENTER
        isAntiAlias = true
    }
    val headerPaint = Paint().apply {
        color = navy
        textSize = 10.5f
        isFakeBoldText = true
        isAntiAlias = true
    }
    val bodyPaint = Paint().apply {
        color = android.graphics.Color.BLACK
        textSize = 10f
        isAntiAlias = true
    }
    val smallPaint = Paint().apply {
        color = android.graphics.Color.DKGRAY
        textSize = 8.5f
        isAntiAlias = true
    }
    val centerBodyPaint = Paint(bodyPaint).apply { textAlign = Paint.Align.CENTER }
    val centerHeaderPaint = Paint(headerPaint).apply { textAlign = Paint.Align.CENTER }
    val linePaint = Paint().apply {
        color = border
        strokeWidth = 1.05f
        style = Paint.Style.STROKE
        isAntiAlias = true
    }
    val fillPaint = Paint().apply {
        color = soft
        style = Paint.Style.FILL
        isAntiAlias = true
    }
    val badgePaint = Paint().apply {
        style = Paint.Style.FILL
        isAntiAlias = true
    }

    val latest = measurements.firstOrNull()
    val previous = measurements.getOrNull(1)
    val first = measurements.lastOrNull()
    val comparison = listOf(
        "İlk Kayıt" to first,
        "Sondan Bir Önceki" to previous,
        "Son Kayıt" to latest
    )

    fun refFor(metric: String): String = when (metric) {
        "Kilo (kg)" -> idealWeight(patient.heightCm).oneDecimal()
        "VKE (BMI)" -> "20-24"
        "Vücut Yağ Oranı" -> "≤27"
        "Vücut Sıvı Oranı" -> "≥55"
        "KPS" -> "≤15"
        "Kemik" -> "≥2.7"
        "Metabolizma Hızı" -> "≥1600"
        "İç Yağ" -> "≤5"
        else -> "-"
    }

    fun metricValue(m: MeasurementEntity?, metric: String): Double? = when (metric) {
        "Kilo (kg)" -> m?.weightKg
        "VKE (BMI)" -> m?.bmi
        "Vücut Yağ Oranı" -> m?.bodyFatPercent
        "Vücut Sıvı Oranı" -> m?.bodyWaterPercent
        "KPS" -> m?.let { kotlin.math.abs(it.weightKg - it.muscle) }
        "Kemik" -> m?.bone
        "Metabolizma Hızı" -> m?.metabolicRate
        "İç Yağ" -> m?.visceralFat
        else -> null
    }

    fun metricText(m: MeasurementEntity?, metric: String): String = metricValue(m, metric)?.oneDecimal() ?: "-"

    fun metricStatus(metric: String, m: MeasurementEntity?): Pair<String, Int> {
        if (m == null) return "-" to android.graphics.Color.LTGRAY
        val status = when (metric) {
            "Kilo (kg)" -> weightReferenceStatus(m.weightKg, patient.heightCm)
            "VKE (BMI)" -> bmiReferenceStatus(m.bmi)
            "Vücut Yağ Oranı" -> bodyFatReferenceStatus(patient.gender, patientAge(patient), m.bodyFatPercent)
            "Vücut Sıvı Oranı" -> bodyWaterReferenceStatus(patient.gender, m.bodyWaterPercent)
            "KPS" -> kpsReferenceStatus(m.weightKg, m.muscle)
            "Kemik" -> boneReferenceStatus(patient.gender, m.bone)
            "Metabolizma Hızı" -> metabolicRateReferenceStatus(patient.gender, patientAge(patient), patient.heightCm, m.weightKg, m.metabolicRate)
            "İç Yağ" -> visceralFatReferenceStatus(m.visceralFat)
            else -> ReferenceStatus("-", "-", ReferenceLevel.INFO)
        }
        val short = when {
            status.statusText.contains("hedef", ignoreCase = true) -> "Hedefte"
            status.statusText.contains("sinir", ignoreCase = true) -> "Sınırda"
            status.statusText.contains("dusuk", ignoreCase = true) || status.statusText.contains("düşük", ignoreCase = true) -> "Düşük"
            status.statusText.contains("yuksek", ignoreCase = true) || status.statusText.contains("yüksek", ignoreCase = true) -> "Yüksek"
            else -> status.statusText
        }
        val color = when (status.level) {
            ReferenceLevel.NORMAL -> green
            ReferenceLevel.LOW -> amber
            ReferenceLevel.HIGH -> red
            ReferenceLevel.INFO -> grayBar
        }
        return short to color
    }

    var y = 34f
    canvas.drawText("FOREVER PRO VUCUT ANALIZI", 297.5f, y, titlePaint)
    y += 14f
    canvas.drawLine(36f, y, 559f, y, linePaint)
    y += 12f

    val infoTop = y
    val infoBottom = infoTop + 62f
    val infoCols = listOf(36f, 190f, 340f, 559f)
    canvas.drawRect(36f, infoTop, 559f, infoBottom, fillPaint)
    canvas.drawRect(36f, infoTop, 559f, infoBottom, linePaint)
    infoCols.drop(1).dropLast(1).forEach { x -> canvas.drawLine(x, infoTop, x, infoBottom, linePaint) }
    canvas.drawLine(36f, infoTop + 31f, 559f, infoTop + 31f, linePaint)
    canvas.drawText("Danışan", 44f, infoTop + 14f, headerPaint)
    canvas.drawText("Yaş", 198f, infoTop + 14f, headerPaint)
    canvas.drawText("Tarih", 348f, infoTop + 14f, headerPaint)
    canvas.drawText((patient.firstName + " " + patient.lastName).trim().ifBlank { "-" }, 44f, infoTop + 28f, bodyPaint)
    canvas.drawText(patientAge(patient).toString(), 198f, infoTop + 28f, bodyPaint)
    canvas.drawText(formatDate(System.currentTimeMillis()), 348f, infoTop + 28f, bodyPaint)
    canvas.drawText("Cinsiyet", 44f, infoTop + 45f, headerPaint)
    canvas.drawText(patient.gender.ifBlank { "-" }, 102f, infoTop + 45f, bodyPaint)
    canvas.drawText("Boy", 198f, infoTop + 45f, headerPaint)
    canvas.drawText("${patient.heightCm} cm", 230f, infoTop + 45f, bodyPaint)
    canvas.drawText("M. Yaş", 348f, infoTop + 45f, headerPaint)
    canvas.drawText((latest?.metabolicAge ?: 0).toString(), 396f, infoTop + 45f, bodyPaint)
    y = infoBottom + 16f

    canvas.drawText("Ölçüm Sonuç Karşılaştırması", 36f, y, headerPaint)
    canvas.drawLine(36f, y + 6f, 559f, y + 6f, linePaint)
    y += 14f

    val tableLeft = 36f
    val tableTop = y
    val labelWidth = 140f
    val dataWidth = 90f
    val refWidth = 62f
    val statusWidth = 51f
    val headerHeight = 26f
    val rowHeight = 24f
    val tableRight = tableLeft + labelWidth + dataWidth * 3 + refWidth + statusWidth
    val columns = listOf(tableLeft, tableLeft + labelWidth, tableLeft + labelWidth + dataWidth, tableLeft + labelWidth + dataWidth * 2, tableLeft + labelWidth + dataWidth * 3, tableLeft + labelWidth + dataWidth * 3 + refWidth, tableRight)
    canvas.drawRect(tableLeft, tableTop, tableRight, tableTop + headerHeight + rowHeight * 8, linePaint)
    canvas.drawRect(tableLeft, tableTop, tableRight, tableTop + headerHeight, fillPaint)
    columns.drop(1).dropLast(0).forEach { x -> canvas.drawLine(x, tableTop, x, tableTop + headerHeight + rowHeight * 8, linePaint) }
    val headerY = tableTop + 17f
    canvas.drawText("Ölçüm", tableLeft + 8f, headerY, headerPaint)
    canvas.drawText("İlk Kayıt", tableLeft + labelWidth + dataWidth / 2f, headerY, centerHeaderPaint)
    canvas.drawText("Önceki", tableLeft + labelWidth + dataWidth * 1.5f, headerY, centerHeaderPaint)
    canvas.drawText("Son", tableLeft + labelWidth + dataWidth * 2.5f, headerY, centerHeaderPaint)
    canvas.drawText("Ref.", tableLeft + labelWidth + dataWidth * 3 + refWidth / 2f, headerY, centerHeaderPaint)
    canvas.drawText("Durum", tableLeft + labelWidth + dataWidth * 3 + refWidth + statusWidth / 2f, headerY, centerHeaderPaint)

    val metrics = listOf("Kilo (kg)", "VKE (BMI)", "Vücut Yağ Oranı", "Vücut Sıvı Oranı", "KPS", "Kemik", "Metabolizma Hızı", "İç Yağ")
    metrics.forEachIndexed { rowIndex, metric ->
        val top = tableTop + headerHeight + rowIndex * rowHeight
        val bottom = top + rowHeight
        canvas.drawLine(tableLeft, bottom, tableRight, bottom, linePaint)
        canvas.drawText(metric, tableLeft + 8f, top + 16f, bodyPaint)
        comparison.forEachIndexed { colIndex, entry ->
            val cx = tableLeft + labelWidth + dataWidth * colIndex + dataWidth / 2f
            canvas.drawText(metricText(entry.second, metric), cx, top + 16f, centerBodyPaint)
        }
        canvas.drawText(refFor(metric), tableLeft + labelWidth + dataWidth * 3 + refWidth / 2f, top + 16f, centerBodyPaint)
        val (statusText, statusColor) = metricStatus(metric, latest)
        badgePaint.color = statusColor
        val badgeLeft = tableLeft + labelWidth + dataWidth * 3 + refWidth + 4f
        val badgeTop = top + 4f
        val badgeRight = tableRight - 4f
        val badgeBottom = bottom - 4f
        canvas.drawRoundRect(badgeLeft, badgeTop, badgeRight, badgeBottom, 6f, 6f, badgePaint)
        canvas.drawText(statusText.take(7), (badgeLeft + badgeRight) / 2f, top + 16f, Paint(centerBodyPaint).apply { color = white; textSize = 8.5f })
    }
    y = tableTop + headerHeight + rowHeight * 8 + 16f

    canvas.drawText("Grafik Karşılaştırmaları", 36f, y, headerPaint)
    canvas.drawLine(36f, y + 6f, 559f, y + 6f, linePaint)
    y += 14f

    fun drawGroupedBarBlock(left: Float, top: Float, width: Float, height: Float, title: String, series: List<Pair<String, List<Double?>>>) {
        canvas.drawRect(left, top, left + width, top + height, linePaint)
        canvas.drawText(title, left + 8f, top + 14f, headerPaint)
        val innerLeft = left + 24f
        val innerRight = left + width - 12f
        val baseY = top + height - 20f
        val innerTop = top + 24f
        val allValues = series.flatMap { it.second }.mapNotNull { it }
        val maxValue = (allValues.maxOrNull() ?: 1.0).coerceAtLeast(1.0)
        canvas.drawLine(innerLeft, baseY, innerRight, baseY, linePaint)
        val groupCount = series.size
        val groupWidth = (innerRight - innerLeft) / groupCount
        val colors = listOf(blueBar, grayBar, greenBar)
        series.forEachIndexed { gIndex, (label, vals) ->
            vals.forEachIndexed { i, v ->
                val barWidth = 14f
                val gap = 4f
                val totalWidth = barWidth * 3 + gap * 2
                val startX = innerLeft + groupWidth * gIndex + (groupWidth - totalWidth) / 2f
                val leftX = startX + i * (barWidth + gap)
                val ratio = ((v ?: 0.0) / maxValue).toFloat().coerceIn(0f, 1f)
                val topY = baseY - (baseY - innerTop - 4f) * ratio
                val barPaint = Paint().apply { color = colors.getOrElse(i){greenBar}; style = Paint.Style.FILL; isAntiAlias = true }
                canvas.drawRect(leftX, topY, leftX + barWidth, baseY, barPaint)
            }
            canvas.drawText(label, innerLeft + groupWidth * gIndex + groupWidth / 2f, baseY + 14f, Paint(centerBodyPaint).apply { textSize = 8.5f })
        }
        val legendY = top + 16f
        listOf("İlk" to blueBar, "Önceki" to grayBar, "Son" to greenBar).forEachIndexed { i, (txt, color) ->
            val lx = left + width - 120f + i * 38f
            badgePaint.color = color
            canvas.drawRect(lx, legendY - 8f, lx + 10f, legendY + 2f, badgePaint)
            canvas.drawText(txt, lx + 13f, legendY, smallPaint)
        }
    }

    val barTop = y
    drawGroupedBarBlock(36f, barTop, 255f, 124f, "Kilo / VKE", listOf(
        "Kilo" to comparison.map { it.second?.weightKg },
        "VKE" to comparison.map { it.second?.bmi }
    ))
    drawGroupedBarBlock(304f, barTop, 255f, 124f, "Yağ / Sıvı", listOf(
        "Yağ" to comparison.map { it.second?.bodyFatPercent },
        "Sıvı" to comparison.map { it.second?.bodyWaterPercent }
    ))
    y = barTop + 136f
    drawGroupedBarBlock(36f, y, 523f, 124f, "KPS / Kemik / İç Yağ", listOf(
        "KPS" to comparison.map { it.second?.let { kotlin.math.abs(it.weightKg - it.muscle) } },
        "Kemik" to comparison.map { it.second?.bone },
        "İç Yağ" to comparison.map { it.second?.visceralFat }
    ))
    y += 138f

    canvas.drawText("Uzman Notu", 36f, y, headerPaint)
    canvas.drawLine(36f, y + 6f, 559f, y + 6f, linePaint)
    y += 18f
    val noteBoxBottom = y + 54f
    canvas.drawRect(36f, y, 559f, noteBoxBottom, linePaint)
    val notes = listOf(
        "Bu rapor ilk kayıt, sondan bir önceki kayıt ve son kayıt üzerinden sütun grafiklerle hazırlanmıştır.",
        content.lines().firstOrNull { it.isNotBlank() && it != it.uppercase() }?.take(84) ?: "Genel değerlendirme: düzenli takip önerilir.",
        latest?.let { "Güncel değerlendirme: ${buildAnalysisSummary(it)}" } ?: "Henüz ölçüm bulunmuyor."
    )
    notes.forEachIndexed { idx, line -> canvas.drawText(line, 42f, y + 16f + idx * 14f, bodyPaint) }

    pdf.finishPage(page)
    val file = File(context.cacheDir, "analiz_raporu_${patient.firstName}_${patient.lastName}.pdf")
    file.outputStream().use { pdf.writeTo(it) }
    pdf.close()
    return file
}

private fun shareFile(context: Context, file: File, patient: PatientEntity, mimeType: String) {
    val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = mimeType
        putExtra(Intent.EXTRA_STREAM, uri)
        putExtra(Intent.EXTRA_SUBJECT, "${patient.firstName} ${patient.lastName} raporu")
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(Intent.createChooser(intent, "Raporu paylaş"))
}

private fun shareBackupFile(context: Context, file: File) {
    val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "application/octet-stream"
        putExtra(Intent.EXTRA_STREAM, uri)
        putExtra(Intent.EXTRA_SUBJECT, "Forever Pro veri yedeği")
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(Intent.createChooser(intent, "Veri yedeğini paylaş"))
}

private fun createDietPdf(
    context: Context,
    patient: PatientEntity,
    measurements: List<MeasurementEntity>,
    supplementSnapshots: Map<String, List<String>>,
    goal: String,
    notes: String,
    trackingStatus: TrackingStatus,
    planQuality: PlanQuality,
    stockAlerts: List<StockAlert>,
    nutritionActions: List<NutritionAction>,
    planActions: List<PlanAction>,
    comparisonInsights: List<PlanComparisonInsight>,
    complianceLogs: List<DailyComplianceEntity>,
    decisionLogs: List<DecisionLogEntity>
): File {
    val pdf = PdfDocument()
    val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
    val page = pdf.startPage(pageInfo)
    val canvas = page.canvas

    val navy = android.graphics.Color.rgb(32, 64, 112)
    val border = android.graphics.Color.rgb(146, 160, 178)
    val soft = android.graphics.Color.rgb(243, 246, 250)
    val green = android.graphics.Color.rgb(116, 154, 66)
    val gray = android.graphics.Color.rgb(145, 152, 164)

    val titlePaint = Paint().apply {
        color = navy
        textSize = 22f
        isFakeBoldText = true
        textAlign = Paint.Align.CENTER
    }
    val headerPaint = Paint().apply {
        color = navy
        textSize = 12f
        isFakeBoldText = true
    }
    val bodyPaint = Paint().apply {
        color = android.graphics.Color.BLACK
        textSize = 10.5f
    }
    val smallPaint = Paint().apply {
        color = android.graphics.Color.DKGRAY
        textSize = 9f
    }
    val linePaint = Paint().apply {
        color = border
        strokeWidth = 1.2f
        style = Paint.Style.STROKE
    }
    val fillPaint = Paint().apply {
        color = soft
        style = Paint.Style.FILL
    }
    val blueBarPaint = Paint().apply { color = navy; style = Paint.Style.FILL }
    val greenBarPaint = Paint().apply { color = green; style = Paint.Style.FILL }
    val grayBarPaint = Paint().apply { color = gray; style = Paint.Style.FILL }

    val latest = measurements.firstOrNull()
    val previous = measurements.getOrNull(1)
    val first = measurements.lastOrNull()
    val comparison = listOf(
        "İlk Kayıt" to first,
        "Sondan Bir Önceki" to previous,
        "Son Kayıt" to latest
    )

    var y = 34f
    canvas.drawText("TAKVİYE RAPORU", 297.5f, y, titlePaint)
    y += 18f
    canvas.drawLine(36f, y, 559f, y, linePaint)
    y += 14f

    val infoTop = y
    val infoBottom = infoTop + 54f
    canvas.drawRect(36f, infoTop, 559f, infoBottom, fillPaint)
    canvas.drawRect(36f, infoTop, 559f, infoBottom, linePaint)
    canvas.drawLine(210f, infoTop, 210f, infoBottom, linePaint)
    canvas.drawLine(360f, infoTop, 360f, infoBottom, linePaint)
    canvas.drawLine(36f, infoTop + 27f, 559f, infoTop + 27f, linePaint)
    canvas.drawText("Danışan", 44f, infoTop + 16f, headerPaint)
    canvas.drawText("${patient.firstName} ${patient.lastName}", 44f, infoTop + 36f, bodyPaint)
    canvas.drawText("Yaş", 218f, infoTop + 16f, headerPaint)
    canvas.drawText(patientAge(patient).toString(), 218f, infoTop + 36f, bodyPaint)
    canvas.drawText("Tarih", 368f, infoTop + 16f, headerPaint)
    canvas.drawText(formatDate(System.currentTimeMillis()), 368f, infoTop + 36f, bodyPaint)
    canvas.drawText("Cinsiyet", 44f, infoTop + 50f, headerPaint)
    canvas.drawText(patient.gender, 108f, infoTop + 50f, bodyPaint)
    canvas.drawText("Hedef", 218f, infoTop + 50f, headerPaint)
    canvas.drawText(goal, 265f, infoTop + 50f, bodyPaint)
    canvas.drawText("Boy", 368f, infoTop + 50f, headerPaint)
    canvas.drawText("${patient.heightCm} cm", 400f, infoTop + 50f, bodyPaint)
    y = infoBottom + 18f

    canvas.drawText("Kompozisyon ve Takip Ozeti", 180f, y, headerPaint)
    canvas.drawLine(36f, y + 6f, 559f, y + 6f, linePaint)
    y += 18f

    val tableLeft = 36f
    val tableTop = y
    val col1 = 160f
    val colWidth = 104f
    val refWidth = 51f
    val rowHeight = 24f
    val tableRight = tableLeft + col1 + colWidth * 3 + refWidth
    val headerBottom = tableTop + 32f

    canvas.drawRect(tableLeft, tableTop, tableRight, headerBottom, fillPaint)
    canvas.drawRect(tableLeft, tableTop, tableRight, headerBottom, linePaint)
    listOf(tableLeft + col1, tableLeft + col1 + colWidth, tableLeft + col1 + colWidth * 2, tableLeft + col1 + colWidth * 3).forEach { x ->
        canvas.drawLine(x, tableTop, x, tableTop + rowHeight * 10, linePaint)
    }
    val labels = comparison.map { it.first }
    labels.forEachIndexed { index, label ->
        val x = tableLeft + col1 + index * colWidth + 8f
        canvas.drawText(label, x, tableTop + 14f, headerPaint)
        val dateText = comparison[index].second?.let { formatDate(it.dateMillis) } ?: "-"
        canvas.drawText(dateText, x, tableTop + 27f, smallPaint)
    }
    canvas.drawText("Ref.", tableRight - refWidth + 8f, tableTop + 18f, headerPaint)

    fun mValue(m: MeasurementEntity?, metric: String): String = when (metric) {
        "Kilo (kg)" -> m?.let { "${it.weightKg.oneDecimal()}" } ?: "-"
        "VKİ" -> m?.let { it.bmi.oneDecimal() } ?: "-"
        "Yağ (%)" -> m?.let { it.bodyFatPercent.oneDecimal() } ?: "-"
        "Sıvı (%)" -> m?.let { it.bodyWaterPercent.oneDecimal() } ?: "-"
        "KPS" -> m?.let { kotlin.math.abs(it.weightKg - it.muscle).oneDecimal() } ?: "-"
        "Aktivite" -> m?.let { it.physicalActivity.oneDecimal() } ?: "-"
        "Kemik" -> m?.let { it.bone.oneDecimal() } ?: "-"
        "Met. Hızı" -> m?.let { it.metabolicRate.oneDecimal() } ?: "-"
        "İç Yağ" -> m?.let { it.visceralFat.oneDecimal() } ?: "-"
        else -> "-"
    }
    val metrics = listOf(
        "Kilo (kg)" to latest?.let { idealWeight(patient.heightCm).oneDecimal() }?.let { "$it" }.orEmpty(),
        "VKİ" to "20-24",
        "Yağ (%)" to "≤27",
        "Sıvı (%)" to "≥55",
        "KPS" to "≤15",
        "Aktivite" to "5",
        "Kemik" to "≥2.7",
        "Met. Hızı" to "≥1600",
        "İç Yağ" to "≤5"
    )
    metrics.forEachIndexed { rowIndex, (metric, ref) ->
        val top = headerBottom + rowHeight * rowIndex
        val bottom = top + rowHeight
        canvas.drawRect(tableLeft, top, tableRight, bottom, linePaint)
        canvas.drawText(metric, tableLeft + 8f, top + 16f, headerPaint)
        comparison.forEachIndexed { colIndex, entry ->
            val x = tableLeft + col1 + colIndex * colWidth + 8f
            canvas.drawText(mValue(entry.second, metric), x, top + 16f, bodyPaint)
        }
        canvas.drawText(ref.take(10), tableRight - refWidth + 4f, top + 16f, smallPaint)
    }
    y = headerBottom + rowHeight * metrics.size + 18f

    canvas.drawText("Fark Grafikleri", 220f, y, headerPaint)
    canvas.drawLine(36f, y + 6f, 559f, y + 6f, linePaint)
    y += 18f

    fun drawBarBlock(left: Float, top: Float, width: Float, height: Float, title: String, values: List<Double?>, maxValue: Double) {
        canvas.drawRect(left, top, left + width, top + height, linePaint)
        canvas.drawText(title, left + 8f, top + 14f, headerPaint)
        val baseY = top + height - 22f
        canvas.drawLine(left + 20f, baseY, left + width - 10f, baseY, linePaint)
        val usableHeight = height - 44f
        val barWidth = 24f
        val gap = 22f
        val colors = listOf(blueBarPaint, grayBarPaint, greenBarPaint)
        values.forEachIndexed { index, value ->
            val normalized = ((value ?: 0.0) / maxValue).coerceIn(0.0, 1.0)
            val barHeight = (usableHeight * normalized).toFloat()
            val barLeft = left + 32f + index * (barWidth + gap)
            val barTop = baseY - barHeight
            canvas.drawRect(barLeft, barTop, barLeft + barWidth, baseY, colors[index])
            canvas.drawText((value?.let { String.format(java.util.Locale.US, "%.1f", it) } ?: "-"), barLeft - 2f, barTop - 4f, smallPaint)
            val shortLabel = when (index) { 0 -> "İlk"; 1 -> "Önceki"; else -> "Son" }
            canvas.drawText(shortLabel, barLeft - 2f, baseY + 14f, smallPaint)
        }
    }

    val barTop = y
    drawBarBlock(36f, barTop, 165f, 128f, "Kilo (kg)", comparison.map { it.second?.weightKg }, kotlin.math.max(100.0, comparison.mapNotNull { it.second?.weightKg }.maxOrNull() ?: 100.0))
    drawBarBlock(215f, barTop, 165f, 128f, "Yağ Oranı (%)", comparison.map { it.second?.bodyFatPercent }, kotlin.math.max(50.0, comparison.mapNotNull { it.second?.bodyFatPercent }.maxOrNull() ?: 50.0))
    drawBarBlock(394f, barTop, 165f, 128f, "Kas", comparison.map { it.second?.muscle }, kotlin.math.max(50.0, comparison.mapNotNull { it.second?.muscle }.maxOrNull() ?: 50.0))
    y = barTop + 145f

    canvas.drawText("Takviye ve Stok Kiyaslamasi", 220f, y, headerPaint)
    canvas.drawLine(36f, y + 6f, 559f, y + 6f, linePaint)
    y += 18f

    val suppTop = y
    val suppColWidth = (559f - 36f) / 3f
    canvas.drawRect(36f, suppTop, 559f, suppTop + 110f, linePaint)
    canvas.drawRect(36f, suppTop, 559f, suppTop + 24f, fillPaint)
    canvas.drawLine(36f + suppColWidth, suppTop, 36f + suppColWidth, suppTop + 110f, linePaint)
    canvas.drawLine(36f + suppColWidth * 2, suppTop, 36f + suppColWidth * 2, suppTop + 110f, linePaint)
    canvas.drawText("İlk Kayıt", 44f, suppTop + 16f, headerPaint)
    canvas.drawText("Önceki Kayıt", 36f + suppColWidth + 8f, suppTop + 16f, headerPaint)
    canvas.drawText("Son Kayıt", 36f + suppColWidth * 2 + 8f, suppTop + 16f, headerPaint)

    listOf("İlk Kayıt", "Önceki Kayıt", "Son Kayıt").forEachIndexed { index, key ->
        val lines = supplementSnapshots[key].orEmpty().ifEmpty { listOf("- Bu analiz kaydı için takviye yok") }
        lines.take(4).forEachIndexed { row, line ->
            val x = 44f + index * suppColWidth
            val lineY = suppTop + 40f + row * 18f
            canvas.drawText("• ${line.take(24)}", x, lineY, smallPaint)
        }
    }
    y = suppTop + 126f

    canvas.drawText("Kurumsal Uzman Notu", 36f, y, headerPaint)
    canvas.drawLine(36f, y + 6f, 559f, y + 6f, linePaint)
    y += 20f
    val noteLines = listOf(
        "Bu rapor ilk kayıt, sondan bir önceki kayıt ve son kayıt üzerinden karşılaştırmalı hazırlanmıştır.",
        if (notes.isBlank()) "Program hedefi: $goal" else notes,
        latest?.let { "Güncel analiz tipi: ${it.analysisMode}" } ?: "Henüz analiz kaydı yok"
    )
    noteLines.forEachIndexed { index, line ->
        canvas.drawText(line.take(92), 40f, y + index * 16f, bodyPaint)
    }

    pdf.finishPage(page)

    val page2 = pdf.startPage(PdfDocument.PageInfo.Builder(595, 842, 2).create())
    val canvas2 = page2.canvas
    var y2 = 38f
    canvas2.drawText("AKILLI PLAN VE TAKIP OZETI", 297.5f, y2, titlePaint)
    y2 += 18f
    canvas2.drawLine(36f, y2, 559f, y2, linePaint)
    y2 += 18f

    fun cleanPdfText(value: String): String = value
        .replace("ğ", "g").replace("Ğ", "G")
        .replace("ü", "u").replace("Ü", "U")
        .replace("ş", "s").replace("Ş", "S")
        .replace("ı", "i").replace("İ", "I")
        .replace("ö", "o").replace("Ö", "O")
        .replace("ç", "c").replace("Ç", "C")

    fun drawSmartSection(title: String, lines: List<String>, maxLines: Int = 5) {
        if (y2 > 780f) return
        canvas2.drawText(cleanPdfText(title), 36f, y2, headerPaint)
        canvas2.drawLine(36f, y2 + 6f, 559f, y2 + 6f, linePaint)
        y2 += 18f
        lines.ifEmpty { listOf("- Kayit yok") }.take(maxLines).forEach { line ->
            canvas2.drawText(cleanPdfText("- ${line.take(92)}"), 42f, y2, bodyPaint)
            y2 += 15f
        }
        y2 += 8f
    }

    val avgCompliance = complianceLogs.take(7).takeIf { it.isNotEmpty() }?.map { compliancePercent(it) }?.average()?.toInt()
    drawSmartSection(
        "Plan Kalite ve Danisan Durumu",
        listOf(
            "Durum: ${trackingStatus.label} - ${trackingStatus.detail}",
            "Plan kalite skoru: %${planQuality.score}",
            "Guc: ${planQuality.strengths.joinToString(", ").ifBlank { "-" }}",
            "Eksik: ${planQuality.missing.joinToString(", ").ifBlank { "-" }}",
            "Uyum ortalamasi: ${avgCompliance?.let { "%$it" } ?: "kayit yok"}"
        ),
        maxLines = 5
    )
    drawSmartSection(
        "Stok Bildirimleri",
        stockAlerts.map { "${it.title}: ${it.detail}" },
        maxLines = 5
    )
    drawSmartSection(
        "Beslenme Aksiyonlari",
        nutritionActions.map { "${it.title}: ${it.detail}" },
        maxLines = 5
    )
    drawSmartSection(
        "Akilli Plan Aksiyonlari",
        planActions.sortedBy { it.priority }.map { "P${it.priority} ${it.title}: ${it.detail}" },
        maxLines = 5
    )
    drawSmartSection(
        "Onceki Plana Gore Yorum",
        comparisonInsights.map { "${it.title}: ${it.detail}" },
        maxLines = 4
    )
    drawSmartSection(
        "Danisman Karar Gunlugu",
        decisionLogs.map { "${formatDate(it.createdAt)} - ${it.title}: ${it.reason} / ${it.action}" },
        maxLines = 5
    )

    pdf.finishPage(page2)
    val file = File(context.cacheDir, "takviye_raporu_${patient.firstName}_${patient.lastName}.pdf")
    file.outputStream().use { pdf.writeTo(it) }
    pdf.close()
    return file
}

private fun idealWeight(heightCm: Int): Double = (22.0 * heightCm * heightCm) / 10000.0

private fun generateDietPlanText(patient: PatientEntity, measurements: List<MeasurementEntity>, goal: String, meals: String, water: String, notes: String, supplements: List<String>): String {
    val latest = measurements.firstOrNull()
    val firstRecord = measurements.lastOrNull()
    val penultimateRecord = measurements.getOrNull(1)
    val bmiLine = latest?.bmi?.oneDecimal() ?: "-"
    val weightLine = latest?.weightKg?.oneDecimal()?.plus(" kg") ?: "-"
    val fatLine = latest?.bodyFatPercent?.oneDecimal()?.plus("%") ?: "-"
    val visceralLine = latest?.visceralFat?.oneDecimal() ?: "-"
    val focus = when (goal) {
        "Kilo Verme" -> "Rafine şeker ve kızartma azaltılır, porsiyon kontrolü güçlendirilir."
        "Kas Koruma" -> "Protein dağılımı güne yayılır, ana öğünlerde kaliteli protein artırılır."
        else -> "Dengeli tabak modeli ve sürdürülebilir beslenme düzeni korunur."
    }
    return buildString {
        appendLine("DANIŞAN ANALİZ VE TAKVİYE PLANI")
        appendLine("Ad Soyad: ${patient.firstName} ${patient.lastName}")
        appendLine("Tarih: ${formatDate(System.currentTimeMillis())}")
        appendLine("Yaş: ${patientAge(patient)}")
        appendLine("Cinsiyet: ${patient.gender}")
        appendLine("Boy: ${patient.heightCm} cm")
        appendLine("Son Kilo: $weightLine")
        appendLine("VKİ: $bmiLine")
        appendLine("Vücut Yağ Oranı: $fatLine")
        appendLine("İç Yağ: $visceralLine")
        appendLine()
        appendLine()
        appendLine("KAYIT KIYASLAMASI")
        listOf(
            "İlk kayıt" to firstRecord,
            "Sondan bir önceki kayıt" to penultimateRecord,
            "Son kayıt" to latest
        ).forEach { (label, record) ->
            if (record != null) {
                appendLine("- $label (${formatDate(record.dateMillis)})")
                appendLine("  • Tip: ${record.analysisMode}")
                appendLine("  • Kilo: ${record.weightKg.oneDecimal()} kg")
                appendLine("  • VKİ: ${record.bmi.oneDecimal()}")
                appendLine("  • Yağ: %${record.bodyFatPercent.oneDecimal()}")
                appendLine("  • Sıvı: %${record.bodyWaterPercent.oneDecimal()}")
                appendLine("  • Kas: ${record.muscle.oneDecimal()}")
            }
        }
        appendLine()
        appendLine("HEDEF")
        appendLine(goal)
        appendLine()
        appendLine("BESLENME PLANLARI")
        appendLine("- $meals")
        appendLine("- Kahvaltıda protein kaynağı, öğle ve akşamda sebze + ana protein dengesi")
        appendLine("- Paketli atıştırmalık yerine yoğurt, kefir, meyve veya çiğ kuruyemiş")
        appendLine("- $water")
        appendLine("- $focus")
        appendLine()
        appendLine("TAKVİYE PLANI")
        if (supplements.isEmpty()) {
            appendLine("- Ek takviye seçilmedi")
        } else {
            supplements.forEach { appendLine("- $it") }
        }
        appendLine()
        appendLine("IZLEME NOTLARI")
        appendLine("- Haftalık kilo ve iştah takibi yapılır")
        appendLine("- Bir sonraki kontrolde önceki ölçümle kıyas önerilir")
        if (notes.isNotBlank()) appendLine("- Uzman notu: $notes")
    }
}



@Composable
private fun SmartDashboardInsightCard(
    todayAppointments: Int,
    weeklyAppointments: Int,
    waitingMeasurements: Int,
    patientCount: Int
) {
    val message = when {
        todayAppointments > 0 -> "Bugün $todayAppointments randevu var. Randevu ekranından hatırlatıcıları kontrol et."
        waitingMeasurements > 0 -> "$waitingMeasurements danışanda son 30 günde ölçüm yok. Takip listesi oluşturulabilir."
        patientCount == 0 -> "İlk danışanı ekleyerek profesyonel takip panelini başlat."
        else -> "Takip düzenli görünüyor. Bu hafta $weeklyAppointments randevu planlanmış."
    }
    ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = Color(0xFF102A24), contentColor = Color.White)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Akıllı Dashboard", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color(0xFF39E58C))
            Text(message, color = Color(0xFFC9D7E3))
        }
    }
}

@Composable
private fun ProfileGoalAndHealthBlock(patient: PatientEntity) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        if (patient.targetWeightKg > 0 || patient.targetBodyFatPercent > 0) {
            Surface(shape = MaterialTheme.shapes.medium, color = MaterialTheme.colorScheme.primaryContainer) {
                Column(Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Hedefler", fontWeight = FontWeight.Bold)
                    Text("Hedef kilo: ${if (patient.targetWeightKg > 0) patient.targetWeightKg.oneDecimal() + " kg" else "-"}")
                    Text("Hedef yağ: ${if (patient.targetBodyFatPercent > 0) "%" + patient.targetBodyFatPercent.oneDecimal() else "-"}")
                }
            }
        }
        val healthLines = listOf(
            "Hastalık geçmişi" to patient.medicalHistory,
            "Alerjiler" to patient.allergies,
            "Kullanılan ilaçlar" to patient.medications,
            "Not" to patient.notes
        ).filter { it.second.isNotBlank() }
        if (healthLines.isNotEmpty()) {
            Surface(shape = MaterialTheme.shapes.medium, color = MaterialTheme.colorScheme.tertiaryContainer) {
                Column(Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Sağlık Bilgileri", fontWeight = FontWeight.Bold)
                    healthLines.forEach { (label, value) -> Text("$label: $value") }
                }
            }
        }
    }
}

@Composable
private fun SmartCoachCard(patient: PatientEntity, measurements: List<MeasurementEntity>) {
    val summary = remember(patient.id, measurements.size) { buildSmartCoachSummary(patient, measurements) }
    val actions = remember(patient.id, measurements.size) { buildSmartCoachActions(patient, measurements) }
    ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = Color(0xFFE3F2FD), contentColor = Color(0xFF0F172A))) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Akıllı Analiz Asistanı", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(summary)
            actions.forEach { Text("• $it") }
        }
    }
}

private fun buildSmartCoachSummary(patient: PatientEntity, measurements: List<MeasurementEntity>): String {
    val sorted = measurements.sortedByDescending { it.dateMillis }
    val latest = sorted.firstOrNull() ?: return "Henüz analiz için yeterli ölçüm yok."
    val last3 = sorted.take(3)
    if (last3.size < 2) return buildAnalysisSummary(latest)
    val newest = last3.first()
    val oldest = last3.last()
    val fatDelta = newest.bodyFatPercent - oldest.bodyFatPercent
    val muscleDelta = newest.muscle - oldest.muscle
    val weightDelta = newest.weightKg - oldest.weightKg
    val targetWeight = patient.targetWeightKg.takeIf { it > 0.0 }
    return when {
        fatDelta < -0.5 && muscleDelta < -0.3 -> "Yağ oranı düşüyor ancak kas değeri de geriliyor. Program kas koruma odağıyla gözden geçirilmeli."
        fatDelta < -0.5 && muscleDelta >= 0.0 -> "Son ölçümlerde yağ oranı düşerken kas korunuyor. Takip olumlu ilerliyor."
        fatDelta > 0.5 -> "Son ölçümlerde yağ oranı yükselme eğiliminde. Beslenme ve aktivite notları yeniden değerlendirilmelidir."
        targetWeight != null && newest.weightKg > targetWeight -> "Kilo hedefinin üzerinde. Düzenli ölçüm ve sürdürülebilir takip önerilir."
        weightDelta < -1.0 && muscleDelta < 0.0 -> "Kilo düşüşü var fakat kas kaybı riski görünüyor. Protein ve direnç egzersizi odağı değerlendirilebilir."
        else -> "Ölçüm trendleri dengeli. Aynı takip periyodu korunabilir."
    }
}

private fun buildSmartCoachActions(patient: PatientEntity, measurements: List<MeasurementEntity>): List<String> {
    val latest = measurements.firstOrNull() ?: return listOf("İlk ölçümü ekleyerek trend analizini başlatın.")
    val actions = mutableListOf<String>()
    if (patient.allergies.isNotBlank()) actions += "Takviye önerilerinde alerji bilgisini mutlaka kontrol edin."
    if (patient.medications.isNotBlank()) actions += "İlaç kullanımı olduğu için takviye planı öncesi notları kontrol edin."
    if (latest.bodyWaterPercent in 1.0..45.0) actions += "Sıvı oranı düşük görünüyor; su tüketimi takibi açılabilir."
    if (latest.visceralFat >= 10.0) actions += "İç yağ değeri için düzenli haftalık takip önerilir."
    if (latest.waistCm > 0.0) actions += "Bel çevresi trendini kilo ve yağ oranı grafiğiyle birlikte izleyin."
    if (actions.isEmpty()) actions += "Mevcut planı koruyup sonraki ölçümde trendi tekrar kontrol edin."
    return actions
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AboutScreen(onBack: () -> Unit) {
    Scaffold(
        topBar = {
            SmallTopAppBar(
                title = { Text("Uygulama Hakkında") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) } }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                    Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Forever Danışan Takip", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        Text("Profesyonel danışan takip, ölçüm karşılaştırma, takviye planı ve paylaşım uygulaması")
                    }
                }
            }
            item {
                ElevatedCard {
                    Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Yapan: Barış Göral", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text("Sürüm: 42.0")
                        Text("Öne çıkanlar: kurumsal dashboard, önceki plana göre akıllı kıyas, akıllı beslenme/plan aksiyonları, akıllı ürün eşleşmesi, ürün görselli takviye planı, stok/bitme uyarıları, klinik ölçüm özeti, profesyonel trend grafikleri, PDF/WhatsApp paylaşımı, randevu takibi ve yerel DB yedeği.")
                    }
                }
            }
            item {
                ElevatedCard {
                    Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Sonraki geliştirmeler", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text("• Klinik/profil ayarları\n• PDF kurum logosu\n• Çoklu uzman profili\n• Gelişmiş grafik karşılaştırmaları\n• Güvenli bulut senkronizasyonu")
                    }
                }
            }
        }
    }
}

private fun saveBitmapToCache(context: Context, bitmap: Bitmap): Uri? {
    return runCatching {
        val file = File(context.cacheDir, "camera_${System.currentTimeMillis()}.jpg")
        FileOutputStream(file).use { out ->
            bitmap.compress(Bitmap.CompressFormat.JPEG, 92, out)
        }
        Uri.fromFile(file)
    }.getOrNull()
}

@Composable
fun QuickActionCard(
    title: String,
    icon: ImageVector,
    modifier: Modifier = Modifier,
    iconContainerColor: Color = MaterialTheme.colorScheme.primaryContainer,
    iconTint: Color = MaterialTheme.colorScheme.primary,
    onClick: () -> Unit
) {
    ElevatedCard(
        modifier = modifier.clickable(onClick = onClick),
        colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(
            Modifier.fillMaxWidth().padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            IconBadge(
                icon = icon,
                size = 52.dp,
                containerColor = iconContainerColor,
                iconTint = iconTint
            )
            Text(title, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun IconBadge(
    icon: ImageVector,
    size: androidx.compose.ui.unit.Dp = 40.dp,
    containerColor: Color = MaterialTheme.colorScheme.primaryContainer,
    iconTint: Color = MaterialTheme.colorScheme.primary
) {
    Surface(
        modifier = Modifier.size(size),
        shape = CircleShape,
        color = containerColor,
    ) {
        Box(contentAlignment = Alignment.Center) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = iconTint,
                modifier = Modifier.size(size * 0.5f)
            )
        }
    }
}

@Composable
private fun FormLeadingIcon(
    icon: ImageVector,
    containerColor: Color = MaterialTheme.colorScheme.primaryContainer,
    iconTint: Color = MaterialTheme.colorScheme.primary
) {
    IconBadge(icon = icon, size = 34.dp, containerColor = containerColor, iconTint = iconTint)
}

@Composable
fun TrendChartCard(measurements: List<MeasurementEntity>) {
    if (measurements.size < 2) return
    val latestThree = measurements.sortedBy { it.dateMillis }.takeLast(3)
    val labels = listOf("İlk", "Önceki", "Son").takeLast(latestThree.size)
    ElevatedCard {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Değişim Grafikleri", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text("Son üç kayıt sütun grafik olarak gösterilir")
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                MiniBarChartCard(
                    title = "Kilo (kg)",
                    values = latestThree.map { it.weightKg },
                    labels = labels,
                    modifier = Modifier.weight(1f)
                )
                MiniBarChartCard(
                    title = "Yağ Oranı (%)",
                    values = latestThree.map { it.bodyFatPercent },
                    labels = labels,
                    modifier = Modifier.weight(1f)
                )
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                MiniBarChartCard(
                    title = "Sıvı Oranı (%)",
                    values = latestThree.map { it.bodyWaterPercent },
                    labels = labels,
                    modifier = Modifier.weight(1f)
                )
                MiniBarChartCard(
                    title = "KPS",
                    values = latestThree.map { kotlin.math.abs(it.weightKg - it.muscle) },
                    labels = labels,
                    modifier = Modifier.weight(1f)
                )
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                MiniBarChartCard(
                    title = "Kemik",
                    values = latestThree.map { it.bone },
                    labels = labels,
                    modifier = Modifier.weight(1f)
                )
                MiniBarChartCard(
                    title = "İç Yağ",
                    values = latestThree.map { it.visceralFat },
                    labels = labels,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
fun PatientPhotoCard(photoUri: String?, onCamera: () -> Unit, onGallery: () -> Unit) {
    ElevatedCard {
        Column(Modifier.fillMaxWidth().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Surface(modifier = Modifier.height(150.dp).fillMaxWidth(), shape = MaterialTheme.shapes.large, color = MaterialTheme.colorScheme.surfaceVariant) {
                if (photoUri != null) {
                    AsyncImage(model = photoUri, contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                } else {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) { IconBadge(icon = Icons.Default.Person, size = 56.dp); Text("Danışan fotoğrafı") } }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onCamera) { Icon(Icons.Default.CameraAlt, null, tint = Color(0xFF1565C0)); Spacer(Modifier.size(6.dp)); Text("Kamera") }
                OutlinedButton(onClick = onGallery) { Icon(Icons.Default.PhotoLibrary, null, tint = Color(0xFF2E7D32)); Spacer(Modifier.size(6.dp)); Text("Galeri") }
            }
        }
    }
}

@Composable
fun NumericField(label: String, value: String, onValue: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = { onValue(it.filter { ch -> ch.isDigit() || ch == '.' || ch == ',' }.replace(',', '.')) },
        modifier = Modifier.fillMaxWidth(),
        label = { Text(label) },
        leadingIcon = { FormLeadingIcon(Icons.Default.QueryStats, containerColor = Color(0xFFE3F2FD), iconTint = Color(0xFF1565C0)) },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        singleLine = true
    )
}

@Composable
fun DateField(label: String, value: String, onClick: () -> Unit) {
    OutlinedButton(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                FormLeadingIcon(Icons.Default.CalendarMonth, containerColor = Color(0xFFFFF8E1), iconTint = Color(0xFFE69500))
                Text(label)
            }
            Text(value)
        }
    }
}

@Composable
fun MiniBarChartCard(
    title: String,
    values: List<Double>,
    labels: List<String>,
    modifier: Modifier = Modifier
) {
    val barColors = listOf(Color(0xFF4F7CAC), Color(0xFF95A5A6), Color(0xFF6A994E))
    val bgColor = MaterialTheme.colorScheme.surfaceVariant
    ElevatedCard(modifier = modifier) {
        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Canvas(modifier = Modifier.fillMaxWidth().height(140.dp).background(bgColor, MaterialTheme.shapes.medium)) {
                val maxValue = (values.maxOrNull() ?: 1.0).toFloat().coerceAtLeast(1f)
                val chartHeight = size.height - 28f
                val chartBottom = size.height - 18f
                val groupWidth = size.width / values.size.coerceAtLeast(1)
                drawLine(Color.Gray.copy(alpha = 0.25f), Offset(0f, chartBottom), Offset(size.width, chartBottom), strokeWidth = 2f)
                values.forEachIndexed { index, value ->
                    val barWidth = groupWidth * 0.42f
                    val left = groupWidth * index + (groupWidth - barWidth) / 2f
                    val barHeight = ((value.toFloat() / maxValue) * chartHeight).coerceIn(0f, chartHeight)
                    val top = chartBottom - barHeight
                    drawRect(color = barColors.getOrElse(index) { barColors.last() }, topLeft = Offset(left, top), size = androidx.compose.ui.geometry.Size(barWidth, barHeight))
                    drawContext.canvas.nativeCanvas.drawText(String.format(java.util.Locale.US, "%.1f", value), left, top - 6f, android.graphics.Paint().apply {
                        color = android.graphics.Color.DKGRAY
                        textSize = 24f
                        isAntiAlias = true
                    })
                    drawContext.canvas.nativeCanvas.drawText(labels.getOrElse(index) { "" }, left, size.height - 2f, android.graphics.Paint().apply {
                        color = android.graphics.Color.DKGRAY
                        textSize = 24f
                        isAntiAlias = true
                    })
                }
            }
        }
    }
}


@Composable
fun ReferenceStatusCard(title: String, status: ReferenceStatus) {
    val container = when (status.level) {
        ReferenceLevel.NORMAL -> MaterialTheme.colorScheme.secondaryContainer
        ReferenceLevel.LOW -> MaterialTheme.colorScheme.tertiaryContainer
        ReferenceLevel.HIGH -> MaterialTheme.colorScheme.errorContainer
        ReferenceLevel.INFO -> MaterialTheme.colorScheme.primaryContainer
    }
    ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = container)) {
        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text("Referans: ${status.rangeLabel}")
            Text(status.statusText, fontWeight = FontWeight.Bold)
            if (status.detail.isNotBlank()) {
                Text(status.detail, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ModernDatePicker(initial: Long, title: String, onDismiss: () -> Unit, onConfirm: (Long) -> Unit) {
    val state = rememberDatePickerState(initialSelectedDateMillis = initial)
    DatePickerDialog(onDismissRequest = onDismiss, confirmButton = { TextButton(onClick = { onConfirm(state.selectedDateMillis ?: initial) }) { Text("Tamam") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("İptal") } }) {
        Column {
            Text(title, modifier = Modifier.padding(16.dp), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            DatePicker(state = state)
        }
    }
}


private fun referenceForMetric(label: String, value: Double, patient: PatientEntity, measurement: MeasurementEntity): ReferenceStatus {
    val age = patientAge(patient)
    return when (label) {
        "Kilo" -> weightReferenceStatus(value, patient.heightCm)
        "VKİ" -> bmiReferenceStatus(value)
        "Yağ" -> bodyFatReferenceStatus(patient.gender, age, value)
        "Sıvı" -> bodyWaterReferenceStatus(patient.gender, value)
        "Kas" -> kpsReferenceStatus(measurement.weightKg, measurement.muscle)
        "Aktivite" -> activityReferenceStatus(value)
        "Kemik" -> boneReferenceStatus(patient.gender, value)
        "Met. Hızı" -> metabolicRateReferenceStatus(patient.gender, age, patient.heightCm, measurement.weightKg, value)
        "Met. Yaşı" -> metabolicAgeReferenceStatus(age, value.toInt())
        "İç Yağ" -> visceralFatReferenceStatus(value)
        else -> ReferenceStatus("Kişiye göre değişir", "Takip amaçlı gösterim", ReferenceLevel.INFO)
    }
}

@Composable
fun MeasurementLivePreviewCard(
    patient: PatientEntity,
    bmi: Double,
    weight: Double,
    fat: Double,
    water: Double,
    muscle: Double,
    visceral: Double
) {
    val age = patientAge(patient)
    val kps = kotlin.math.abs(weight - muscle)
    val focus = when {
        weight <= 0.0 -> "Kilo girildiğinde analiz önizlemesi netleşir."
        visceral >= 10.0 -> "İç yağ yüksek görünüyor; takip planı sıklaştırılabilir."
        fat >= 30.0 -> "Yağ oranı odağıyla takviye ve beslenme planı hazırlanmalı."
        water in 1.0..49.9 -> "Sıvı oranı düşük; su planı görünür olmalı."
        kps >= 20.0 -> "Kilo-kas farkı yüksek; kompozisyon takibi önemli."
        else -> "Ölçüm dengeli görünüyor; trend takibi yeterli olabilir."
    }
    ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = Color(0xFF0F1B2B), contentColor = Color.White)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Canlı Analiz Önizlemesi", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color(0xFF39E58C))
            Text(focus, color = Color(0xFFC9D7E3))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                ClinicalMetricTile("VKİ", bmi.oneDecimal(), bmiReferenceStatus(bmi).statusText, null, bmiReferenceStatus(bmi).level, Modifier.weight(1f))
                ClinicalMetricTile("Yağ", "%${fat.oneDecimal()}", bodyFatReferenceStatus(patient.gender, age, fat).statusText, null, bodyFatReferenceStatus(patient.gender, age, fat).level, Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                ClinicalMetricTile("Sıvı", "%${water.oneDecimal()}", bodyWaterReferenceStatus(patient.gender, water).statusText, null, bodyWaterReferenceStatus(patient.gender, water).level, Modifier.weight(1f))
                ClinicalMetricTile("KPS", kps.oneDecimal(), kpsReferenceStatus(weight, muscle).statusText, null, kpsReferenceStatus(weight, muscle).level, Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                ClinicalMetricTile("İç Yağ", visceral.oneDecimal(), visceralFatReferenceStatus(visceral).statusText, null, visceralFatReferenceStatus(visceral).level, Modifier.weight(1f))
                ClinicalMetricTile("Hedef Kilo", idealWeight(patient.heightCm).oneDecimal(), "Boy bilgisine göre", null, ReferenceLevel.INFO, Modifier.weight(1f))
            }
        }
    }
}

@Composable
fun ProfessionalAnalysisReportCard(
    patient: PatientEntity,
    latest: MeasurementEntity,
    previous: MeasurementEntity?,
    previousMonth: MeasurementEntity?,
    measurements: List<MeasurementEntity>
) {
    val age = patientAge(patient)
    val targetWeight = patient.targetWeightKg.takeIf { it > 0.0 } ?: ((22.0 * patient.heightCm * patient.heightCm) / 10000.0)
    val weightDelta = latest.weightKg - targetWeight
    val obesityDegree = if (targetWeight > 0) ((latest.weightKg / targetWeight) * 100.0) else 0.0
    val infoColor = MaterialTheme.colorScheme.onSurfaceVariant

    ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = Color(0xFFFDFCF8), contentColor = Color(0xFF0F172A))) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Vücut Analiz Raporu", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Surface(shape = MaterialTheme.shapes.medium, color = MaterialTheme.colorScheme.primaryContainer) {
                Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("${patient.firstName} ${patient.lastName}", fontWeight = FontWeight.Bold)
                    Text("${patient.gender} • $age yaş • ${patient.heightCm} cm", color = infoColor)
                    Text("Ölçüm tarihi: ${formatDate(latest.dateMillis)}", color = infoColor)
                }
            }

            ReportSection(title = "Genel Özet") {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    ReportMiniStat("Kilo", "${latest.weightKg.oneDecimal()} kg", Modifier.weight(1f))
                    ReportMiniStat("VKİ", latest.bmi.oneDecimal(), Modifier.weight(1f))
                    ReportMiniStat("Met. Yaş", latest.metabolicAge.toString(), Modifier.weight(1f))
                }
            }

            ReportSection(title = "Vücut Kompozisyonu") {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    AnalysisProgressRow("Kilo", latest.weightKg.oneDecimal(), 0f, 150f, "kg")
                    AnalysisProgressRow("Yağ", latest.bodyFatPercent.oneDecimal(), 0f, 50f, "%")
                    AnalysisProgressRow("Sıvı", latest.bodyWaterPercent.oneDecimal(), 0f, 80f, "%")
                    AnalysisProgressRow("KPS", kotlin.math.abs(latest.weightKg - latest.muscle).oneDecimal(), 0f, 30f, "")
                    AnalysisProgressRow("Kemik", latest.bone.oneDecimal(), 0f, 10f, "kg")
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                ReportSection(title = "Hedef Kilo Kontrolü", modifier = Modifier.weight(1f)) {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        ReportKeyValueRow("Mevcut kilo", "${latest.weightKg.oneDecimal()} kg")
                        ReportKeyValueRow("İdeal kilo", "${targetWeight.oneDecimal()} kg")
                        ReportKeyValueRow("Fark", "${weightDelta.oneDecimal()} kg")
                        ReportKeyValueRow("Obezite derecesi", "%${obesityDegree.oneDecimal()}")
                    }
                }
                ReportSection(title = "Metabolik Yorum", modifier = Modifier.weight(1f)) {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        ReportKeyValueRow("BMR", "${latest.metabolicRate.oneDecimal()} kcal")
                        ReportKeyValueRow("Aktivite", latest.physicalActivity.oneDecimal())
                        ReportKeyValueRow("İç yağ", latest.visceralFat.oneDecimal())
                        ReportKeyValueRow("Bel", if (latest.waistCm > 0) "${latest.waistCm.oneDecimal()} cm" else "-")
                        ReportKeyValueRow("Durum", buildSmartCoachSummary(patient, measurements))
                    }
                }
            }

            ReportSection(title = "Referans Analizi") {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    ReferenceSummaryRow("VKİ", bmiReferenceStatus(latest.bmi))
                    ReferenceSummaryRow("Yağ", bodyFatReferenceStatus(patient.gender, age, latest.bodyFatPercent))
                    ReferenceSummaryRow("Sıvı", bodyWaterReferenceStatus(patient.gender, latest.bodyWaterPercent))
                    ReferenceSummaryRow("KPS", kpsReferenceStatus(latest.weightKg, latest.muscle))
                    ReferenceSummaryRow("Aktivite", activityReferenceStatus(latest.physicalActivity))
                    ReferenceSummaryRow("Kemik", boneReferenceStatus(patient.gender, latest.bone))
                    ReferenceSummaryRow("Met. Hızı", metabolicRateReferenceStatus(patient.gender, age, patient.heightCm, latest.weightKg, latest.metabolicRate))
                    ReferenceSummaryRow("İç Yağ", visceralFatReferenceStatus(latest.visceralFat))
                }
            }

            ReportSection(title = "Fark Analizi") {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    DifferenceRow("Önceki kayıt", latest, previous)
                    DifferenceRow("Önceki ay", latest, previousMonth)
                    DifferenceRow("İlk kayıt", latest, measurements.lastOrNull())
                }
            }

            if (measurements.size >= 2) {
                ReportSection(title = "Fark Grafiği") {
                    TrendChartCard(measurements.take(6))
                }
            }
        }
    }
}

private fun buildAnalysisSummary(latest: MeasurementEntity): String {
    return when {
        latest.bodyFatPercent >= 30.0 -> "Yağ kontrolü odağı"
        latest.bodyWaterPercent <= 45.0 -> "Sıvı desteği odağı"
        latest.visceralFat >= 10.0 -> "İç yağ takibi gerekli"
        else -> "Dengeli görünüm"
    }
}

@Composable
fun ClinicalAnalysisDashboard(
    patient: PatientEntity,
    latest: MeasurementEntity,
    previous: MeasurementEntity?,
    measurements: List<MeasurementEntity>
) {
    val age = patientAge(patient)
    val targetWeight = patient.targetWeightKg.takeIf { it > 0.0 } ?: idealWeight(patient.heightCm)
    val targetFat = patient.targetBodyFatPercent.takeIf { it > 0.0 } ?: 27.0
    val weightGap = latest.weightKg - targetWeight
    val fatGap = latest.bodyFatPercent - targetFat
    val waterStatus = bodyWaterReferenceStatus(patient.gender, latest.bodyWaterPercent)
    val fatStatus = bodyFatReferenceStatus(patient.gender, age, latest.bodyFatPercent)
    val bmiStatus = bmiReferenceStatus(latest.bmi)
    val visceralStatus = visceralFatReferenceStatus(latest.visceralFat)
    val focus = when {
        latest.visceralFat >= 10.0 -> "İç yağ ve bel çevresi öncelikli takip edilmeli."
        latest.bodyFatPercent > targetFat -> "Yağ oranı hedefin üzerinde; takviye ve öğün planı buna göre düzenlenmeli."
        latest.bodyWaterPercent < 50.0 -> "Sıvı oranı düşük; su planı ve takip sıklığı artırılmalı."
        kotlin.math.abs(weightGap) <= 2.0 && fatGap <= 0.0 -> "Hedefe yakın görünüm; mevcut plan korunup trend izlenebilir."
        else -> buildSmartCoachSummary(patient, measurements)
    }

    ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = Color(0xFF0B1828), contentColor = Color.White)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Top) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Klinik Ölçüm Özeti", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Color(0xFF39E58C))
                    Text("Son ölçüm: ${formatDate(latest.dateMillis)} • ${latest.analysisMode}", color = Color(0xFFC9D7E3))
                }
                Surface(shape = MaterialTheme.shapes.large, color = Color(0xFF132238)) {
                    Text("Odak", Modifier.padding(horizontal = 12.dp, vertical = 8.dp), fontWeight = FontWeight.Bold, color = Color(0xFF93C5FD))
                }
            }
            Text(focus, color = Color.White, fontWeight = FontWeight.SemiBold)

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                ClinicalMetricTile(
                    label = "Kilo",
                    value = "${latest.weightKg.oneDecimal()} kg",
                    sub = "Hedef ${targetWeight.oneDecimal()} kg",
                    delta = previous?.let { deltaText(latest.weightKg, it.weightKg, "kg") },
                    level = weightReferenceStatus(latest.weightKg, patient.heightCm).level,
                    modifier = Modifier.weight(1f)
                )
                ClinicalMetricTile(
                    label = "Yağ",
                    value = "%${latest.bodyFatPercent.oneDecimal()}",
                    sub = "Hedef ≤ %${targetFat.oneDecimal()}",
                    delta = previous?.let { deltaText(latest.bodyFatPercent, it.bodyFatPercent, "%") },
                    level = fatStatus.level,
                    modifier = Modifier.weight(1f)
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                ClinicalMetricTile(
                    label = "Sıvı",
                    value = "%${latest.bodyWaterPercent.oneDecimal()}",
                    sub = waterStatus.statusText,
                    delta = previous?.let { deltaText(latest.bodyWaterPercent, it.bodyWaterPercent, "%") },
                    level = waterStatus.level,
                    modifier = Modifier.weight(1f)
                )
                ClinicalMetricTile(
                    label = "VKİ",
                    value = latest.bmi.oneDecimal(),
                    sub = bmiStatus.rangeLabel,
                    delta = previous?.let { deltaText(latest.bmi, it.bmi, "") },
                    level = bmiStatus.level,
                    modifier = Modifier.weight(1f)
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                ClinicalMetricTile(
                    label = "Bel",
                    value = if (latest.waistCm > 0.0) "${latest.waistCm.oneDecimal()} cm" else "-",
                    sub = "Trend takibi",
                    delta = previous?.takeIf { latest.waistCm > 0.0 && it.waistCm > 0.0 }?.let { deltaText(latest.waistCm, it.waistCm, "cm") },
                    level = ReferenceLevel.INFO,
                    modifier = Modifier.weight(1f)
                )
                ClinicalMetricTile(
                    label = "İç Yağ",
                    value = latest.visceralFat.oneDecimal(),
                    sub = visceralStatus.statusText,
                    delta = previous?.let { deltaText(latest.visceralFat, it.visceralFat, "") },
                    level = visceralStatus.level,
                    modifier = Modifier.weight(1f)
                )
            }
            if (measurements.size >= 2) {
                TrendLineCard(
                    title = "Kilo / Yağ / Sıvı Trend",
                    measurements = measurements,
                    series = listOf(
                        "Kilo" to measurements.sortedBy { it.dateMillis }.takeLast(6).map { it.weightKg },
                        "Yağ" to measurements.sortedBy { it.dateMillis }.takeLast(6).map { it.bodyFatPercent },
                        "Sıvı" to measurements.sortedBy { it.dateMillis }.takeLast(6).map { it.bodyWaterPercent }
                    )
                )
            }
        }
    }
}

@Composable
fun ClinicalMetricTile(
    label: String,
    value: String,
    sub: String,
    delta: String?,
    level: ReferenceLevel,
    modifier: Modifier = Modifier
) {
    val accent = when (level) {
        ReferenceLevel.NORMAL -> Color(0xFF39E58C)
        ReferenceLevel.LOW -> Color(0xFF93C5FD)
        ReferenceLevel.HIGH -> Color(0xFFFF7A7A)
        ReferenceLevel.INFO -> Color(0xFFBFA7FF)
    }
    Surface(modifier = modifier, shape = MaterialTheme.shapes.large, color = Color(0xFF101F31)) {
        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(label, color = Color(0xFF9FB4C7), style = MaterialTheme.typography.labelMedium)
            Text(value, color = Color.White, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text(sub, color = Color(0xFFC9D7E3), style = MaterialTheme.typography.bodySmall)
            if (!delta.isNullOrBlank()) {
                Text(delta, color = accent, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
fun TrendLineCard(
    title: String,
    measurements: List<MeasurementEntity>,
    series: List<Pair<String, List<Double>>>
) {
    val colors = listOf(Color(0xFF39E58C), Color(0xFFFF7A7A), Color(0xFF93C5FD))
    val labels = measurements.sortedBy { it.dateMillis }.takeLast(6).map { formatDate(it.dateMillis).substringBeforeLast("/") }
    Surface(shape = MaterialTheme.shapes.large, color = Color(0xFF101F31)) {
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, fontWeight = FontWeight.Bold, color = Color.White)
            Canvas(modifier = Modifier.fillMaxWidth().height(170.dp)) {
                val allValues = series.flatMap { it.second }
                val minValue = (allValues.minOrNull() ?: 0.0).toFloat()
                val maxValue = (allValues.maxOrNull() ?: 1.0).toFloat()
                val range = (maxValue - minValue).takeIf { it > 0f } ?: 1f
                val leftPad = 12f
                val rightPad = 12f
                val topPad = 12f
                val bottomPad = 28f
                val chartWidth = size.width - leftPad - rightPad
                val chartHeight = size.height - topPad - bottomPad
                repeat(4) { index ->
                    val y = topPad + chartHeight * index / 3f
                    drawLine(Color.White.copy(alpha = 0.10f), Offset(leftPad, y), Offset(leftPad + chartWidth, y), strokeWidth = 1.3f)
                }
                series.forEachIndexed { sIndex, (_, values) ->
                    val points = values.mapIndexed { index, value ->
                        val x = leftPad + if (values.size <= 1) 0f else chartWidth * index / (values.size - 1)
                        val normalized = ((value.toFloat() - minValue) / range).coerceIn(0f, 1f)
                        val y = topPad + chartHeight - normalized * chartHeight
                        Offset(x, y)
                    }
                    points.zipWithNext().forEach { (a, b) ->
                        drawLine(colors.getOrElse(sIndex) { Color.White }, a, b, strokeWidth = 4f, cap = StrokeCap.Round)
                    }
                    points.forEach { point ->
                        drawCircle(colors.getOrElse(sIndex) { Color.White }, radius = 4.5f, center = point)
                    }
                }
                labels.forEachIndexed { index, label ->
                    val x = leftPad + if (labels.size <= 1) 0f else chartWidth * index / (labels.size - 1)
                    drawContext.canvas.nativeCanvas.drawText(label, x - 10f, size.height - 6f, android.graphics.Paint().apply {
                        color = android.graphics.Color.LTGRAY
                        textSize = 20f
                        isAntiAlias = true
                    })
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                series.forEachIndexed { index, item ->
                    Surface(shape = MaterialTheme.shapes.medium, color = colors.getOrElse(index) { Color.White }.copy(alpha = 0.16f)) {
                        Text(item.first, Modifier.padding(horizontal = 10.dp, vertical = 6.dp), color = colors.getOrElse(index) { Color.White }, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun ReportSection(title: String, modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    ElevatedCard(modifier = modifier, colors = CardDefaults.elevatedCardColors(containerColor = Color.White, contentColor = Color(0xFF0F172A))) {
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, fontWeight = FontWeight.Bold, color = Color(0xFF264653))
            content()
        }
    }
}

@Composable
fun ReportMiniStat(label: String, value: String, modifier: Modifier = Modifier) {
    Surface(modifier = modifier, shape = MaterialTheme.shapes.medium, color = MaterialTheme.colorScheme.secondaryContainer) {
        Column(Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(label, style = MaterialTheme.typography.labelMedium)
            Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun ReportKeyValueRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = Color(0xFFC9D7E3))
        Text(value, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun AnalysisProgressRow(label: String, value: String, min: Float, max: Float, unit: String) {
    val numeric = value.toFloatOrNull() ?: 0f
    val progress = ((numeric - min) / (max - min)).coerceIn(0f, 1f)
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label)
            Text("$value${if (unit.isNotBlank()) " $unit" else ""}", fontWeight = FontWeight.SemiBold)
        }
        Canvas(modifier = Modifier.fillMaxWidth().height(14.dp)) {
            drawRect(color = Color(0xFFE6ECF1))
            drawRect(color = Color(0xFF5B8DEF), size = androidx.compose.ui.geometry.Size(size.width * progress, size.height))
        }
    }
}

@Composable
fun ReferenceSummaryRow(label: String, status: ReferenceStatus) {
    Surface(shape = MaterialTheme.shapes.medium, color = when (status.level) {
        ReferenceLevel.NORMAL -> Color(0xFFE8F5E9)
        ReferenceLevel.LOW -> Color(0xFFE3F2FD)
        ReferenceLevel.HIGH -> Color(0xFFFFEBEE)
        ReferenceLevel.INFO -> MaterialTheme.colorScheme.secondaryContainer
    }) {
        Column(Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(label, fontWeight = FontWeight.SemiBold)
            Text(status.statusText)
            Text("Referans: ${status.rangeLabel}", style = MaterialTheme.typography.bodySmall, color = Color(0xFFC9D7E3))
        }
    }
}

@Composable
fun DifferenceRow(label: String, latest: MeasurementEntity, base: MeasurementEntity?) {
    val weightText = base?.let { (latest.weightKg - it.weightKg).oneDecimal() + " kg" } ?: "-"
    val fatText = base?.let { (latest.bodyFatPercent - it.bodyFatPercent).oneDecimal() + " %" } ?: "-"
    val waterText = base?.let { (latest.bodyWaterPercent - it.bodyWaterPercent).oneDecimal() + " %" } ?: "-"
    val muscleText = base?.let { (latest.muscle - it.muscle).oneDecimal() } ?: "-"
    Surface(shape = MaterialTheme.shapes.medium, color = MaterialTheme.colorScheme.surfaceVariant) {
        Column(Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(label, fontWeight = FontWeight.Bold)
            Text("Kilo: $weightText  •  Yağ: $fatText")
            Text("Sıvı: $waterText  •  Kas: $muscleText")
        }
    }
}

@Composable
fun ComparisonOverview(latest: MeasurementEntity, previous: MeasurementEntity?, previousMonth: MeasurementEntity?, olderMeasurements: List<MeasurementEntity>) {
    val average = olderMeasurements.takeIf { it.isNotEmpty() }?.let { list ->
        MeasurementEntity(
            patientId = latest.patientId,
            dateMillis = list.last().dateMillis,
            weightKg = list.map { it.weightKg }.average(),
            bmi = list.map { it.bmi }.average(),
            bodyFatPercent = list.map { it.bodyFatPercent }.average(),
            bodyWaterPercent = list.map { it.bodyWaterPercent }.average(),
            muscle = list.map { it.muscle }.average(),
            physicalActivity = list.map { it.physicalActivity }.average(),
            bone = list.map { it.bone }.average(),
            metabolicRate = list.map { it.metabolicRate }.average(),
            metabolicAge = list.map { it.metabolicAge }.average().toInt(),
            visceralFat = list.map { it.visceralFat }.average()
        )
    }
    ElevatedCard {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Detaylı Kıyas Özeti", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text("Son ölçüm: ${formatDate(latest.dateMillis)}")
            HorizontalDivider()
            MetricComparisonRow("Kilo", latest.weightKg, "kg", previous?.weightKg, previousMonth?.weightKg, average?.weightKg)
            MetricComparisonRow("VKİ", latest.bmi, "", previous?.bmi, previousMonth?.bmi, average?.bmi)
            MetricComparisonRow("Yağ", latest.bodyFatPercent, "%", previous?.bodyFatPercent, previousMonth?.bodyFatPercent, average?.bodyFatPercent)
            MetricComparisonRow("Sıvı", latest.bodyWaterPercent, "%", previous?.bodyWaterPercent, previousMonth?.bodyWaterPercent, average?.bodyWaterPercent)
            MetricComparisonRow("Kas", latest.muscle, "", previous?.muscle, previousMonth?.muscle, average?.muscle)
            MetricComparisonRow("Aktivite", latest.physicalActivity, "", previous?.physicalActivity, previousMonth?.physicalActivity, average?.physicalActivity)
            MetricComparisonRow("Kemik", latest.bone, "", previous?.bone, previousMonth?.bone, average?.bone)
            MetricComparisonRow("KPS", kotlin.math.abs(latest.weightKg - latest.muscle), "", previous?.let { kotlin.math.abs(it.weightKg - it.muscle) }, previousMonth?.let { kotlin.math.abs(it.weightKg - it.muscle) }, average?.let { kotlin.math.abs(it.weightKg - it.muscle) })
            MetricComparisonRow("Met. Hızı", latest.metabolicRate, "", previous?.metabolicRate, previousMonth?.metabolicRate, average?.metabolicRate)
            MetricComparisonRow("İç Yağ", latest.visceralFat, "", previous?.visceralFat, previousMonth?.visceralFat, average?.visceralFat)
        }
    }
}

@Composable
fun MetricComparisonRow(label: String, current: Double, unit: String, previous: Double?, previousMonth: Double?, averagePrevious: Double?) {
    ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(label, fontWeight = FontWeight.Bold)
            Text("Güncel: ${current.oneDecimal()}${if (unit.isNotBlank()) " $unit" else ""}", style = MaterialTheme.typography.titleMedium)
            Text("Önceki kayıt: ${previous?.let { deltaText(current, it, unit).ifBlank { current.oneDecimal() } } ?: "Yok"}")
            Text("Önceki ay: ${previousMonth?.let { deltaText(current, it, unit).ifBlank { current.oneDecimal() } } ?: "Yok"}")
            Text("Tüm önceki kayıt ort.: ${averagePrevious?.let { deltaText(current, it, unit).ifBlank { current.oneDecimal() } } ?: "Yok"}")
        }
    }
}

@Composable
fun MetricChartsSection(measurements: List<MeasurementEntity>) {
    if (measurements.size < 2) return
    val recent = measurements.sortedBy { it.dateMillis }.takeLast(6)
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Profesyonel Trend Grafikleri", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        TrendLineCard(
            title = "Ana Vücut Kompozisyonu",
            measurements = recent,
            series = listOf(
                "Kilo" to recent.map { it.weightKg },
                "Yağ" to recent.map { it.bodyFatPercent },
                "Sıvı" to recent.map { it.bodyWaterPercent }
            )
        )
        TrendLineCard(
            title = "Kas / Bel / KPS Takibi",
            measurements = recent,
            series = listOf(
                "Kas" to recent.map { it.muscle },
                "Bel" to recent.map { it.waistCm.takeIf { waist -> waist > 0.0 } ?: 0.0 },
                "KPS" to recent.map { kotlin.math.abs(it.weightKg - it.muscle) }
            )
        )
        TrendLineCard(
            title = "Metabolik Risk Göstergeleri",
            measurements = recent,
            series = listOf(
                "İç Yağ" to recent.map { it.visceralFat },
                "Aktivite" to recent.map { it.physicalActivity },
                "Kemik" to recent.map { it.bone }
            )
        )
    }
}

@Composable
fun SimpleMetricChartCard(title: String, measurements: List<MeasurementEntity>, metric: (MeasurementEntity) -> Double) {
    val points = measurements.sortedBy { it.dateMillis }.takeLast(3).map(metric)
    if (points.size < 2) return
    MiniBarChartCard(
        title = title,
        values = points,
        labels = listOf("İlk", "Önceki", "Son").takeLast(points.size),
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
fun MetricGrid(patient: PatientEntity, m: MeasurementEntity) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Ölçüm Kartları ve Referans", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        val items = listOf(
            Triple("Kilo", m.weightKg, "kg"),
            Triple("VKİ", m.bmi, ""),
            Triple("Yağ", m.bodyFatPercent, "%"),
            Triple("Sıvı", m.bodyWaterPercent, "%"),
            Triple("Kas", m.muscle, ""),
            Triple("Bel", m.waistCm, "cm"),
            Triple("Aktivite", m.physicalActivity, ""),
            Triple("Kemik", m.bone, ""),
            Triple("Met. Hızı", m.metabolicRate, "kcal"),
            Triple("Met. Yaşı", m.metabolicAge.toDouble(), ""),
            Triple("İç Yağ", m.visceralFat, "")
        )
        items.chunked(2).forEach { rowItems ->
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                rowItems.forEach { (title, value, unit) ->
                    val status = referenceForMetric(title, value, patient, m)
                    ElevatedCard(modifier = Modifier.weight(1f)) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(title, fontWeight = FontWeight.SemiBold)
                            Text(
                                if (unit.isBlank()) value.oneDecimal() else "${value.oneDecimal()} $unit",
                                style = MaterialTheme.typography.titleLarge
                            )
                            Text("Referans: ${status.rangeLabel}", style = MaterialTheme.typography.bodySmall)
                            Text(status.statusText, fontWeight = FontWeight.Bold,
                                color = when (status.level) {
                                    ReferenceLevel.NORMAL -> MaterialTheme.colorScheme.primary
                                    ReferenceLevel.LOW -> MaterialTheme.colorScheme.tertiary
                                    ReferenceLevel.HIGH -> MaterialTheme.colorScheme.error
                                    ReferenceLevel.INFO -> MaterialTheme.colorScheme.primary
                                }
                            )
                            if (status.detail.isNotBlank()) {
                                Text(status.detail, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
                if (rowItems.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}
