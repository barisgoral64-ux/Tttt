# V41 GitHub APK Build Düzeltmesi

- GitHub Actions workflow v41 zip adına göre güncellendi.
- `build.log` artık build başlamadan repo kökünde oluşturulur.
- Log artifact yolu sabit `build.log` olduğu için `/build.log` hatası oluşmaz.
- Proje dizini bulunamasa bile hata detayı log dosyasına yazılır.
- APK artifact araması sabit `src/**/build/outputs/apk/release/*.apk` globu ile yapılır.
- Sürüm `versionCode 41` / `versionName 41.0` yapıldı.
