# Güncelleme ve Veri Kaybını Önleme Rehberi

Bu uygulama `com.example.bodytracker` paket adıyla yayınlanır. Telefonda girilmiş danışan, ölçüm, randevu ve takviye verilerinin korunması için yeni APK mutlaka eski APK ile aynı imza anahtarıyla imzalanmalıdır.

## Doğru güncelleme yöntemi

1. Eski sürümde kullanılan `forever-release.jks` dosyasını güvenli bir yerde saklayın.
2. `keystore.properties.example` dosyasını `keystore.properties` olarak kopyalayın.
3. `storeFile`, `storePassword`, `keyAlias`, `keyPassword` alanlarını eski anahtara göre doldurun.
4. Release APK üretin.
5. APK'yı telefona normal güncelleme olarak kurun. Uygulamayı kaldırmayın.

## Önemli

- Yeni bir keystore üretirseniz Android bunu güncelleme olarak kabul etmez.
- Farklı imzalı APK için önce eski uygulamayı kaldırmak gerekir; bu işlem yerel veritabanını silebilir.
- Keystore dosyasını ve şifreleri GitHub, WhatsApp, zip paketi veya müşteriye açık dosyalar içinde paylaşmayın.
- Bu pakette şifreler koddan kaldırılmıştır; fakat aynı eski keystore ile imzalama desteği korunmuştur.
