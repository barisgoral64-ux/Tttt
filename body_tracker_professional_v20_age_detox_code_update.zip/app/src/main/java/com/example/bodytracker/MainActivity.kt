package com.example.bodytracker

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.pm.PackageManager
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.RequiresApi
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Female
import androidx.compose.material.icons.filled.Man
import androidx.compose.material.icons.filled.MonitorWeight
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.Done
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.LocalDrink
import androidx.compose.material.icons.filled.Medication
import androidx.compose.material.icons.filled.QueryStats
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SmallTopAppBar
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.text.input.KeyboardType
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import androidx.compose.runtime.collectAsState
import coil.compose.AsyncImage
import com.example.bodytracker.data.AppDatabase
import com.example.bodytracker.data.AppointmentEntity
import com.example.bodytracker.data.BodyTrackerRepository
import com.example.bodytracker.data.MeasurementEntity
import com.example.bodytracker.data.PatientEntity
import com.example.bodytracker.notifications.AppointmentAlarmReceiver
import com.example.bodytracker.ui.theme.BodyTrackerTheme
import com.example.bodytracker.util.*
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream

sealed interface Screen {
    data object Patients : Screen
    data class AddPatient(val patientId: Long? = null) : Screen
    data object About : Screen
    data class Detail(val patientId: Long) : Screen
    data class AddMeasurement(val patientId: Long, val measurementId: Long? = null) : Screen
    data class DietPlan(val patientId: Long) : Screen
    data class Appointments(val patientId: Long) : Screen
}

class MainActivity : ComponentActivity() {
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = AppDatabase.get(this)
        val repo = BodyTrackerRepository(
            db.patientDao(),
            db.measurementDao(),
            db.appointmentDao(),
            db.productCategoryDao(),
            db.productDao(),
            db.dietPlanDao(),
            db.dietPlanProductDao(),
            db.appSettingDao()
        )
        lifecycleScope.launch { repo.ensureSeededProducts() }
        setContent {
            BodyTrackerTheme {
                BodyTrackerApp(repo)
            }
        }
    }
}

@Composable
fun BodyTrackerApp(repo: BodyTrackerRepository) {
    var screen by remember { mutableStateOf<Screen>(Screen.Patients) }
    val context = LocalContext.current
    val activity = context as? Activity
    LaunchedEffect(activity?.intent?.getLongExtra("appointment_patient_id", -1L)) {
        val patientIdFromIntent = activity?.intent?.getLongExtra("appointment_patient_id", -1L) ?: -1L
        if (patientIdFromIntent > 0L) {
            screen = Screen.Detail(patientIdFromIntent)
        }
    }
    when (val s = screen) {
        Screen.Patients -> PatientsScreen(
            repo,
            onAdd = { screen = Screen.AddPatient() },
            onAbout = { screen = Screen.About },
            onOpen = { screen = Screen.Detail(it) },
            onEdit = { screen = Screen.AddPatient(it) }
        )
        is Screen.AddPatient -> AddPatientScreen(repo, s.patientId, onBack = {
            screen = if (s.patientId == null) Screen.Patients else Screen.Detail(s.patientId)
        }, onSaved = { screen = Screen.Detail(it) })
        Screen.About -> AboutScreen(onBack = { screen = Screen.Patients })
        is Screen.Detail -> PatientDetailScreen(
            repo = repo,
            patientId = s.patientId,
            onBack = { screen = Screen.Patients },
            onEditPatient = { screen = Screen.AddPatient(s.patientId) },
            onAddMeasurement = { screen = Screen.AddMeasurement(s.patientId) },
            onEditMeasurement = { screen = Screen.AddMeasurement(s.patientId, it) },
            onOpenDietPlan = { screen = Screen.DietPlan(s.patientId) },
            onOpenAppointments = { screen = Screen.Appointments(s.patientId) }
        )
        is Screen.AddMeasurement -> AddMeasurementScreen(repo, s.patientId, s.measurementId, onBack = { screen = Screen.Detail(s.patientId) }, onSaved = { screen = Screen.Detail(s.patientId) })
        is Screen.DietPlan -> DietPlanScreen(repo, s.patientId, onBack = { screen = Screen.Detail(s.patientId) })
        is Screen.Appointments -> AppointmentsScreen(repo, s.patientId, onBack = { screen = Screen.Detail(s.patientId) })
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PatientsScreen(repo: BodyTrackerRepository, onAdd: () -> Unit, onAbout: () -> Unit, onOpen: (Long) -> Unit, onEdit: (Long) -> Unit) {
    val patients by repo.observePatients().collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    var query by rememberSaveable { mutableStateOf("") }
    var patientPendingDelete by remember { mutableStateOf<PatientEntity?>(null) }
    val filtered = remember(patients, query) {
        val q = query.trim().lowercase()
        if (q.isBlank()) {
            patients
        } else {
            patients.filter {
                listOf(
                    it.firstName,
                    it.lastName,
                    "${it.firstName} ${it.lastName}",
                    it.gender,
                    formatDate(it.birthDateMillis),
                    it.notes
                ).any { value -> value.lowercase().contains(q) }
            }
        }
    }

    patientPendingDelete?.let { patient ->
        AlertDialog(
            onDismissRequest = { patientPendingDelete = null },
            title = { Text("Danışanı sil") },
            text = { Text("${patient.firstName} ${patient.lastName} kaydını silmek istediğinize emin misiniz?") },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch { repo.deletePatient(patient) }
                    patientPendingDelete = null
                }) { Text("Sil", color = Color(0xFFC62828)) }
            },
            dismissButton = { TextButton(onClick = { patientPendingDelete = null }) { Text("Vazgeç") } }
        )
    }


    Scaffold(
        topBar = {
            SmallTopAppBar(
                title = { Text("Forever Danışan Takip") },
                actions = { IconButton(onClick = onAbout) { Icon(Icons.Default.Info, contentDescription = "Hakkında") } }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onAdd,
                containerColor = Color(0xFF0F8A5F),
                contentColor = Color.White,
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text("Yeni Danışan") }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Profesyonel danışan arama", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text("Kayıtlı danışanları hızlı ara, karttan detay aç ve danışan bilgilerini tek bakışta gör.")
                    }
                }
            }
            item {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Danışan ara") },
                    placeholder = { Text("Ad, soyad, cinsiyet veya tarih") },
                    leadingIcon = { Icon(Icons.Default.Search, null) },
                    trailingIcon = {
                        if (query.isNotBlank()) {
                            IconButton(onClick = { query = "" }) { Icon(Icons.Default.Close, contentDescription = "Temizle") }
                        }
                    },
                    singleLine = true
                )
            }
            if (filtered.isEmpty()) {
                item {
                    ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                        Column(Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.Search, contentDescription = null)
                            Text("Sonuç bulunamadı", fontWeight = FontWeight.Bold)
                            Text("Arama kelimesini değiştirerek tekrar deneyebilirsin.")
                        }
                    }
                }
            }
            items(filtered) { patient ->
                PatientSearchCard(
                    patient = patient,
                    onOpen = { onOpen(patient.id) },
                    onEdit = { onEdit(patient.id) },
                    onDelete = { patientPendingDelete = patient }
                )
            }
            item { Spacer(Modifier.height(96.dp)) }
        }
    }
}

@Composable
private fun PatientSearchCard(patient: PatientEntity, onOpen: () -> Unit, onEdit: () -> Unit, onDelete: () -> Unit) {
    ElevatedCard(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onOpen),
        colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Surface(
                    modifier = Modifier.size(60.dp),
                    shape = MaterialTheme.shapes.large,
                    color = MaterialTheme.colorScheme.secondaryContainer
                ) {
                    if (patient.photoUri.isNullOrBlank()) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.Person, contentDescription = null, modifier = Modifier.size(32.dp))
                        }
                    } else {
                        AsyncImage(
                            model = patient.photoUri,
                            contentDescription = null,
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    }
                }
                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("${patient.firstName} ${patient.lastName}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(
                        text = "Yaş: ${patientAge(patient)}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Surface(shape = MaterialTheme.shapes.large, color = MaterialTheme.colorScheme.primaryContainer) {
                    Text(
                        text = if (patient.gender == "Erkek") "Erkek" else "Kadın",
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PatientInfoChip(icon = Icons.Default.Person, text = "${patientAge(patient)} yaş")
                PatientInfoChip(icon = Icons.Default.MonitorWeight, text = "${patient.heightCm} cm")
                PatientInfoChip(
                    icon = if (patient.gender == "Erkek") Icons.Default.Man else Icons.Default.Female,
                    text = "Profil"
                )
            }

            if (patient.notes.isNotBlank()) {
                Surface(shape = MaterialTheme.shapes.medium, color = MaterialTheme.colorScheme.tertiaryContainer) {
                    Text(
                        text = patient.notes.take(90),
                        modifier = Modifier.fillMaxWidth().padding(10.dp),
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }

            HorizontalDivider()

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text("Kayıt tarihi", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(formatDate(patient.createdAt), fontWeight = FontWeight.Medium)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = onEdit) { Text("Düzenle") }
                    TextButton(onClick = onOpen) { Text("Detayı Aç") }
                    IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, contentDescription = "Sil") }
                }
            }
        }
    }
}

@Composable
private fun PatientInfoChip(icon: ImageVector, text: String) {
    Surface(shape = MaterialTheme.shapes.large, color = MaterialTheme.colorScheme.surfaceVariant) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconBadge(icon = icon, size = 32.dp)
            Text(text, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Medium)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddPatientScreen(repo: BodyTrackerRepository, patientId: Long?, onBack: () -> Unit, onSaved: (Long) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val existingPatient by if (patientId != null) {
        repo.observePatient(patientId).collectAsState(initial = null)
    } else {
        remember { mutableStateOf<PatientEntity?>(null) }
    }
    var initialized by remember(existingPatient?.id) { mutableStateOf(false) }
    var firstName by rememberSaveable { mutableStateOf("") }
    var lastName by rememberSaveable { mutableStateOf("") }
    var gender by rememberSaveable { mutableStateOf("Erkek") }
    var heightText by rememberSaveable { mutableStateOf("") }
    var ageText by rememberSaveable { mutableStateOf("") }
    var photoUri by rememberSaveable { mutableStateOf<String?>(null) }
    var notes by rememberSaveable { mutableStateOf("") }

    val previewLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicturePreview()) { bitmap ->
        if (bitmap != null) {
            photoUri = saveBitmapToCache(context, bitmap)?.toString()
        } else {
            Toast.makeText(context, "Kamera görüntüsü alınamadı", Toast.LENGTH_SHORT).show()
        }
    }
    val cameraPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            try {
                previewLauncher.launch(null)
            } catch (_: Exception) {
                Toast.makeText(context, "Kamera açılamadı", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(context, "Kamera izni verilmedi", Toast.LENGTH_SHORT).show()
        }
    }
    val galleryLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> photoUri = uri?.toString() }

    val existingProfile = existingPatient
    if (existingProfile != null && !initialized) {
        firstName = existingProfile.firstName
        lastName = existingProfile.lastName
        gender = existingProfile.gender
        heightText = existingProfile.heightCm.toString()
        ageText = (if (existingProfile.ageYears > 0) existingProfile.ageYears else calculateAge(existingProfile.birthDateMillis)).toString()
        photoUri = existingProfile.photoUri
        notes = existingProfile.notes
        initialized = true
    }


    Scaffold(topBar = { SmallTopAppBar(title = { Text(if (patientId == null) "Yeni Danışan" else "Danışan Düzenle") }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) } }) }) { padding ->
        LazyColumn(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                PatientPhotoCard(photoUri, onCamera = {
                    val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == android.content.pm.PackageManager.PERMISSION_GRANTED
                    if (granted) {
                        try {
                            previewLauncher.launch(null)
                        } catch (_: Exception) {
                            Toast.makeText(context, "Kamera açılamadı", Toast.LENGTH_SHORT).show()
                        }
                    } else {
                        cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                    }
                }, onGallery = { galleryLauncher.launch("image/*") })
            }
            item { OutlinedTextField(firstName, { firstName = it }, Modifier.fillMaxWidth(), label = { Text("Ad") }, leadingIcon = { Icon(Icons.Default.Person, null) }) }
            item { OutlinedTextField(lastName, { lastName = it }, Modifier.fillMaxWidth(), label = { Text("Soyad") }, leadingIcon = { Icon(Icons.Default.Person, null) }) }
            item { OutlinedTextField(ageText, { ageText = it.filter(Char::isDigit).take(3) }, Modifier.fillMaxWidth(), label = { Text("Yaş") }, leadingIcon = { Icon(Icons.Default.Cake, null) }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true) }
            item {
                Text("Cinsiyet", style = MaterialTheme.typography.titleMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = gender == "Erkek", onClick = { gender = "Erkek" }, label = { Text("Erkek") }, leadingIcon = { Icon(Icons.Default.Man, null) })
                    FilterChip(selected = gender == "Kadın", onClick = { gender = "Kadın" }, label = { Text("Kadın") }, leadingIcon = { Icon(Icons.Default.Female, null) })
                }
            }
            item { OutlinedTextField(heightText, { heightText = it.filter(Char::isDigit) }, Modifier.fillMaxWidth(), label = { Text("Boy (cm)") }, leadingIcon = { Icon(Icons.Default.MonitorWeight, null) }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)) }
            item {
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    modifier = Modifier.fillMaxWidth().height(120.dp),
                    label = { Text("Danışan Notu / Hastalıklar") },
                    leadingIcon = { Icon(Icons.Default.Info, null) }
                )
            }
            item {
                Button(onClick = {
                    val height = heightText.toIntOrNull() ?: 0
                    val age = ageText.toIntOrNull() ?: 0
                    if (firstName.isNotBlank() && lastName.isNotBlank() && height > 0 && age > 0) {
                        scope.launch {
                            val entity = PatientEntity(
                                id = existingPatient?.id ?: 0,
                                firstName = firstName.trim(),
                                lastName = lastName.trim(),
                                birthDateMillis = existingPatient?.birthDateMillis ?: 0L,
                                ageYears = age,
                                gender = gender,
                                heightCm = height,
                                photoUri = photoUri,
                                notes = notes.trim(),
                                createdAt = existingPatient?.createdAt ?: System.currentTimeMillis()
                            )
                            if (existingPatient == null) {
                                val id = repo.addPatient(entity)
                                onSaved(id)
                            } else {
                                repo.updatePatient(entity)
                                onSaved(entity.id)
                            }
                        }
                    }
                }, modifier = Modifier.fillMaxWidth()) { Text(if (patientId == null) "Danışanı Kaydet" else "Danışanı Güncelle") }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PatientDetailScreen(
    repo: BodyTrackerRepository,
    patientId: Long,
    onBack: () -> Unit,
    onEditPatient: () -> Unit,
    onAddMeasurement: () -> Unit,
    onEditMeasurement: (Long) -> Unit,
    onOpenDietPlan: () -> Unit,
    onOpenAppointments: () -> Unit
) {
    val scope = rememberCoroutineScope()
    val patient by repo.observePatient(patientId).collectAsState(initial = null)
    val measurements by repo.observeMeasurements(patientId).collectAsState(initial = emptyList())
    val latest = measurements.firstOrNull()
    val previous = measurements.getOrNull(1)
    val previousMonth = latest?.let { l -> measurements.drop(1).minByOrNull { kotlin.math.abs(it.dateMillis - (l.dateMillis - 30L * 24 * 60 * 60 * 1000)) } }
    var measurementPendingDelete by remember { mutableStateOf<MeasurementEntity?>(null) }

    measurementPendingDelete?.let { measurement ->
        AlertDialog(
            onDismissRequest = { measurementPendingDelete = null },
            title = { Text("Ölçümü sil") },
            text = { Text("${formatDate(measurement.dateMillis)} tarihli vücut analizini silmek istediğinize emin misiniz?") },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch { repo.deleteMeasurement(measurement) }
                    measurementPendingDelete = null
                }) { Text("Sil", color = Color(0xFFC62828)) }
            },
            dismissButton = { TextButton(onClick = { measurementPendingDelete = null }) { Text("Vazgeç") } }
        )
    }

    Scaffold(
        topBar = {
            SmallTopAppBar(
                title = { Text("Danışan Detayı") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) } },
                actions = {
                    IconButton(onClick = onEditPatient) { Icon(Icons.Default.Edit, null) }
                    IconButton(onClick = onOpenAppointments) { Icon(Icons.Default.Event, null, tint = Color(0xFFE0A106)) }
                    IconButton(onClick = onOpenDietPlan) { Icon(Icons.Default.LocalDrink, null, tint = Color(0xFF2E7D32)) }
                    IconButton(onClick = onAddMeasurement) { Icon(Icons.Default.QueryStats, null, tint = Color(0xFF1565C0)) }
                }
            )
        }
    ) { padding ->
        val p = patient ?: return@Scaffold
        LazyColumn(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                Card {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("${p.firstName} ${p.lastName}", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        Text("${p.gender} • ${patientAge(p)} yaş • ${p.heightCm} cm")
                        Text("Yaş: ${patientAge(p)}")
                        if (p.notes.isNotBlank()) {
                            Surface(shape = MaterialTheme.shapes.medium, color = MaterialTheme.colorScheme.tertiaryContainer) {
                                Text("Not: ${p.notes}", modifier = Modifier.fillMaxWidth().padding(10.dp))
                            }
                        }
                    }
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                    QuickActionCard(
                        title = "Vücut Analizi",
                        icon = Icons.Default.QueryStats,
                        modifier = Modifier.weight(1f),
                        iconContainerColor = Color(0xFFE3F2FD),
                        iconTint = Color(0xFF1565C0),
                        onClick = onAddMeasurement
                    )
                    QuickActionCard(
                        title = "Takviye Planı",
                        icon = Icons.Default.LocalDrink,
                        modifier = Modifier.weight(1f),
                        iconContainerColor = Color(0xFFE8F5E9),
                        iconTint = Color(0xFF2E7D32),
                        onClick = onOpenDietPlan
                    )
                }
            }
            if (latest != null) {
                item {
                    val context = LocalContext.current
                    val analysisText = remember(p.id, latest.id, measurements.size) {
                        generateAnalysisReportText(patient = p, latest = latest, previous = previous, previousMonth = previousMonth, measurements = measurements)
                    }
                    ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = Color(0xFFFFF8E1))) {
                        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("Analiz Raporu Paylaş", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text("PDF oluşturup paylaşabilir veya kısa analiz özetini WhatsApp ile gönderebilirsin.")
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                                OutlinedButton(
                                    onClick = { shareText(context, analysisText, p, false) },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.Share, null)
                                    Spacer(Modifier.size(6.dp))
                                    Text("Özeti Paylaş")
                                }
                                Button(
                                    onClick = {
                                        val pdf = createAnalysisPdf(context, p, analysisText)
                                        shareFile(context, pdf, p, "application/pdf")
                                    },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.PictureAsPdf, null)
                                    Spacer(Modifier.size(6.dp))
                                    Text("PDF Oluştur")
                                }
                            }
                        }
                    }
                }
                item { ProfessionalAnalysisReportCard(patient = p, latest = latest, previous = previous, previousMonth = previousMonth, measurements = measurements) }
                item { ComparisonOverview(latest, previous, previousMonth, measurements.drop(1)) }
                item { MetricGrid(p, latest) }
                item { MetricChartsSection(measurements) }
            } else {
                item {
                    ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = Color(0xFFE3F2FD))) {
                        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Henüz vücut analizi yok", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text("Yukarıdaki Vücut Analizi kartı ile ilk ölçümü ekleyebilir ve rapor görünümünü burada görebilirsin.")
                        }
                    }
                }
            }
            item { Text("Vücut Analizi Geçmişi", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
            items(measurements) { m ->
                Card {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text(formatDate(m.dateMillis), fontWeight = FontWeight.SemiBold)
                            Row {
                                IconButton(onClick = { onEditMeasurement(m.id) }) { Icon(Icons.Default.Edit, null) }
                                IconButton(onClick = { measurementPendingDelete = m }) { Icon(Icons.Default.Delete, null) }
                            }
                        }
                        Text("${m.analysisMode} • Kilo: ${m.weightKg.oneDecimal()} kg  •  VKİ: ${m.bmi.oneDecimal()}")
                        Text("Yağ: ${m.bodyFatPercent.oneDecimal()}%  •  Sıvı: ${m.bodyWaterPercent.oneDecimal()}%  •  Kas: ${m.muscle.oneDecimal()}")
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddMeasurementScreen(repo: BodyTrackerRepository, patientId: Long, measurementId: Long?, onBack: () -> Unit, onSaved: () -> Unit) {
    val scope = rememberCoroutineScope()
    val patient by repo.observePatient(patientId).collectAsState(initial = null)
    val existing by if (measurementId != null) {
        repo.observeMeasurement(measurementId).collectAsState(initial = null)
    } else {
        remember { mutableStateOf<MeasurementEntity?>(null) }
    }
    val p = patient ?: return

    var initialized by remember(existing?.id) { mutableStateOf(false) }
    var dateMillis by rememberSaveable { mutableStateOf(System.currentTimeMillis()) }
    var showDatePicker by remember { mutableStateOf(false) }
    var weightText by rememberSaveable { mutableStateOf("") }
    var fatText by rememberSaveable { mutableStateOf("") }
    var waterText by rememberSaveable { mutableStateOf("") }
    var muscleText by rememberSaveable { mutableStateOf("") }
    var activityText by rememberSaveable { mutableStateOf("") }
    var boneText by rememberSaveable { mutableStateOf("") }
    var rateText by rememberSaveable { mutableStateOf("") }
    var metabolicAgeText by rememberSaveable { mutableStateOf("") }
    var visceralText by rememberSaveable { mutableStateOf("") }
    var analysisMode by rememberSaveable { mutableStateOf("Standart") }

    val existingMeasurement = existing
    if (existingMeasurement != null && !initialized) {
        dateMillis = existingMeasurement.dateMillis
        weightText = existingMeasurement.weightKg.toString()
        fatText = existingMeasurement.bodyFatPercent.toString()
        waterText = existingMeasurement.bodyWaterPercent.toString()
        muscleText = existingMeasurement.muscle.toString()
        activityText = existingMeasurement.physicalActivity.toString()
        boneText = existingMeasurement.bone.toString()
        rateText = existingMeasurement.metabolicRate.toString()
        metabolicAgeText = existingMeasurement.metabolicAge.toString()
        visceralText = existingMeasurement.visceralFat.toString()
        analysisMode = existingMeasurement.analysisMode
        initialized = true
    }

    val bmi = calculateBmi(weightText.toDoubleOrNull() ?: 0.0, p.heightCm)

    Scaffold(topBar = { SmallTopAppBar(title = { Text(if (measurementId == null) "Yeni Ölçüm" else "Ölçüm Düzenle") }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) } }) }) { padding ->
        LazyColumn(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("${p.firstName} ${p.lastName}", fontWeight = FontWeight.Bold)
                        Text("Boy: ${p.heightCm} cm • Yaş: ${patientAge(p)}")
                        Text("VKİ otomatik hesaplanır.")
                        Text("Analiz türü: $analysisMode")
                    }
                }
            }
            item { DateField("Ölçüm Tarihi", formatDate(dateMillis)) { showDatePicker = true } }
            item {
                Text("Analiz tipi", style = MaterialTheme.typography.titleMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = analysisMode == "Standart", onClick = { analysisMode = "Standart" }, label = { Text("Vücut Analizi") })
                    FilterChip(selected = analysisMode == "Detoks", onClick = { analysisMode = "Detoks" }, label = { Text("Detoks") })
                }
            }
            item { NumericField("Kilo (kg)", weightText) { weightText = it } }
            item { ReferenceStatusCard("Kilo Referansı", weightReferenceStatus(weightText.toDoubleOrNull() ?: 0.0, p.heightCm)) }
            item {
                ElevatedCard { Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween) { Text("Otomatik VKİ", fontWeight = FontWeight.SemiBold); Text(bmi.oneDecimal(), style = MaterialTheme.typography.titleLarge) } }
            }
            item { ReferenceStatusCard("VKİ Referansı", bmiReferenceStatus(bmi)) }
            item { NumericField("Vücut Yağ Oranı (%)", fatText) { fatText = it } }
            item { ReferenceStatusCard("Yağ Oranı Referansı", bodyFatReferenceStatus(p.gender, patientAge(p), fatText.toDoubleOrNull() ?: 0.0)) }
            item { NumericField("Vücut Sıvı Oranı (%)", waterText) { waterText = it } }
            item { ReferenceStatusCard("Sıvı Oranı Referansı", bodyWaterReferenceStatus(p.gender, waterText.toDoubleOrNull() ?: 0.0)) }
            item { NumericField("Kas", muscleText) { muscleText = it } }
            item { ReferenceStatusCard("Kas Referansı", muscleReferenceStatus(p.gender, muscleText.toDoubleOrNull() ?: 0.0)) }
            item { NumericField("Fiziksel Aktivite", activityText) { activityText = it } }
            item { ReferenceStatusCard("Aktivite Referansı", activityReferenceStatus(activityText.toDoubleOrNull() ?: 0.0)) }
            item { NumericField("Kemik", boneText) { boneText = it } }
            item { ReferenceStatusCard("Kemik Referansı", boneReferenceStatus(p.gender, boneText.toDoubleOrNull() ?: 0.0)) }
            item { NumericField("Metabolizma Hızı", rateText) { rateText = it } }
            item { ReferenceStatusCard("Metabolizma Hızı Referansı", metabolicRateReferenceStatus(p.gender, patientAge(p), p.heightCm, weightText.toDoubleOrNull() ?: 0.0, rateText.toDoubleOrNull() ?: 0.0)) }
            item { NumericField("Metabolizma Yaşı", metabolicAgeText) { metabolicAgeText = it } }
            item { ReferenceStatusCard("Metabolizma Yaşı Referansı", metabolicAgeReferenceStatus(patientAge(p), metabolicAgeText.toIntOrNull() ?: 0)) }
            item { NumericField("İç Yağ", visceralText) { visceralText = it } }
            item { ReferenceStatusCard("İç Yağ Referansı", visceralFatReferenceStatus(visceralText.toDoubleOrNull() ?: 0.0)) }
            item {
                Button(onClick = {
                    val weight = weightText.toDoubleOrNull() ?: 0.0
                    if (weight > 0) {
                        val entity = MeasurementEntity(
                            id = existing?.id ?: 0,
                            patientId = patientId,
                            dateMillis = dateMillis,
                            weightKg = weight,
                            bmi = bmi,
                            bodyFatPercent = fatText.toDoubleOrNull() ?: 0.0,
                            bodyWaterPercent = waterText.toDoubleOrNull() ?: 0.0,
                            muscle = muscleText.toDoubleOrNull() ?: 0.0,
                            physicalActivity = activityText.toDoubleOrNull() ?: 0.0,
                            bone = boneText.toDoubleOrNull() ?: 0.0,
                            metabolicRate = rateText.toDoubleOrNull() ?: 0.0,
                            metabolicAge = metabolicAgeText.toIntOrNull() ?: metabolicAgeHint(patientAge(p), bmi),
                            visceralFat = visceralText.toDoubleOrNull() ?: 0.0,
                            analysisMode = analysisMode
                        )
                        scope.launch {
                            if (existing == null) repo.addMeasurement(entity) else repo.updateMeasurement(entity)
                            onSaved()
                        }
                    }
                }, modifier = Modifier.fillMaxWidth()) { Text(if (measurementId == null) "Ölçümü Kaydet" else "Değişiklikleri Kaydet") }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppointmentsScreen(repo: BodyTrackerRepository, patientId: Long, onBack: () -> Unit) {
    val context = LocalContext.current
    val activity = context as? Activity
    val scope = rememberCoroutineScope()
    val notificationPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        Toast.makeText(
            context,
            if (granted) "Bildirim izni verildi. Randevuyu tekrar kaydedersen bildirim kurulacak." else "Bildirim izni verilmedi. Randevu kaydedildi ama bildirim gösterilemeyebilir.",
            Toast.LENGTH_LONG
        ).show()
    }
    val patient by repo.observePatient(patientId).collectAsState(initial = null)
    val appointments by repo.observeAppointments(patientId).collectAsState(initial = emptyList())
    val p = patient ?: return
    var title by rememberSaveable { mutableStateOf("") }
    var note by rememberSaveable { mutableStateOf("") }
    var dateMillis by rememberSaveable { mutableStateOf(System.currentTimeMillis()) }
    var hourText by rememberSaveable { mutableStateOf("09") }
    var minuteText by rememberSaveable { mutableStateOf("00") }
    var showDatePicker by remember { mutableStateOf(false) }


    fun ensureNotificationPermission(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return true
        return if (ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
            true
        } else {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            false
        }
    }

    LaunchedEffect(Unit) {
        ensureNotificationPermission()
    }

    fun ensureExactAlarmPermission(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return true
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        if (alarmManager.canScheduleExactAlarms()) return true
        val requestIntent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
            data = Uri.parse("package:${context.packageName}")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return runCatching {
            activity?.startActivity(requestIntent) ?: context.startActivity(requestIntent)
            Toast.makeText(context, "Kesin saatli bildirim için 'Alarmlar ve hatırlatıcılar' iznini açıp tekrar kaydetmen gerekiyor.", Toast.LENGTH_LONG).show()
            false
        }.getOrDefault(false)
    }

    fun scheduleAppointmentNotification(appointmentId: Long, whenMillis: Long, titleValue: String, noteValue: String): Boolean {
        if (!ensureNotificationPermission()) return false
        if (!ensureExactAlarmPermission()) return false
        val patientName = "${p.firstName} ${p.lastName}"
        val intent = AppointmentAlarmReceiver.buildAlarmIntent(
            context = context,
            appointmentId = appointmentId,
            patientId = patientId,
            patientName = patientName,
            title = titleValue,
            note = noteValue,
            whenMillis = whenMillis,
            whenText = formatDateTime(whenMillis)
        )
        AppointmentAlarmReceiver.scheduleExact(context, intent, whenMillis)
        return true
    }

    Scaffold(topBar = { SmallTopAppBar(title = { Text("Randevu Takibi") }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) } }) }) { padding ->
        LazyColumn(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("${p.firstName} ${p.lastName}", fontWeight = FontWeight.Bold)
                        Text("Randevu oluştururken tarih ve saat belirle. Ekran açıldığında bildirim izni istenir; böylece uygulamayı ayarlardan aramak zorunda kalmazsın.")
                    }
                }
            }
            item { OutlinedTextField(title, { title = it }, Modifier.fillMaxWidth(), label = { Text("Randevu Başlığı") }, leadingIcon = { Icon(Icons.Default.Event, null) }) }
            item { DateField("Randevu Tarihi", formatDate(dateMillis)) { showDatePicker = true } }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = hourText,
                        onValueChange = { hourText = it.filter(Char::isDigit).take(2) },
                        modifier = Modifier.weight(1f),
                        label = { Text("Saat") },
                        leadingIcon = { Icon(Icons.Default.AccessTime, null) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = minuteText,
                        onValueChange = { minuteText = it.filter(Char::isDigit).take(2) },
                        modifier = Modifier.weight(1f),
                        label = { Text("Dakika") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true
                    )
                }
            }
            item { OutlinedTextField(note, { note = it }, Modifier.fillMaxWidth().height(120.dp), label = { Text("Not") }) }
            item {
                Button(onClick = {
                    if (title.isNotBlank()) {
                        val whenMillis = combineDateAndTime(dateMillis, hourText.toIntOrNull() ?: 9, minuteText.toIntOrNull() ?: 0)
                        scope.launch {
                            val appointmentId = repo.addAppointment(AppointmentEntity(patientId = patientId, dateMillis = whenMillis, title = title.trim(), note = note.trim()))
                            val scheduled = scheduleAppointmentNotification(appointmentId, whenMillis, title.trim(), note.trim())
                            title = ""
                            note = ""
                            dateMillis = System.currentTimeMillis()
                            hourText = "09"
                            minuteText = "00"
                            Toast.makeText(
                                context,
                                if (scheduled) "Randevu kaydedildi ve bildirim kuruldu" else "Randevu kaydedildi. İzinleri açtıktan sonra tekrar kaydet veya ertele ile bildirimi kur.",
                                Toast.LENGTH_LONG
                            ).show()
                        }
                    }
                }, modifier = Modifier.fillMaxWidth()) { Text("Randevu Kaydet ve Bildirim Kur") }
            }
            item { Text("Kayıtlı Randevular", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
            items(appointments) { appt ->
                Card {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(appt.title, fontWeight = FontWeight.SemiBold)
                                Text(formatDateTime(appt.dateMillis))
                                Text("Danışan: ${p.firstName} ${p.lastName}", style = MaterialTheme.typography.bodySmall)
                            }
                            IconButton(onClick = { scope.launch { repo.deleteAppointment(appt) } }) { Icon(Icons.Default.Delete, null) }
                        }
                        if (appt.note.isNotBlank()) Text("Not: ${appt.note}")
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = {
                                scope.launch {
                                    val newMillis = appt.dateMillis + 60 * 60 * 1000L
                                    val updated = appt.copy(dateMillis = newMillis)
                                    repo.updateAppointment(updated)
                                    val scheduled = scheduleAppointmentNotification(updated.id, newMillis, updated.title, updated.note)
                                    Toast.makeText(context, if (scheduled) "1 saat ertelendi" else "Randevu ertelendi fakat bildirim izni / alarm izni gerekiyor", Toast.LENGTH_LONG).show()
                                }
                            }) { Icon(Icons.Default.Alarm, null); Spacer(Modifier.size(6.dp)); Text("Ertele") }
                            Button(onClick = { scope.launch { repo.deleteAppointment(appt) } }) { Icon(Icons.Default.Done, null); Spacer(Modifier.size(6.dp)); Text("Tamam") }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DietPlanScreen(repo: BodyTrackerRepository, patientId: Long, onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val patient by repo.observePatient(patientId).collectAsState(initial = null)
    val measurements by repo.observeMeasurements(patientId).collectAsState(initial = emptyList())
    val categories by repo.observeCategories().collectAsState(initial = emptyList())
    val products by repo.observeProducts().collectAsState(initial = emptyList())
    val dietPlans by repo.observeDietPlans(patientId).collectAsState(initial = emptyList())
    val currentPlan = dietPlans.firstOrNull()
    val selectedPlanProducts by if (currentPlan != null) {
        repo.observeDietPlanProducts(currentPlan.id).collectAsState(initial = emptyList())
    } else {
        remember { mutableStateOf(emptyList()) }
    }
    val p = patient ?: return
    val latest = measurements.firstOrNull()

    var goal by rememberSaveable { mutableStateOf("Kilo kontrolü") }
    var meals by rememberSaveable { mutableStateOf("3 ana öğün + 2 ara öğün") }
    var water by rememberSaveable { mutableStateOf("Günde 2-2.5 litre su") }
    var notes by rememberSaveable { mutableStateOf("") }
    var productQuery by rememberSaveable { mutableStateOf("") }
    var selectedCategoryId by rememberSaveable { mutableStateOf<Long?>(null) }
    var showAddSupplementDialog by remember { mutableStateOf(false) }
    var selectedProductIdForAdd by rememberSaveable { mutableStateOf<Long?>(null) }
    var addApplicationMethod by rememberSaveable { mutableStateOf("Ağızdan") }
    var addUsagePattern by rememberSaveable { mutableStateOf("1x2") }
    var addQuantityValue by rememberSaveable { mutableStateOf("1") }
    var addQuantityUnit by rememberSaveable { mutableStateOf("adet") }
    var addTimingNote by rememberSaveable { mutableStateOf("") }
    var addNote by rememberSaveable { mutableStateOf("") }

    val selectedProducts = remember(products, selectedPlanProducts) {
        val ids = selectedPlanProducts.map { it.productId }.toSet()
        products.filter { it.id in ids }
    }
    val filteredProducts = remember(products, productQuery, selectedCategoryId) {
        products.filter { product ->
            val categoryOk = selectedCategoryId == null || product.categoryId == selectedCategoryId
            val q = productQuery.trim().lowercase()
            val queryOk = q.isBlank() || listOf(product.name, product.brand, product.description, product.defaultDose, product.timing)
                .plus(product.code)
                .any { it.lowercase().contains(q) }
            categoryOk && queryOk
        }
    }
    val browseProducts = remember(filteredProducts, selectedPlanProducts) {
        val selectedIds = selectedPlanProducts.map { it.productId }.toSet()
        filteredProducts.filterNot { it.id in selectedIds }
    }

    val supplementLines = remember(selectedProducts, selectedPlanProducts) {
        selectedProducts.mapNotNull { product ->
            val item = selectedPlanProducts.firstOrNull { it.productId == product.id } ?: return@mapNotNull null
            formatSupplementLine(product, item)
        }
    }
    val selectedProductForAdd = products.firstOrNull { it.id == selectedProductIdForAdd }

    val planText = remember(p, measurements, goal, meals, water, notes, supplementLines) {
        generateDietPlanText(p, measurements, goal, meals, water, notes, supplementLines)
    }

    fun addOrRemoveProduct(product: com.example.bodytracker.data.ProductEntity, remove: Boolean) {
        scope.launch {
            val planId = currentPlan?.id ?: repo.addDietPlan(
                com.example.bodytracker.data.DietPlanEntity(
                    patientId = patientId,
                    title = "${p.firstName} ${p.lastName} Takviye Planı",
                    description = "Analiz destekli takviye ve diyet planı"
                )
            )
            val existing = selectedPlanProducts.firstOrNull { it.productId == product.id }
            if (remove) {
                if (existing != null) repo.deleteDietPlanProduct(existing)
            } else if (existing == null) {
                repo.addDietPlanProduct(
                    com.example.bodytracker.data.DietPlanProductEntity(
                        dietPlanId = planId,
                        productId = product.id,
                        customDose = product.defaultDose,
                        customTiming = product.timing,
                        applicationMethod = suggestApplicationMethod(product, categories.firstOrNull { it.id == product.categoryId }?.name.orEmpty()),
                        usagePattern = suggestUsagePattern(product),
                        quantityValue = suggestQuantityValue(product),
                        quantityUnit = suggestQuantityUnit(product),
                        timingNote = product.timing,
                        goalTag = goal,
                        customNote = product.usageNote,
                        sortOrder = selectedPlanProducts.size + 1
                    )
                )
            }
        }
    }

    fun addProductWithDetails(product: com.example.bodytracker.data.ProductEntity) {
        scope.launch {
            val planId = currentPlan?.id ?: repo.addDietPlan(
                com.example.bodytracker.data.DietPlanEntity(
                    patientId = patientId,
                    title = "${p.firstName} ${p.lastName} Takviye Planı",
                    description = "Analiz destekli takviye ve diyet planı"
                )
            )
            val existing = selectedPlanProducts.firstOrNull { it.productId == product.id }
            if (existing == null) {
                repo.addDietPlanProduct(
                    com.example.bodytracker.data.DietPlanProductEntity(
                        dietPlanId = planId,
                        productId = product.id,
                        customDose = listOf(addQuantityValue, addQuantityUnit).filter { it.isNotBlank() }.joinToString(" "),
                        customTiming = addTimingNote,
                        applicationMethod = addApplicationMethod,
                        usagePattern = addUsagePattern,
                        quantityValue = addQuantityValue,
                        quantityUnit = addQuantityUnit,
                        timingNote = addTimingNote,
                        goalTag = goal,
                        customNote = addNote,
                        sortOrder = selectedPlanProducts.size + 1
                    )
                )
            }
            showAddSupplementDialog = false
            selectedProductIdForAdd = null
            addNote = ""
            productQuery = ""
        }
    }

    if (showAddSupplementDialog) {
        AlertDialog(
            onDismissRequest = { showAddSupplementDialog = false },
            properties = DialogProperties(usePlatformDefaultWidth = false),
            confirmButton = {
                TextButton(onClick = {
                    selectedProductForAdd?.let { addProductWithDetails(it) }
                }, enabled = selectedProductForAdd != null) { Text("Takviyeyi ekle") }
            },
            dismissButton = { TextButton(onClick = { showAddSupplementDialog = false }) { Text("Kapat") } },
            title = { Text("Takviye seç ve ekle") },
            text = {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth().height(520.dp)
                ) {
                    item {
                        Text(
                            "Önce kategori seç. Arama alanı sadece istersen filtrelemek için kullanılır.",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    item {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                FilterChip(
                                    selected = selectedCategoryId == null,
                                    onClick = { selectedCategoryId = null },
                                    label = { Text("Tümü") }
                                )
                            }
                            categories.chunked(2).forEach { chunk ->
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    chunk.forEach { cat ->
                                        FilterChip(
                                            selected = selectedCategoryId == cat.id,
                                            onClick = {
                                                selectedCategoryId = if (selectedCategoryId == cat.id) null else cat.id
                                            },
                                            label = { Text(cat.name) }
                                        )
                                    }
                                }
                            }
                        }
                    }
                    item {
                        OutlinedTextField(
                            value = productQuery,
                            onValueChange = { productQuery = it },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            label = { Text("Kod veya isim ara") },
                            leadingIcon = { Icon(Icons.Default.Search, null) }
                        )
                    }
                    item {
                        val categoryLabel = categories.firstOrNull { it.id == selectedCategoryId }?.name ?: "Tüm takviyeler"
                        Surface(shape = MaterialTheme.shapes.medium, color = MaterialTheme.colorScheme.secondaryContainer) {
                            Text(
                                "$categoryLabel • ${browseProducts.size} ürün",
                                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                    if (browseProducts.isEmpty()) {
                        item {
                            ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                                Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text("Bu seçim için ürün bulunamadı", fontWeight = FontWeight.Bold)
                                    Text("Kategoriyi değiştir veya arama alanını temizleyerek tekrar dene.")
                                }
                            }
                        }
                    } else {
                        items(browseProducts) { product ->
                            val selected = selectedProductIdForAdd == product.id
                            val categoryName = categories.firstOrNull { it.id == product.categoryId }?.name.orEmpty()
                            Card(
                                modifier = Modifier.fillMaxWidth().clickable {
                                    selectedProductIdForAdd = product.id
                                    addApplicationMethod = suggestApplicationMethod(product, categoryName)
                                    addUsagePattern = suggestUsagePattern(product)
                                    addQuantityValue = suggestQuantityValue(product)
                                    addQuantityUnit = suggestQuantityUnit(product)
                                    addTimingNote = product.timing
                                    addNote = product.usageNote
                                },
                                colors = CardDefaults.cardColors(
                                    containerColor = if (selected) MaterialTheme.colorScheme.tertiaryContainer else MaterialTheme.colorScheme.surface
                                )
                            ) {
                                Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text(product.name, fontWeight = FontWeight.Bold)
                                    if (product.code.isNotBlank()) Text("Kod: ${product.code}", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                                    if (categoryName.isNotBlank()) {
                                        Text(categoryName, color = MaterialTheme.colorScheme.primary)
                                    }
                                    if (product.description.isNotBlank()) {
                                        Text(product.description, maxLines = 2, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                            }
                        }
                    }
                    if (selectedProductForAdd != null) {
                        item {
                            ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = Color(0xFFF5F9FF))) {
                                Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Text("Seçilen takviye detayları", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                    Text(selectedProductForAdd.name)
                                    Text("Uygulama türü", fontWeight = FontWeight.SemiBold)
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        listOf("Ağızdan", "Çiğneme", "Saça", "Dış deriye").forEach { option ->
                                            FilterChip(selected = addApplicationMethod == option, onClick = { addApplicationMethod = option }, label = { Text(option) })
                                        }
                                    }
                                    Text("Kullanım şekli", fontWeight = FontWeight.SemiBold)
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        listOf("1x1", "1x2", "2x1", "2x2").forEach { option ->
                                            FilterChip(selected = addUsagePattern == option, onClick = { addUsagePattern = option }, label = { Text(option) })
                                        }
                                    }
                                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                                        OutlinedTextField(addQuantityValue, { addQuantityValue = it }, modifier = Modifier.weight(0.8f), label = { Text("Miktar") }, singleLine = true)
                                        OutlinedTextField(addQuantityUnit, { addQuantityUnit = it }, modifier = Modifier.weight(1.2f), label = { Text("Birim") }, singleLine = true)
                                    }
                                    OutlinedTextField(addTimingNote, { addTimingNote = it }, Modifier.fillMaxWidth(), label = { Text("Zaman") })
                                    OutlinedTextField(addNote, { addNote = it }, Modifier.fillMaxWidth(), label = { Text("Ek not") })
                                }
                            }
                        }
                    }
                }
            }
        )
    }


    Scaffold(
        topBar = {
            SmallTopAppBar(
                title = { Text("Takviye ve Beslenme Planı") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) } }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = Color(0xFFF2F8F4))) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("${p.firstName} ${p.lastName}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Text("Analizden beslenme planına uzanan tek ekran", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            AnalysisBadge("Kilo", latest?.weightKg?.oneDecimal()?.plus(" kg") ?: "-")
                            AnalysisBadge("VKİ", latest?.bmi?.oneDecimal() ?: "-")
                            AnalysisBadge("Yağ", latest?.bodyFatPercent?.oneDecimal()?.plus("%") ?: "-")
                        }
                    }
                }
            }
            item {
                Text("Plan odağı", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            }
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(
                        listOf("Kilo kontrolü", "Sindirim desteği"),
                        listOf("Enerji", "Cilt ve saç")
                    ).forEach { rowItems ->
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            rowItems.forEach { label ->
                                FilterChip(
                                    selected = goal == label,
                                    onClick = { goal = label },
                                    label = { Text(label) }
                                )
                            }
                        }
                    }
                }
            }
            item {
                ElevatedCard {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Beslenme omurgası", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        OutlinedTextField(meals, { meals = it }, Modifier.fillMaxWidth(), label = { Text("Öğün planı") })
                        OutlinedTextField(water, { water = it }, Modifier.fillMaxWidth(), label = { Text("Su planı") })
                        OutlinedTextField(notes, { notes = it }, Modifier.fillMaxWidth().height(120.dp), label = { Text("Uzman notu") })
                    }
                }
            }
            item {
                ElevatedCard {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Takviye seçimi", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text("Kategori seç, sonra küçük seçim penceresinden takviyeyi kullanım detaylarıyla birlikte ekle.")
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                FilterChip(selected = selectedCategoryId == null, onClick = { selectedCategoryId = null }, label = { Text("Tüm takviyeler") })
                            }
                            categories.chunked(2).forEach { chunk ->
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    chunk.forEach { cat ->
                                        FilterChip(
                                            selected = selectedCategoryId == cat.id,
                                            onClick = { selectedCategoryId = if (selectedCategoryId == cat.id) null else cat.id },
                                            label = { Text(cat.name) }
                                        )
                                    }
                                }
                            }
                        }
                        Button(onClick = { showAddSupplementDialog = true }, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.Add, null)
                            Spacer(Modifier.size(6.dp))
                            Text("Takviye seç ve ekle")
                        }
                        Surface(shape = MaterialTheme.shapes.medium, color = MaterialTheme.colorScheme.surfaceVariant) {
                            Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("Seçilen kategoriye göre görünen ürünler", fontWeight = FontWeight.SemiBold)
                                if (browseProducts.isEmpty()) {
                                    Text("Bu seçim için ürün görünmüyor.")
                                } else {
                                    browseProducts.take(5).forEach { product ->
                                        val categoryName = categories.firstOrNull { it.id == product.categoryId }?.name.orEmpty()
                                        Text("• ${product.name}${if (categoryName.isNotBlank()) " — $categoryName" else ""}")
                                    }
                                    if (browseProducts.size > 5) {
                                        Text("+ ${browseProducts.size - 5} ürün daha", color = MaterialTheme.colorScheme.primary)
                                    }
                                }
                            }
                        }
                        if (selectedPlanProducts.isNotEmpty()) {
                            Text("Eklenen kart sayısı: ${selectedPlanProducts.size}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
            item {
                ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = Color(0xFFFFF8EA))) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Hazırlanan takviye kartları", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        if (selectedProducts.isEmpty()) {
                            Text("Henüz ürün seçilmedi. Üstteki listeden takviye ekleyebilirsin.")
                        } else {
                            selectedProducts.forEach { product ->
                                val item = selectedPlanProducts.firstOrNull { it.productId == product.id } ?: return@forEach
                                SupplementPlanEditorCard(
                                    product = product,
                                    categoryName = categories.firstOrNull { it.id == product.categoryId }?.name.orEmpty(),
                                    item = item,
                                    onRemove = { addOrRemoveProduct(product, true) },
                                    onSave = { updated -> scope.launch { repo.updateDietPlanProduct(updated) } }
                                )
                            }
                        }
                    }
                }
            }
            item {
                ElevatedCard {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("WhatsApp / PDF özeti", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text(planText)
                    }
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = { shareText(context, planText, p, false) }, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Default.Share, null); Spacer(Modifier.size(6.dp)); Text("Paylaş")
                    }
                    Button(onClick = { shareText(context, planText, p, true) }, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Default.Share, null); Spacer(Modifier.size(6.dp)); Text("WhatsApp")
                    }
                }
            }
            item {
                OutlinedButton(onClick = {
                    val pdf = createDietPdf(context, p, planText)
                    shareFile(context, pdf, p, "application/pdf")
                }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.PictureAsPdf, null); Spacer(Modifier.size(6.dp)); Text("PDF Oluştur ve Paylaş")
                }
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}

@Composable
private fun AnalysisBadge(label: String, value: String) {
    Surface(shape = MaterialTheme.shapes.large, color = MaterialTheme.colorScheme.primaryContainer) {
        Column(Modifier.padding(horizontal = 14.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        }
    }
}

private fun suggestApplicationMethod(product: com.example.bodytracker.data.ProductEntity, categoryName: String): String = when {
    product.name.contains("creme", true) || product.name.contains("lotion", true) || product.name.contains("gelly", true) || categoryName.contains("Cilt", true) -> "Dış deriye"
    product.name.contains("shampoo", true) || product.name.contains("conditioner", true) || categoryName.contains("Saç", true) -> "Saça"
    product.name.contains("tooth", true) -> "Ağız içi"
    product.name.contains("spray", true) -> "Sprey"
    product.name.contains("gummy", true) -> "Çiğneme"
    else -> "Ağızdan"
}

private fun suggestUsagePattern(product: com.example.bodytracker.data.ProductEntity): String = when {
    product.timing.contains("sabah", true) && product.timing.contains("akşam", true) -> "1x2"
    product.defaultDose.contains("2", true) -> "2x2"
    else -> "1x2"
}

private fun suggestQuantityValue(product: com.example.bodytracker.data.ProductEntity): String = when {
    product.defaultDose.contains("30") -> "30"
    product.defaultDose.contains("2") -> "2"
    else -> "1"
}

private fun suggestQuantityUnit(product: com.example.bodytracker.data.ProductEntity): String = when {
    product.defaultDose.contains("ml", true) -> "ml"
    product.defaultDose.contains("tablet", true) -> "tablet"
    product.defaultDose.contains("kaps", true) -> "kapsül"
    product.name.contains("gel", true) || product.name.contains("creme", true) || product.name.contains("lotion", true) -> "ince tabaka"
    else -> "adet"
}

private fun formatSupplementLine(product: com.example.bodytracker.data.ProductEntity, item: com.example.bodytracker.data.DietPlanProductEntity): String {
    val pieces = listOf(
        product.name,
        item.applicationMethod.ifBlank { suggestApplicationMethod(product, "") },
        item.usagePattern.ifBlank { suggestUsagePattern(product) },
        listOf(item.quantityValue, item.quantityUnit).filter { it.isNotBlank() }.joinToString(" ").ifBlank { product.defaultDose },
        item.timingNote.ifBlank { item.customTiming.ifBlank { product.timing } },
        item.customNote
    ).filter { it.isNotBlank() }
    return pieces.joinToString(" — ")
}

@Composable
private fun SupplementPlanEditorCard(
    product: com.example.bodytracker.data.ProductEntity,
    categoryName: String,
    item: com.example.bodytracker.data.DietPlanProductEntity,
    onRemove: () -> Unit,
    onSave: (com.example.bodytracker.data.DietPlanProductEntity) -> Unit
) {
    var applicationMethod by remember(item.id) { mutableStateOf(item.applicationMethod.ifBlank { suggestApplicationMethod(product, categoryName) }) }
    var usagePattern by remember(item.id) { mutableStateOf(item.usagePattern.ifBlank { suggestUsagePattern(product) }) }
    var quantityValue by remember(item.id) { mutableStateOf(item.quantityValue.ifBlank { suggestQuantityValue(product) }) }
    var quantityUnit by remember(item.id) { mutableStateOf(item.quantityUnit.ifBlank { suggestQuantityUnit(product) }) }
    var timingNote by remember(item.id) { mutableStateOf(item.timingNote.ifBlank { item.customTiming.ifBlank { product.timing } }) }
    var note by remember(item.id) { mutableStateOf(item.customNote) }

    Surface(shape = MaterialTheme.shapes.large, color = MaterialTheme.colorScheme.surface) {
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                IconBadge(
                    icon = when {
                        applicationMethod.contains("Saça", true) -> Icons.Default.PhotoLibrary
                        applicationMethod.contains("Dış", true) -> Icons.Default.Category
                        else -> Icons.Default.LocalDrink
                    },
                    size = 42.dp
                )
                Column(modifier = Modifier.weight(1f)) {
                    Text(product.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    if (categoryName.isNotBlank()) Text(categoryName, color = MaterialTheme.colorScheme.primary)
                }
                IconButton(onClick = onRemove) { Icon(Icons.Default.Delete, null, tint = Color(0xFFC62828)) }
            }

            Text("Uygulama yöntemi", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Ağızdan", "Çiğneme", "Saça", "Dış deriye").forEach { option ->
                    FilterChip(selected = applicationMethod == option, onClick = { applicationMethod = option }, label = { Text(option) })
                }
            }

            Text("Kullanım şekli", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("1x1", "1x2", "2x1", "2x2").forEach { option ->
                    FilterChip(selected = usagePattern == option, onClick = { usagePattern = option }, label = { Text(option) })
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(quantityValue, { quantityValue = it }, modifier = Modifier.weight(0.8f), label = { Text("Miktar") }, singleLine = true)
                OutlinedTextField(quantityUnit, { quantityUnit = it }, modifier = Modifier.weight(1.2f), label = { Text("Birim") }, singleLine = true)
            }
            OutlinedTextField(timingNote, { timingNote = it }, Modifier.fillMaxWidth(), label = { Text("Zaman / kullanım notu") })
            OutlinedTextField(note, { note = it }, Modifier.fillMaxWidth(), label = { Text("Ek not") })

            Surface(shape = MaterialTheme.shapes.medium, color = MaterialTheme.colorScheme.secondaryContainer) {
                Text(
                    text = formatSupplementLine(product, item.copy(
                        applicationMethod = applicationMethod,
                        usagePattern = usagePattern,
                        quantityValue = quantityValue,
                        quantityUnit = quantityUnit,
                        timingNote = timingNote,
                        customNote = note
                    )),
                    modifier = Modifier.fillMaxWidth().padding(12.dp)
                )
            }

            Button(onClick = {
                onSave(item.copy(
                    applicationMethod = applicationMethod,
                    usagePattern = usagePattern,
                    quantityValue = quantityValue,
                    quantityUnit = quantityUnit,
                    timingNote = timingNote,
                    customTiming = timingNote,
                    goalTag = item.goalTag.ifBlank { "Plan" },
                    customNote = note,
                    customDose = listOf(quantityValue, quantityUnit).filter { it.isNotBlank() }.joinToString(" ")
                ))
            }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.Done, null)
                Spacer(Modifier.size(6.dp))
                Text("Takviye kartını kaydet")
            }
        }
    }
}

@Composable
private fun ProductSelectionCard(
    product: com.example.bodytracker.data.ProductEntity,
    categoryName: String,
    selected: Boolean,
    onToggle: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
            .clickable(onClick = onToggle),
        colors = CardDefaults.cardColors(
            containerColor = if (selected) MaterialTheme.colorScheme.tertiaryContainer else MaterialTheme.colorScheme.surface
        )
    ) {
        Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(color = MaterialTheme.colorScheme.primaryContainer, shape = MaterialTheme.shapes.medium, modifier = Modifier.size(72.dp)) {
                if (product.imageUrl.isNotBlank()) {
                    AsyncImage(
                        model = product.imageUrl,
                        contentDescription = product.name,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                        val categoryIcon = when {
                            categoryName.contains("Aloe", true) -> Icons.Default.LocalDrink
                            categoryName.contains("Vitamin", true) || categoryName.contains("Mineral", true) -> Icons.Default.Medication
                            categoryName.contains("Performans", true) -> Icons.Default.QueryStats
                            else -> Icons.Default.Inventory2
                        }
                        Icon(categoryIcon, contentDescription = null, modifier = Modifier.size(30.dp))
                    }
                }
            }
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(product.name, fontWeight = FontWeight.Bold)
                if (product.code.isNotBlank()) Text("Kod: ${product.code}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (categoryName.isNotBlank()) Text(categoryName, color = MaterialTheme.colorScheme.primary)
                if (product.description.isNotBlank()) Text(product.description, maxLines = 2)
                val info = listOf(product.defaultDose, product.timing).filter { it.isNotBlank() }.joinToString(" • ")
                if (info.isNotBlank()) Text(info, style = MaterialTheme.typography.bodySmall)
            }
            Button(onClick = onToggle) {
                Text(if (selected) "Çıkar" else "Ekle")
            }
        }
    }
}


private fun patientAge(patient: PatientEntity): Int = if (patient.ageYears > 0) patient.ageYears else calculateAge(patient.birthDateMillis)

private fun shareText(context: Context, content: String, patient: PatientEntity, whatsappOnly: Boolean) {
    val file = File(context.cacheDir, "diyet_${patient.firstName}_${patient.lastName}.txt")
    file.writeText(content)
    val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, content)
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    try {
        if (whatsappOnly) {
            intent.setPackage("com.whatsapp")
            context.startActivity(intent)
        } else context.startActivity(Intent.createChooser(intent, "Belgeyi paylaş"))
    } catch (_: ActivityNotFoundException) {
        context.startActivity(Intent.createChooser(intent.apply { `package` = null }, "Belgeyi paylaş"))
    }
}

private fun generateAnalysisReportText(
    patient: PatientEntity,
    latest: MeasurementEntity,
    previous: MeasurementEntity?,
    previousMonth: MeasurementEntity?,
    measurements: List<MeasurementEntity>
): String {
    val targetWeight = (22.0 * patient.heightCm * patient.heightCm) / 10000.0
    val first = measurements.lastOrNull()
    return buildString {
        appendLine("VUCUT ANALIZ RAPORU")
        appendLine("Danışan: ${patient.firstName} ${patient.lastName}")
        appendLine("Tarih: ${formatDate(latest.dateMillis)}")
        appendLine("Cinsiyet / Yaş: ${patient.gender} / ${patientAge(patient)}")
        appendLine("Boy: ${patient.heightCm} cm")
        appendLine()
        appendLine("GENEL OZET")
        appendLine("• Kilo: ${latest.weightKg.oneDecimal()} kg")
        appendLine("• VKI: ${latest.bmi.oneDecimal()}")
        appendLine("• Yag Orani: %${latest.bodyFatPercent.oneDecimal()}")
        appendLine("• Sivi Orani: %${latest.bodyWaterPercent.oneDecimal()}")
        appendLine("• Kas: ${latest.muscle.oneDecimal()}")
        appendLine("• Kemik: ${latest.bone.oneDecimal()} kg")
        appendLine("• Metabolizma Hizi: ${latest.metabolicRate.oneDecimal()} kcal")
        appendLine("• Metabolizma Yasi: ${latest.metabolicAge}")
        appendLine("• Ic Yag: ${latest.visceralFat.oneDecimal()}")
        appendLine()
        appendLine("HEDEF KILO KONTROLU")
        appendLine("• Ideal kilo: ${targetWeight.oneDecimal()} kg")
        appendLine("• Fark: ${(latest.weightKg - targetWeight).oneDecimal()} kg")
        appendLine("• Durum: ${buildAnalysisSummary(latest)}")
        appendLine()
        appendLine("REFERANS YORUMU")
        appendLine("• VKI: ${bmiReferenceStatus(latest.bmi).statusText}")
        appendLine("• Yag: ${bodyFatReferenceStatus(patient.gender, patientAge(patient), latest.bodyFatPercent).statusText}")
        appendLine("• Sivi: ${bodyWaterReferenceStatus(patient.gender, latest.bodyWaterPercent).statusText}")
        appendLine("• Kas: ${muscleReferenceStatus(patient.gender, latest.muscle).statusText}")
        appendLine("• Kemik: ${boneReferenceStatus(patient.gender, latest.bone).statusText}")
        previous?.let {
            appendLine()
            appendLine("ONCEKI OLCUME GORE")
            appendLine("• Kilo farki: ${(latest.weightKg - it.weightKg).oneDecimal()} kg")
            appendLine("• Yag farki: ${(latest.bodyFatPercent - it.bodyFatPercent).oneDecimal()} %")
            appendLine("• Sivi farki: ${(latest.bodyWaterPercent - it.bodyWaterPercent).oneDecimal()} %")
        }
        previousMonth?.let {
            appendLine()
            appendLine("ONCEKI AYA GORE")
            appendLine("• Kilo farki: ${(latest.weightKg - it.weightKg).oneDecimal()} kg")
            appendLine("• Yag farki: ${(latest.bodyFatPercent - it.bodyFatPercent).oneDecimal()} %")
            appendLine("• Sivi farki: ${(latest.bodyWaterPercent - it.bodyWaterPercent).oneDecimal()} %")
        }
        first?.let {
            appendLine()
            appendLine("ILK KAYDA GORE")
            appendLine("• Kilo farki: ${(latest.weightKg - it.weightKg).oneDecimal()} kg")
            appendLine("• Yag farki: ${(latest.bodyFatPercent - it.bodyFatPercent).oneDecimal()} %")
            appendLine("• Sivi farki: ${(latest.bodyWaterPercent - it.bodyWaterPercent).oneDecimal()} %")
        }
    }
}

private fun createAnalysisPdf(context: Context, patient: PatientEntity, content: String): File {
    val pdf = PdfDocument()
    val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
    val page = pdf.startPage(pageInfo)
    val canvas = page.canvas
    val titlePaint = Paint().apply { textSize = 20f; isFakeBoldText = true }
    val sectionPaint = Paint().apply { textSize = 13f; isFakeBoldText = true }
    val bodyPaint = Paint().apply { textSize = 11f }
    var y = 42f
    canvas.drawText("Vucut Analiz Raporu", 40f, y, titlePaint)
    y += 26f
    canvas.drawText("Danışan: ${patient.firstName} ${patient.lastName}", 40f, y, bodyPaint)
    y += 18f
    canvas.drawText("Olusturma tarihi: ${formatDate(System.currentTimeMillis())}", 40f, y, bodyPaint)
    y += 24f
    for (line in content.lines()) {
        val paint = if (line.isNotBlank() && line == line.uppercase()) sectionPaint else bodyPaint
        val safeLine = line.take(92)
        canvas.drawText(safeLine, 40f, y, paint)
        y += if (paint === sectionPaint) 20f else 16f
        if (y > 810f) break
    }
    pdf.finishPage(page)
    val file = File(context.cacheDir, "analiz_raporu_${patient.firstName}_${patient.lastName}.pdf")
    file.outputStream().use { pdf.writeTo(it) }
    pdf.close()
    return file
}

private fun shareFile(context: Context, file: File, patient: PatientEntity, mimeType: String) {
    val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = mimeType
        putExtra(Intent.EXTRA_STREAM, uri)
        putExtra(Intent.EXTRA_SUBJECT, "${patient.firstName} ${patient.lastName} raporu")
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(Intent.createChooser(intent, "Raporu paylaş"))
}

private fun createDietPdf(context: Context, patient: PatientEntity, content: String): File {
    val pdf = PdfDocument()
    val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
    val page = pdf.startPage(pageInfo)
    val canvas = page.canvas
    val titlePaint = Paint().apply { textSize = 20f; isFakeBoldText = true }
    val bodyPaint = Paint().apply { textSize = 12f }
    var y = 40f
    canvas.drawText("Danışan Analiz ve Takviye Planı", 40f, y, titlePaint)
    y += 30f
    canvas.drawText("Danışan: ${patient.firstName} ${patient.lastName}", 40f, y, bodyPaint)
    y += 20f
    canvas.drawText("Tarih: ${formatDate(System.currentTimeMillis())}", 40f, y, bodyPaint)
    y += 30f
    content.lines().forEach { line ->
        canvas.drawText(line.take(90), 40f, y, bodyPaint)
        y += 18f
        if (y > 800f) return@forEach
    }
    pdf.finishPage(page)
    val file = File(context.cacheDir, "diyet_raporu_${patient.firstName}_${patient.lastName}.pdf")
    file.outputStream().use { pdf.writeTo(it) }
    pdf.close()
    return file
}

private fun generateDietPlanText(patient: PatientEntity, measurements: List<MeasurementEntity>, goal: String, meals: String, water: String, notes: String, supplements: List<String>): String {
    val latest = measurements.firstOrNull()
    val firstRecord = measurements.lastOrNull()
    val penultimateRecord = measurements.getOrNull(1)
    val bmiLine = latest?.bmi?.oneDecimal() ?: "-"
    val weightLine = latest?.weightKg?.oneDecimal()?.plus(" kg") ?: "-"
    val fatLine = latest?.bodyFatPercent?.oneDecimal()?.plus("%") ?: "-"
    val visceralLine = latest?.visceralFat?.oneDecimal() ?: "-"
    val focus = when (goal) {
        "Kilo Verme" -> "Rafine şeker ve kızartma azaltılır, porsiyon kontrolü güçlendirilir."
        "Kas Koruma" -> "Protein dağılımı güne yayılır, ana öğünlerde kaliteli protein artırılır."
        else -> "Dengeli tabak modeli ve sürdürülebilir beslenme düzeni korunur."
    }
    return buildString {
        appendLine("DANIŞAN ANALİZ VE TAKVİYE PLANI")
        appendLine("Ad Soyad: ${patient.firstName} ${patient.lastName}")
        appendLine("Tarih: ${formatDate(System.currentTimeMillis())}")
        appendLine("Yaş: ${patientAge(patient)}")
        appendLine("Cinsiyet: ${patient.gender}")
        appendLine("Boy: ${patient.heightCm} cm")
        appendLine("Son Kilo: $weightLine")
        appendLine("VKİ: $bmiLine")
        appendLine("Vücut Yağ Oranı: $fatLine")
        appendLine("İç Yağ: $visceralLine")
        appendLine()
        appendLine()
        appendLine("KAYIT KIYASLAMASI")
        listOf(
            "İlk kayıt" to firstRecord,
            "Sondan bir önceki kayıt" to penultimateRecord,
            "Son kayıt" to latest
        ).forEach { (label, record) ->
            if (record != null) {
                appendLine("- $label (${formatDate(record.dateMillis)})")
                appendLine("  • Tip: ${record.analysisMode}")
                appendLine("  • Kilo: ${record.weightKg.oneDecimal()} kg")
                appendLine("  • VKİ: ${record.bmi.oneDecimal()}")
                appendLine("  • Yağ: %${record.bodyFatPercent.oneDecimal()}")
                appendLine("  • Sıvı: %${record.bodyWaterPercent.oneDecimal()}")
                appendLine("  • Kas: ${record.muscle.oneDecimal()}")
            }
        }
        appendLine()
        appendLine("HEDEF")
        appendLine(goal)
        appendLine()
        appendLine("BESLENME PLANLARI")
        appendLine("- $meals")
        appendLine("- Kahvaltıda protein kaynağı, öğle ve akşamda sebze + ana protein dengesi")
        appendLine("- Paketli atıştırmalık yerine yoğurt, kefir, meyve veya çiğ kuruyemiş")
        appendLine("- $water")
        appendLine("- $focus")
        appendLine()
        appendLine("TAKVİYE PLANI")
        if (supplements.isEmpty()) {
            appendLine("- Ek takviye seçilmedi")
        } else {
            supplements.forEach { appendLine("- $it") }
        }
        appendLine()
        appendLine("IZLEME NOTLARI")
        appendLine("- Haftalık kilo ve iştah takibi yapılır")
        appendLine("- Bir sonraki kontrolde önceki ölçümle kıyas önerilir")
        if (notes.isNotBlank()) appendLine("- Uzman notu: $notes")
    }
}


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AboutScreen(onBack: () -> Unit) {
    Scaffold(
        topBar = {
            SmallTopAppBar(
                title = { Text("Uygulama Hakkında") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) } }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                    Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Forever Danışan Takip", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        Text("Profesyonel danışan takip, ölçüm karşılaştırma, takviye planı ve paylaşım uygulaması")
                    }
                }
            }
            item {
                ElevatedCard {
                    Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Yapan: Barış Göral", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Text("Sürüm: 10.0")
                        Text("Öne çıkanlar: kamera desteği, danışan arama, otomatik VKİ, PDF rapor, WhatsApp paylaşımı, randevu takibi ve takviye planı.")
                    }
                }
            }
            item {
                ElevatedCard {
                    Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Sonraki geliştirmeler", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text("• Bulut yedekleme\n• Ölçüm grafiklerini çoğaltma\n• Randevu hatırlatma bildirimi\n• Çoklu uzman profili\n• PDF üst bilgi ve kurum logosu")
                    }
                }
            }
        }
    }
}

private fun saveBitmapToCache(context: Context, bitmap: Bitmap): Uri? {
    return runCatching {
        val file = File(context.cacheDir, "camera_${System.currentTimeMillis()}.jpg")
        FileOutputStream(file).use { out ->
            bitmap.compress(Bitmap.CompressFormat.JPEG, 92, out)
        }
        Uri.fromFile(file)
    }.getOrNull()
}

@Composable
fun QuickActionCard(
    title: String,
    icon: ImageVector,
    modifier: Modifier = Modifier,
    iconContainerColor: Color = MaterialTheme.colorScheme.primaryContainer,
    iconTint: Color = MaterialTheme.colorScheme.primary,
    onClick: () -> Unit
) {
    ElevatedCard(
        modifier = modifier.clickable(onClick = onClick),
        colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(
            Modifier.fillMaxWidth().padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            IconBadge(
                icon = icon,
                size = 52.dp,
                containerColor = iconContainerColor,
                iconTint = iconTint
            )
            Text(title, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun IconBadge(
    icon: ImageVector,
    size: androidx.compose.ui.unit.Dp = 40.dp,
    containerColor: Color = MaterialTheme.colorScheme.primaryContainer,
    iconTint: Color = MaterialTheme.colorScheme.primary
) {
    Surface(
        modifier = Modifier.size(size),
        shape = CircleShape,
        color = containerColor,
    ) {
        Box(contentAlignment = Alignment.Center) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = iconTint,
                modifier = Modifier.size(size * 0.5f)
            )
        }
    }
}

@Composable
private fun FormLeadingIcon(
    icon: ImageVector,
    containerColor: Color = MaterialTheme.colorScheme.primaryContainer,
    iconTint: Color = MaterialTheme.colorScheme.primary
) {
    IconBadge(icon = icon, size = 34.dp, containerColor = containerColor, iconTint = iconTint)
}

@Composable
fun TrendChartCard(measurements: List<MeasurementEntity>) {
    if (measurements.size < 2) return
    val primaryColor = MaterialTheme.colorScheme.primary
    val surfaceVariantColor = MaterialTheme.colorScheme.surfaceVariant
    val cardShape = MaterialTheme.shapes.medium
    ElevatedCard {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Kilo trend grafiği", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text("Son ${measurements.size} ölçümün görsel takibi")
            Canvas(modifier = Modifier.fillMaxWidth().height(180.dp).background(surfaceVariantColor, cardShape)) {
                val sorted = measurements.sortedBy { it.dateMillis }
                val weights = sorted.map { it.weightKg.toFloat() }
                val min = weights.minOrNull() ?: 0f
                val max = weights.maxOrNull() ?: 1f
                val range = (max - min).takeIf { it > 0 } ?: 1f
                val stepX = size.width / (weights.size - 1).coerceAtLeast(1)
                var prev: Offset? = null
                weights.forEachIndexed { index, value ->
                    val x = stepX * index
                    val y = size.height - ((value - min) / range) * (size.height - 20f) - 10f
                    val point = Offset(x, y)
                    drawCircle(color = primaryColor, radius = 6f, center = point)
                    prev?.let { drawLine(primaryColor, it, point, strokeWidth = 6f, cap = StrokeCap.Round) }
                    prev = point
                }
                drawRect(color = Color.Gray.copy(alpha = 0.2f), style = Stroke(2f))
            }
        }
    }
}

@Composable
fun PatientPhotoCard(photoUri: String?, onCamera: () -> Unit, onGallery: () -> Unit) {
    ElevatedCard {
        Column(Modifier.fillMaxWidth().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Surface(modifier = Modifier.height(150.dp).fillMaxWidth(), shape = MaterialTheme.shapes.large, color = MaterialTheme.colorScheme.surfaceVariant) {
                if (photoUri != null) {
                    AsyncImage(model = photoUri, contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                } else {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) { IconBadge(icon = Icons.Default.Person, size = 56.dp); Text("Danışan fotoğrafı") } }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onCamera) { Icon(Icons.Default.CameraAlt, null, tint = Color(0xFF1565C0)); Spacer(Modifier.size(6.dp)); Text("Kamera") }
                OutlinedButton(onClick = onGallery) { Icon(Icons.Default.PhotoLibrary, null, tint = Color(0xFF2E7D32)); Spacer(Modifier.size(6.dp)); Text("Galeri") }
            }
        }
    }
}

@Composable
fun NumericField(label: String, value: String, onValue: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = { onValue(it.filter { ch -> ch.isDigit() || ch == '.' || ch == ',' }.replace(',', '.')) },
        modifier = Modifier.fillMaxWidth(),
        label = { Text(label) },
        leadingIcon = { FormLeadingIcon(Icons.Default.QueryStats, containerColor = Color(0xFFE3F2FD), iconTint = Color(0xFF1565C0)) },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        singleLine = true
    )
}

@Composable
fun DateField(label: String, value: String, onClick: () -> Unit) {
    OutlinedButton(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                FormLeadingIcon(Icons.Default.CalendarMonth, containerColor = Color(0xFFFFF8E1), iconTint = Color(0xFFE69500))
                Text(label)
            }
            Text(value)
        }
    }
}


@Composable
fun ReferenceStatusCard(title: String, status: ReferenceStatus) {
    val container = when (status.level) {
        ReferenceLevel.NORMAL -> MaterialTheme.colorScheme.secondaryContainer
        ReferenceLevel.LOW -> MaterialTheme.colorScheme.tertiaryContainer
        ReferenceLevel.HIGH -> MaterialTheme.colorScheme.errorContainer
        ReferenceLevel.INFO -> MaterialTheme.colorScheme.primaryContainer
    }
    ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = container)) {
        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text("Referans: ${status.rangeLabel}")
            Text(status.statusText, fontWeight = FontWeight.Bold)
            if (status.detail.isNotBlank()) {
                Text(status.detail, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ModernDatePicker(initial: Long, title: String, onDismiss: () -> Unit, onConfirm: (Long) -> Unit) {
    val state = rememberDatePickerState(initialSelectedDateMillis = initial)
    DatePickerDialog(onDismissRequest = onDismiss, confirmButton = { TextButton(onClick = { onConfirm(state.selectedDateMillis ?: initial) }) { Text("Tamam") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("İptal") } }) {
        Column {
            Text(title, modifier = Modifier.padding(16.dp), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            DatePicker(state = state)
        }
    }
}


private fun referenceForMetric(label: String, value: Double, patient: PatientEntity, measurement: MeasurementEntity): ReferenceStatus {
    val age = patientAge(patient)
    return when (label) {
        "Kilo" -> weightReferenceStatus(value, patient.heightCm)
        "VKİ" -> bmiReferenceStatus(value)
        "Yağ" -> bodyFatReferenceStatus(patient.gender, age, value)
        "Sıvı" -> bodyWaterReferenceStatus(patient.gender, value)
        "Kas" -> muscleReferenceStatus(patient.gender, value)
        "Aktivite" -> activityReferenceStatus(value)
        "Kemik" -> boneReferenceStatus(patient.gender, value)
        "Met. Hızı" -> metabolicRateReferenceStatus(patient.gender, age, patient.heightCm, measurement.weightKg, value)
        "Met. Yaşı" -> metabolicAgeReferenceStatus(age, value.toInt())
        "İç Yağ" -> visceralFatReferenceStatus(value)
        else -> ReferenceStatus("Kişiye göre değişir", "Takip amaçlı gösterim", ReferenceLevel.INFO)
    }
}

@Composable
fun ProfessionalAnalysisReportCard(
    patient: PatientEntity,
    latest: MeasurementEntity,
    previous: MeasurementEntity?,
    previousMonth: MeasurementEntity?,
    measurements: List<MeasurementEntity>
) {
    val age = patientAge(patient)
    val targetWeight = (22.0 * patient.heightCm * patient.heightCm) / 10000.0
    val weightDelta = latest.weightKg - targetWeight
    val obesityDegree = if (targetWeight > 0) ((latest.weightKg / targetWeight) * 100.0) else 0.0
    val infoColor = MaterialTheme.colorScheme.onSurfaceVariant

    ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = Color(0xFFFDFCF8))) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Vücut Analiz Raporu", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Surface(shape = MaterialTheme.shapes.medium, color = MaterialTheme.colorScheme.primaryContainer) {
                Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("${patient.firstName} ${patient.lastName}", fontWeight = FontWeight.Bold)
                    Text("${patient.gender} • $age yaş • ${patient.heightCm} cm", color = infoColor)
                    Text("Ölçüm tarihi: ${formatDate(latest.dateMillis)}", color = infoColor)
                }
            }

            ReportSection(title = "Genel Özet") {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    ReportMiniStat("Kilo", "${latest.weightKg.oneDecimal()} kg", Modifier.weight(1f))
                    ReportMiniStat("VKİ", latest.bmi.oneDecimal(), Modifier.weight(1f))
                    ReportMiniStat("Met. Yaş", latest.metabolicAge.toString(), Modifier.weight(1f))
                }
            }

            ReportSection(title = "Vücut Kompozisyonu") {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    AnalysisProgressRow("Kilo", latest.weightKg.oneDecimal(), 0f, 150f, "kg")
                    AnalysisProgressRow("Yağ", latest.bodyFatPercent.oneDecimal(), 0f, 50f, "%")
                    AnalysisProgressRow("Sıvı", latest.bodyWaterPercent.oneDecimal(), 0f, 80f, "%")
                    AnalysisProgressRow("Kas", latest.muscle.oneDecimal(), 0f, 100f, "")
                    AnalysisProgressRow("Kemik", latest.bone.oneDecimal(), 0f, 10f, "kg")
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                ReportSection(title = "Hedef Kilo Kontrolü", modifier = Modifier.weight(1f)) {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        ReportKeyValueRow("Mevcut kilo", "${latest.weightKg.oneDecimal()} kg")
                        ReportKeyValueRow("İdeal kilo", "${targetWeight.oneDecimal()} kg")
                        ReportKeyValueRow("Fark", "${weightDelta.oneDecimal()} kg")
                        ReportKeyValueRow("Obezite derecesi", "%${obesityDegree.oneDecimal()}")
                    }
                }
                ReportSection(title = "Metabolik Yorum", modifier = Modifier.weight(1f)) {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        ReportKeyValueRow("BMR", "${latest.metabolicRate.oneDecimal()} kcal")
                        ReportKeyValueRow("Aktivite", latest.physicalActivity.oneDecimal())
                        ReportKeyValueRow("İç yağ", latest.visceralFat.oneDecimal())
                        ReportKeyValueRow("Durum", buildAnalysisSummary(latest))
                    }
                }
            }

            ReportSection(title = "Referans Analizi") {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    ReferenceSummaryRow("VKİ", bmiReferenceStatus(latest.bmi))
                    ReferenceSummaryRow("Yağ", bodyFatReferenceStatus(patient.gender, age, latest.bodyFatPercent))
                    ReferenceSummaryRow("Sıvı", bodyWaterReferenceStatus(patient.gender, latest.bodyWaterPercent))
                    ReferenceSummaryRow("Kas", muscleReferenceStatus(patient.gender, latest.muscle))
                    ReferenceSummaryRow("Kemik", boneReferenceStatus(patient.gender, latest.bone))
                }
            }

            ReportSection(title = "Fark Analizi") {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    DifferenceRow("Önceki kayıt", latest, previous)
                    DifferenceRow("Önceki ay", latest, previousMonth)
                    DifferenceRow("İlk kayıt", latest, measurements.lastOrNull())
                }
            }

            if (measurements.size >= 2) {
                ReportSection(title = "Fark Grafiği") {
                    TrendChartCard(measurements.take(6))
                }
            }
        }
    }
}

private fun buildAnalysisSummary(latest: MeasurementEntity): String {
    return when {
        latest.bodyFatPercent >= 30.0 -> "Yağ kontrolü odağı"
        latest.bodyWaterPercent <= 45.0 -> "Sıvı desteği odağı"
        latest.visceralFat >= 10.0 -> "İç yağ takibi gerekli"
        else -> "Dengeli görünüm"
    }
}

@Composable
fun ReportSection(title: String, modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    ElevatedCard(modifier = modifier, colors = CardDefaults.elevatedCardColors(containerColor = Color.White)) {
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, fontWeight = FontWeight.Bold, color = Color(0xFF264653))
            content()
        }
    }
}

@Composable
fun ReportMiniStat(label: String, value: String, modifier: Modifier = Modifier) {
    Surface(modifier = modifier, shape = MaterialTheme.shapes.medium, color = MaterialTheme.colorScheme.secondaryContainer) {
        Column(Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(label, style = MaterialTheme.typography.labelMedium)
            Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun ReportKeyValueRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun AnalysisProgressRow(label: String, value: String, min: Float, max: Float, unit: String) {
    val numeric = value.toFloatOrNull() ?: 0f
    val progress = ((numeric - min) / (max - min)).coerceIn(0f, 1f)
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label)
            Text("$value${if (unit.isNotBlank()) " $unit" else ""}", fontWeight = FontWeight.SemiBold)
        }
        Canvas(modifier = Modifier.fillMaxWidth().height(14.dp)) {
            drawRect(color = Color(0xFFE6ECF1))
            drawRect(color = Color(0xFF5B8DEF), size = androidx.compose.ui.geometry.Size(size.width * progress, size.height))
        }
    }
}

@Composable
fun ReferenceSummaryRow(label: String, status: ReferenceStatus) {
    Surface(shape = MaterialTheme.shapes.medium, color = when (status.level) {
        ReferenceLevel.NORMAL -> Color(0xFFE8F5E9)
        ReferenceLevel.LOW -> Color(0xFFE3F2FD)
        ReferenceLevel.HIGH -> Color(0xFFFFEBEE)
        ReferenceLevel.INFO -> MaterialTheme.colorScheme.secondaryContainer
    }) {
        Column(Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(label, fontWeight = FontWeight.SemiBold)
            Text(status.statusText)
            Text("Referans: ${status.rangeLabel}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
fun DifferenceRow(label: String, latest: MeasurementEntity, base: MeasurementEntity?) {
    val weightText = base?.let { (latest.weightKg - it.weightKg).oneDecimal() + " kg" } ?: "-"
    val fatText = base?.let { (latest.bodyFatPercent - it.bodyFatPercent).oneDecimal() + " %" } ?: "-"
    val waterText = base?.let { (latest.bodyWaterPercent - it.bodyWaterPercent).oneDecimal() + " %" } ?: "-"
    val muscleText = base?.let { (latest.muscle - it.muscle).oneDecimal() } ?: "-"
    Surface(shape = MaterialTheme.shapes.medium, color = MaterialTheme.colorScheme.surfaceVariant) {
        Column(Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(label, fontWeight = FontWeight.Bold)
            Text("Kilo: $weightText  •  Yağ: $fatText")
            Text("Sıvı: $waterText  •  Kas: $muscleText")
        }
    }
}

@Composable
fun ComparisonOverview(latest: MeasurementEntity, previous: MeasurementEntity?, previousMonth: MeasurementEntity?, olderMeasurements: List<MeasurementEntity>) {
    val average = olderMeasurements.takeIf { it.isNotEmpty() }?.let { list ->
        MeasurementEntity(
            patientId = latest.patientId,
            dateMillis = list.last().dateMillis,
            weightKg = list.map { it.weightKg }.average(),
            bmi = list.map { it.bmi }.average(),
            bodyFatPercent = list.map { it.bodyFatPercent }.average(),
            bodyWaterPercent = list.map { it.bodyWaterPercent }.average(),
            muscle = list.map { it.muscle }.average(),
            physicalActivity = list.map { it.physicalActivity }.average(),
            bone = list.map { it.bone }.average(),
            metabolicRate = list.map { it.metabolicRate }.average(),
            metabolicAge = list.map { it.metabolicAge }.average().toInt(),
            visceralFat = list.map { it.visceralFat }.average()
        )
    }
    ElevatedCard {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Detaylı Kıyas Özeti", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text("Son ölçüm: ${formatDate(latest.dateMillis)}")
            HorizontalDivider()
            MetricComparisonRow("Kilo", latest.weightKg, "kg", previous?.weightKg, previousMonth?.weightKg, average?.weightKg)
            MetricComparisonRow("VKİ", latest.bmi, "", previous?.bmi, previousMonth?.bmi, average?.bmi)
            MetricComparisonRow("Yağ", latest.bodyFatPercent, "%", previous?.bodyFatPercent, previousMonth?.bodyFatPercent, average?.bodyFatPercent)
            MetricComparisonRow("Sıvı", latest.bodyWaterPercent, "%", previous?.bodyWaterPercent, previousMonth?.bodyWaterPercent, average?.bodyWaterPercent)
            MetricComparisonRow("Kas", latest.muscle, "", previous?.muscle, previousMonth?.muscle, average?.muscle)
            MetricComparisonRow("Aktivite", latest.physicalActivity, "", previous?.physicalActivity, previousMonth?.physicalActivity, average?.physicalActivity)
            MetricComparisonRow("Kemik", latest.bone, "", previous?.bone, previousMonth?.bone, average?.bone)
            MetricComparisonRow("Met. Hızı", latest.metabolicRate, "", previous?.metabolicRate, previousMonth?.metabolicRate, average?.metabolicRate)
            MetricComparisonRow("Met. Yaşı", latest.metabolicAge.toDouble(), "", previous?.metabolicAge?.toDouble(), previousMonth?.metabolicAge?.toDouble(), average?.metabolicAge?.toDouble())
            MetricComparisonRow("İç Yağ", latest.visceralFat, "", previous?.visceralFat, previousMonth?.visceralFat, average?.visceralFat)
        }
    }
}

@Composable
fun MetricComparisonRow(label: String, current: Double, unit: String, previous: Double?, previousMonth: Double?, averagePrevious: Double?) {
    ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(label, fontWeight = FontWeight.Bold)
            Text("Güncel: ${current.oneDecimal()}${if (unit.isNotBlank()) " $unit" else ""}", style = MaterialTheme.typography.titleMedium)
            Text("Önceki kayıt: ${previous?.let { deltaText(current, it, unit).ifBlank { current.oneDecimal() } } ?: "Yok"}")
            Text("Önceki ay: ${previousMonth?.let { deltaText(current, it, unit).ifBlank { current.oneDecimal() } } ?: "Yok"}")
            Text("Tüm önceki kayıt ort.: ${averagePrevious?.let { deltaText(current, it, unit).ifBlank { current.oneDecimal() } } ?: "Yok"}")
        }
    }
}

@Composable
fun MetricChartsSection(measurements: List<MeasurementEntity>) {
    if (measurements.size < 2) return
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Ayrı Grafik Detayları", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        SimpleMetricChartCard("Kilo Grafiği", measurements) { it.weightKg }
        SimpleMetricChartCard("VKİ Grafiği", measurements) { it.bmi }
        SimpleMetricChartCard("Yağ Oranı Grafiği", measurements) { it.bodyFatPercent }
        SimpleMetricChartCard("Sıvı Oranı Grafiği", measurements) { it.bodyWaterPercent }
        SimpleMetricChartCard("Kas Grafiği", measurements) { it.muscle }
        SimpleMetricChartCard("Aktivite Grafiği", measurements) { it.physicalActivity }
        SimpleMetricChartCard("Kemik Grafiği", measurements) { it.bone }
        SimpleMetricChartCard("Metabolizma Hızı Grafiği", measurements) { it.metabolicRate }
        SimpleMetricChartCard("Metabolizma Yaşı Grafiği", measurements) { it.metabolicAge.toDouble() }
        SimpleMetricChartCard("İç Yağ Grafiği", measurements) { it.visceralFat }
    }
}

@Composable
fun SimpleMetricChartCard(title: String, measurements: List<MeasurementEntity>, metric: (MeasurementEntity) -> Double) {
    val points = measurements.sortedBy { it.dateMillis }.map(metric)
    if (points.size < 2) return
    val lineColor = MaterialTheme.colorScheme.primary
    val bgColor = MaterialTheme.colorScheme.surfaceVariant
    val shape = MaterialTheme.shapes.medium
    ElevatedCard {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text("Toplam ${points.size} kayıt üzerinden karşılaştırma")
            Canvas(modifier = Modifier.fillMaxWidth().height(150.dp).background(bgColor, shape)) {
                val values = points.map { it.toFloat() }
                val min = values.minOrNull() ?: 0f
                val max = values.maxOrNull() ?: 1f
                val range = (max - min).takeIf { it > 0f } ?: 1f
                val stepX = size.width / (values.size - 1).coerceAtLeast(1)
                var prev: Offset? = null
                values.forEachIndexed { index, value ->
                    val x = stepX * index
                    val y = size.height - ((value - min) / range) * (size.height - 20f) - 10f
                    val point = Offset(x, y)
                    drawCircle(color = lineColor, radius = 5f, center = point)
                    prev?.let { drawLine(lineColor, it, point, strokeWidth = 5f, cap = StrokeCap.Round) }
                    prev = point
                }
                drawRect(color = Color.Gray.copy(alpha = 0.2f), style = Stroke(2f))
            }
        }
    }
}

@Composable
fun MetricGrid(patient: PatientEntity, m: MeasurementEntity) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Ölçüm Kartları ve Referans", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        val items = listOf(
            Triple("Kilo", m.weightKg, "kg"),
            Triple("VKİ", m.bmi, ""),
            Triple("Yağ", m.bodyFatPercent, "%"),
            Triple("Sıvı", m.bodyWaterPercent, "%"),
            Triple("Kas", m.muscle, ""),
            Triple("Aktivite", m.physicalActivity, ""),
            Triple("Kemik", m.bone, ""),
            Triple("Met. Hızı", m.metabolicRate, "kcal"),
            Triple("Met. Yaşı", m.metabolicAge.toDouble(), ""),
            Triple("İç Yağ", m.visceralFat, "")
        )
        items.chunked(2).forEach { rowItems ->
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                rowItems.forEach { (title, value, unit) ->
                    val status = referenceForMetric(title, value, patient, m)
                    ElevatedCard(modifier = Modifier.weight(1f)) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(title, fontWeight = FontWeight.SemiBold)
                            Text(
                                if (unit.isBlank()) value.oneDecimal() else "${value.oneDecimal()} $unit",
                                style = MaterialTheme.typography.titleLarge
                            )
                            Text("Referans: ${status.rangeLabel}", style = MaterialTheme.typography.bodySmall)
                            Text(status.statusText, fontWeight = FontWeight.Bold,
                                color = when (status.level) {
                                    ReferenceLevel.NORMAL -> MaterialTheme.colorScheme.primary
                                    ReferenceLevel.LOW -> MaterialTheme.colorScheme.tertiary
                                    ReferenceLevel.HIGH -> MaterialTheme.colorScheme.error
                                    ReferenceLevel.INFO -> MaterialTheme.colorScheme.primary
                                }
                            )
                            if (status.detail.isNotBlank()) {
                                Text(status.detail, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
                if (rowItems.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}
