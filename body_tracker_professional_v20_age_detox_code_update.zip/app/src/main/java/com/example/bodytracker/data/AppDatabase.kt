package com.example.bodytracker.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Update
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow

@Dao
interface PatientDao {
    @Query("SELECT * FROM patients ORDER BY createdAt DESC")
    fun observePatients(): Flow<List<PatientEntity>>

    @Query("SELECT * FROM patients WHERE id = :id")
    fun observePatient(id: Long): Flow<PatientEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(patient: PatientEntity): Long

    @Update
    suspend fun update(patient: PatientEntity)

    @Delete
    suspend fun delete(patient: PatientEntity)
}

@Dao
interface MeasurementDao {
    @Query("SELECT * FROM measurements WHERE patientId = :patientId ORDER BY dateMillis DESC")
    fun observeMeasurements(patientId: Long): Flow<List<MeasurementEntity>>

    @Query("SELECT * FROM measurements WHERE id = :id LIMIT 1")
    fun observeMeasurement(id: Long): Flow<MeasurementEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(measurement: MeasurementEntity): Long

    @Update
    suspend fun update(measurement: MeasurementEntity)

    @Delete
    suspend fun delete(measurement: MeasurementEntity)
}

@Dao
interface AppointmentDao {
    @Query("SELECT * FROM appointments WHERE patientId = :patientId ORDER BY dateMillis ASC")
    fun observeAppointments(patientId: Long): Flow<List<AppointmentEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(appointment: AppointmentEntity): Long

    @Update
    suspend fun update(appointment: AppointmentEntity)

    @Delete
    suspend fun delete(appointment: AppointmentEntity)
}

@Dao
interface ProductCategoryDao {
    @Query("SELECT * FROM product_categories WHERE isActive = 1 ORDER BY sortOrder ASC, name ASC")
    fun observeCategories(): Flow<List<ProductCategoryEntity>>

    @Query("SELECT * FROM product_categories ORDER BY sortOrder ASC, name ASC")
    suspend fun getAll(): List<ProductCategoryEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(category: ProductCategoryEntity): Long

    @Update
    suspend fun update(category: ProductCategoryEntity)

    @Delete
    suspend fun delete(category: ProductCategoryEntity)
}

@Dao
interface ProductDao {
    @Query("SELECT * FROM products WHERE isActive = 1 ORDER BY name ASC")
    fun observeProducts(): Flow<List<ProductEntity>>

    @Query("SELECT COUNT(*) FROM products")
    suspend fun countProducts(): Int

    @Query("SELECT * FROM products ORDER BY name COLLATE NOCASE ASC, id ASC")
    suspend fun getAll(): List<ProductEntity>

    @Query("SELECT * FROM products WHERE isActive = 1 AND categoryId = :categoryId ORDER BY name ASC")
    fun observeProductsByCategory(categoryId: Long): Flow<List<ProductEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(product: ProductEntity): Long

    @Update
    suspend fun update(product: ProductEntity)

    @Delete
    suspend fun delete(product: ProductEntity)
}

@Dao
interface DietPlanDao {
    @Query("SELECT * FROM diet_plans WHERE patientId = :patientId ORDER BY createdAt DESC")
    fun observeDietPlans(patientId: Long): Flow<List<DietPlanEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(dietPlan: DietPlanEntity): Long

    @Update
    suspend fun update(dietPlan: DietPlanEntity)

    @Delete
    suspend fun delete(dietPlan: DietPlanEntity)
}

@Dao
interface DietPlanProductDao {
    @Query("SELECT * FROM diet_plan_products WHERE dietPlanId = :dietPlanId ORDER BY sortOrder ASC, id ASC")
    fun observeDietPlanProducts(dietPlanId: Long): Flow<List<DietPlanProductEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(item: DietPlanProductEntity): Long

    @Update
    suspend fun update(item: DietPlanProductEntity)

    @Delete
    suspend fun delete(item: DietPlanProductEntity)
}


@Dao
interface AppSettingDao {
    @Query("SELECT * FROM app_settings WHERE `key` = :key LIMIT 1")
    suspend fun get(key: String): AppSettingEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(setting: AppSettingEntity)
}

@Database(
    entities = [
        PatientEntity::class,
        MeasurementEntity::class,
        AppointmentEntity::class,
        ProductCategoryEntity::class,
        ProductEntity::class,
        DietPlanEntity::class,
        DietPlanProductEntity::class,
        AppSettingEntity::class
    ],
    version = 9,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun patientDao(): PatientDao
    abstract fun measurementDao(): MeasurementDao
    abstract fun appointmentDao(): AppointmentDao
    abstract fun productCategoryDao(): ProductCategoryDao
    abstract fun productDao(): ProductDao
    abstract fun dietPlanDao(): DietPlanDao
    abstract fun dietPlanProductDao(): DietPlanProductDao
    abstract fun appSettingDao(): AppSettingDao

    companion object {
        private val MIGRATION_5_6 = object : Migration(5, 6) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("""
                    CREATE TABLE IF NOT EXISTS `app_settings` (
                        `key` TEXT NOT NULL,
                        `value` TEXT NOT NULL,
                        `updatedAt` INTEGER NOT NULL,
                        PRIMARY KEY(`key`)
                    )
                """.trimIndent())
            }
        }

        private val MIGRATION_6_7 = object : Migration(6, 7) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("""
                    CREATE TABLE IF NOT EXISTS `app_settings` (
                        `key` TEXT NOT NULL,
                        `value` TEXT NOT NULL,
                        `updatedAt` INTEGER NOT NULL,
                        PRIMARY KEY(`key`)
                    )
                """.trimIndent())
            }
        }


        private val MIGRATION_7_8 = object : Migration(7, 8) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("ALTER TABLE diet_plan_products ADD COLUMN applicationMethod TEXT NOT NULL DEFAULT ''")
                database.execSQL("ALTER TABLE diet_plan_products ADD COLUMN usagePattern TEXT NOT NULL DEFAULT ''")
                database.execSQL("ALTER TABLE diet_plan_products ADD COLUMN quantityValue TEXT NOT NULL DEFAULT ''")
                database.execSQL("ALTER TABLE diet_plan_products ADD COLUMN quantityUnit TEXT NOT NULL DEFAULT ''")
                database.execSQL("ALTER TABLE diet_plan_products ADD COLUMN timingNote TEXT NOT NULL DEFAULT ''")
                database.execSQL("ALTER TABLE diet_plan_products ADD COLUMN goalTag TEXT NOT NULL DEFAULT ''")
            }
        }


        private val MIGRATION_8_9 = object : Migration(8, 9) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("ALTER TABLE patients ADD COLUMN ageYears INTEGER NOT NULL DEFAULT 0")
                database.execSQL("ALTER TABLE measurements ADD COLUMN analysisMode TEXT NOT NULL DEFAULT 'Standart'")
                database.execSQL("ALTER TABLE products ADD COLUMN code TEXT NOT NULL DEFAULT ''")
            }
        }

        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun get(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "body_tracker.db"
).addMigrations(MIGRATION_5_6, MIGRATION_6_7, MIGRATION_7_8, MIGRATION_8_9)
                    .build().also { INSTANCE = it }
            }
        }
    }
}
