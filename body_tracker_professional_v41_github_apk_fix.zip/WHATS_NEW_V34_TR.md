# V34 Kurumsal Dashboard ve Güvenli Yedek

- Ana ekran, kurumsal/profesyonel operasyon paneli görünümüne taşındı.
- Danışan dağılımı, bugünkü randevu, 7 günlük randevu ve ölçüm bekleyen danışanlar üst özet alanda toplandı.
- Hızlı işlem kartları daha net ikon, başlık ve açıklama düzeniyle yenilendi.
- Mevcut yerel veritabanını paylaşılabilir `.db` yedeği olarak dışa aktarma eklendi.
- Yedek oluşturma işlemi arka planda çalışır; ekranın takılması azaltıldı.
- Hakkında ekranı ve paket sürümü 34.0 olarak güncellendi.

Not: Room veritabanı versiyonu değiştirilmedi. Bu sürüm mevcut veritabanına zarar vermeden görsel yapı ve iş akışı katmanını iyileştirir.
