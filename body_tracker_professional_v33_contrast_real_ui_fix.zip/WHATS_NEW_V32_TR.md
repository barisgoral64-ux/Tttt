# v32 - Görsel Dashboard ve Ayrı Danışan Listesi

- Ana ekran koyu FOREVER PRO dashboard tarzına yaklaştırıldı.
- Kart renkleri koyu, modern ve daha kurumsal hale getirildi.
- Danışan listesi artık ana ekranın altında açılmıyor; ayrı Danışanlar ekranı olarak açılıyor.
- Danışanlar ekranında canlı arama, düzenleme, silme ve detay açma akışı korundu.
- Hızlı işlem kartları sadeleştirildi.
- Uygulama teması koyu kurumsal görünüme sabitlendi.
- versionCode 32 / versionName 32.0.
